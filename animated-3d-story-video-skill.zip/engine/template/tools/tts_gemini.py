#!/usr/bin/env python3
"""Built-in voice-over with Google's Gemini TTS (the same voices as Google AI Studio "Generate speech").
Needs the user's own free API key from https://aistudio.google.com/apikey saved as GEMINI_API_KEY (never paste it in chat:
save it in the vault / as an env var). One request per block so each block can carry its own emotion.
usage: GEMINI_API_KEY=... python tools/tts_gemini.py voice_blocks.json audio/vo [--voice Puck] [--model gemini-2.5-flash-preview-tts]
voice_blocks.json: [["excited", "Imagine this. ..."], ["suspense", "..."], ...]   ->  audio/vo/vo_01.wav, vo_02.wav ...
Then: python tools/voice_prep.py audio/vo/vo_*.wav --script script.json
Energetic narrator voices that suit the style: Puck (upbeat), Fenrir (excitable), Charon (informative), Orus (firm)."""
import argparse, json, os, sys, base64, wave, urllib.request, urllib.error, time
ap = argparse.ArgumentParser(); ap.add_argument('blocks'); ap.add_argument('outdir'); ap.add_argument('--voice', default='Puck'); ap.add_argument('--model', default='gemini-2.5-flash-preview-tts')
ap.add_argument('--style', default='Read this like an energetic YouTube Shorts storyteller: fast pace, punchy, natural and human, short pauses.')
A = ap.parse_args(); KEY = os.environ.get('GEMINI_API_KEY') or sys.exit('GEMINI_API_KEY is not set')
BASE = 'https://generativelanguage.googleapis.com/v1beta'
def call(model, text):
    body = {'contents': [{'parts': [{'text': text}]}], 'generationConfig': {'responseModalities': ['AUDIO'], 'speechConfig': {'voiceConfig': {'prebuiltVoiceConfig': {'voiceName': A.voice}}}}}
    r = urllib.request.Request(f'{BASE}/models/{model}:generateContent', data=json.dumps(body).encode(), headers={'Content-Type': 'application/json', 'x-goog-api-key': KEY})
    d = json.load(urllib.request.urlopen(r, timeout=180))
    part = d['candidates'][0]['content']['parts'][0]['inlineData']; return base64.b64decode(part['data']), part.get('mimeType', '')
def pick_model():
    r = urllib.request.Request(f'{BASE}/models?pageSize=200', headers={'x-goog-api-key': KEY}); M = json.load(urllib.request.urlopen(r, timeout=60)).get('models', [])
    tts = [m['name'].split('/')[-1] for m in M if 'tts' in m['name']]; print('TTS models available:', tts); return tts[0] if tts else None
B = json.load(open(A.blocks)); os.makedirs(A.outdir, exist_ok=True); model = A.model
for i, (emo, text) in enumerate(B, 1):
    prompt = f'{A.style} Emotion for this part: {emo}.\n\n{text}'
    for attempt in range(4):
        try: pcm, mime = call(model, prompt); break
        except urllib.error.HTTPError as e:
            msg = e.read()[:300]; print('HTTP', e.code, msg)
            if e.code == 404 and attempt == 0: model = pick_model() or sys.exit('no TTS model available for this key'); continue
            if e.code in (429, 500, 503): time.sleep(8 * (attempt + 1)); continue
            sys.exit(1)
    rate = 24000
    if 'rate=' in mime: rate = int(mime.split('rate=')[1].split(';')[0])
    out = os.path.join(A.outdir, f'vo_{i:02d}.wav')
    with wave.open(out, 'wb') as w: w.setnchannels(1); w.setsampwidth(2); w.setframerate(rate); w.writeframes(pcm)
    print('wrote', out, round(len(pcm) / 2 / rate, 2), 's', emo, flush=True)
