#!/usr/bin/env python3
"""Estimated word timings from the script (before the real voice exists - used for the look/storyboard/preview stages).
usage: python tools/est_timing.py script.json words.json [words_per_second=4.2]
script.json: [{"text": "...", "beat": "...", "emotion": "..."}, ...]  (one entry per sentence)
Re-time with tools/words.py as soon as the real voice-over exists."""
import json, sys, re
S = json.load(open(sys.argv[1])); wps = float(sys.argv[3]) if len(sys.argv) > 3 else 4.2
t = 0.0; W = []; sent = []
for s in S:
    toks = s['text'].split(); s0 = t
    for tok in toks:
        d = max(0.12, (len(re.sub(r'[^A-Za-z0-9]', '', tok)) + 2) / 6.5 / wps * 1.3)
        W.append({'t': tok, 's': round(t, 3), 'e': round(t + d, 3)}); t += d
        if re.search(r'[,;:]$', tok): t += 0.08
    sent.append({'text': s['text'], 's': round(s0, 3), 'e': round(t, 3)}); t += 0.12
json.dump({'words': W, 'sent': sent, 'estimated': True}, open(sys.argv[2], 'w'), indent=0)
print('estimated', len(W), 'words', round(t, 2), 's')
