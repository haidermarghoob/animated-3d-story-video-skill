#!/usr/bin/env python3
"""Frames worth checking: for every shot in src/camera.js, its start + 0.3 s and its middle (30 fps).
usage: python tools/frames.py [max_frames]      -> prints frame numbers for tools/stillrun.sh
Reads the add(...) lines of THE SHOT LIST (start = 0, a number, or w('word', n, approx) [+/- offset])."""
import re, sys, json
src = open('src/camera.js').read(); tj = open('src/timing.js').read()
W = json.loads(re.search(r'export const WORDS=(\[.*?\]);', tj).group(1)); D = float(re.search(r'DURATION_S=([0-9.]+)', tj).group(1))
def w(word, n=0, fb=0.0):
    c = [x['s'] for x in W if x['t'] == word]
    return min(c, key=lambda s: abs(s - fb)) if c else fb
T = []
for m in re.finditer(r"^\s*add\((.+?),\s*'(cut|hard|diss)'", src, re.M):
    e = m.group(1).strip()
    try: T.append(eval(e, {'w': w}))
    except Exception: pass
T = sorted(T); fr = []
for i, t0 in enumerate(T):
    t1 = T[i + 1] if i + 1 < len(T) else D
    fr += [round((t0 + 0.3) * 30), round((t0 + t1) / 2 * 30)]
mx = int(sys.argv[1]) if len(sys.argv) > 1 else 999
fr = sorted(set(f for f in fr if f < round(D * 30)))
print(' '.join(str(f) for f in fr[:mx]))
