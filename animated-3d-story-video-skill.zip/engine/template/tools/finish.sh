#!/usr/bin/env bash
# Join all chunks, mux the final mix, make sure the file is 1080x1920, write a contact sheet and run the QA.
# usage: tools/finish.sh "Video Title"      -> out/<Video Title>.mp4, out/<Video Title> (voice + SFX only).mp4, out/contact_sheet.jpg, out/qa.txt
# (ffmpeg -movflags +faststart can fail on network filesystems: everything is written in /tmp first, then copied)
set -e
cd "$(dirname "$0")/.."
TITLE=${1:-final}; D=out/chunks; L=/tmp/fin_list_$$.txt
N=$(python3 -c "import re;print(round(float(re.search(r'DURATION_S=([0-9.]+)',open('src/timing.js').read()).group(1))*30))")
DUR=$(python3 -c "print($N/30)")
STEP=$(sed -n 's/.*step=\([0-9]*\).*/\1/p' $D/stamp 2>/dev/null); STEP=${STEP:-150}
: > $L
for ((a=0; a<N; a+=STEP)); do b=$((a+STEP-1)); [ $b -ge $N ] && b=$((N-1)); n=$(printf "c_%05d_%05d" $a $b)
  [ -f $D/$n.done ] || { echo "MISSING chunk $n - run tools/render.sh first"; exit 1; }; echo "file '$PWD/$D/$n.mp4'" >> $L; done
ffmpeg -v error -y -f concat -safe 0 -i $L -c copy /tmp/fin_silent.mp4
H=$(ffprobe -v error -select_streams v:0 -show_entries stream=height -of csv=p=0 /tmp/fin_silent.mp4)
VF=""; VC="-c:v copy"; [ "$H" != "1920" ] && { VF="-vf scale=1080:1920:flags=lanczos,unsharp=3:3:0.4"; VC="-c:v libx264 -crf 17 -preset medium -pix_fmt yuv420p"; }
AUD=audio/final_mix.wav; [ -f $AUD ] || AUD=public/voiceover.wav
if [ -f $AUD ]; then ffmpeg -v error -y -i /tmp/fin_silent.mp4 -i $AUD -map 0:v -map 1:a $VF $VC -c:a aac -b:a 192k -t $DUR -movflags +faststart /tmp/fin_final.mp4
else echo "WARNING: no audio found (audio/final_mix.wav or public/voiceover.wav) - silent video"; ffmpeg -v error -y -i /tmp/fin_silent.mp4 $VF $VC -t $DUR -movflags +faststart /tmp/fin_final.mp4; fi
mkdir -p out; cp /tmp/fin_final.mp4 "out/$TITLE.mp4"
if [ -f audio/final_mix_nomusic.wav ]; then
  ffmpeg -v error -y -i /tmp/fin_final.mp4 -i audio/final_mix_nomusic.wav -map 0:v -map 1:a -c:v copy -c:a aac -b:a 192k -t $DUR -movflags +faststart /tmp/fin_nm.mp4
  cp /tmp/fin_nm.mp4 "out/$TITLE (voice + SFX only).mp4"
fi
ffmpeg -v error -y -i /tmp/fin_final.mp4 -vf "fps=36/$DUR,scale=144:-2,tile=6x6" -frames:v 1 -update 1 /tmp/fin_contact.jpg && cp /tmp/fin_contact.jpg out/contact_sheet.jpg
.venv/bin/python tools/qa.py "out/$TITLE.mp4" | tee out/qa.txt
rm -f $L /tmp/fin_silent.mp4 /tmp/fin_final.mp4 /tmp/fin_nm.mp4
echo FINISHED "out/$TITLE.mp4"
