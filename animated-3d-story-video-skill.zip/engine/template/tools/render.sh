#!/usr/bin/env bash
# Chunked, resumable render of the Story composition (CPU-safe; each chunk retries 3x; finished chunks are skipped).
# usage: tools/render.sh [FROM_FRAME] [TO_FRAME]      (default: the whole video)
# env:   SCALE=1.5 (1080x1920, default) | SCALE=1 (720x1280, ~2x faster; finish.sh upscales to 1080x1920)
#        STEP=150 (frames per chunk = 5 s)  CONC=2 (browser tabs)  GL=swangle (CPU) | angle (GPU machine)
# Run DETACHED (the sandbox shell times out at 120 s):  setsid nohup tools/render.sh > /dev/null 2>&1 &
# Poll: tail -3 out/chunks/render.log      Speed on a CPU sandbox: ~3-4 s/frame at SCALE=1, ~6-8 s/frame at 1.5.
cd "$(dirname "$0")/.."
SCALE=${SCALE:-1.5}; STEP=${STEP:-150}; CONC=${CONC:-2}; GL=${GL:-swangle}
N=$(python3 -c "import re;print(round(float(re.search(r'DURATION_S=([0-9.]+)',open('src/timing.js').read()).group(1))*30))")
A=${1:-0}; B=${2:-$((N-1))}; [ $B -ge $N ] && B=$((N-1))
D=out/chunks; mkdir -p $D; LOG=$D/render.log
# a chunk rendered at another scale or from older code must not be reused
STAMP="scale=$SCALE step=$STEP"; [ -f $D/stamp ] && [ "$(cat $D/stamp)" != "$STAMP" ] && { echo "scale/step changed: clearing old chunks" >> $LOG; rm -f $D/c_*; }
echo "$STAMP" > $D/stamp
echo "START $(date -u +%FT%TZ) frames $A-$B of $N scale=$SCALE" >> $LOG; START=$(date +%s)
if [ ! -f build_final/index.html ] || [ -n "$(find src public -newer build_final/index.html -type f 2>/dev/null | head -1)" ]; then
  rm -rf build_final; npx remotion bundle src/index.jsx --out-dir build_final > $D/bundle.log 2>&1 || { echo "BUNDLE_FAIL (see $D/bundle.log)" >> $LOG; exit 1; }
  rm -f $D/c_*   # new code -> old chunks are stale
fi
for ((a=(A/STEP)*STEP; a<=B; a+=STEP)); do
  b=$((a+STEP-1)); [ $b -ge $N ] && b=$((N-1)); name=$(printf "c_%05d_%05d" $a $b)
  [ -f $D/$name.done ] && continue; t0=$(date +%s); rm -f $D/$name.mp4
  for attempt in 1 2 3; do
    npx remotion render build_final Story $D/$name.mp4 --frames=$a-$b --gl=$GL --concurrency=$CONC --scale=$SCALE --timeout=240000 \
      --image-format=jpeg --jpeg-quality=93 --crf=17 --muted > $D/$name.log 2>&1 && { touch $D/$name.done; break; }
    echo "RETRY $name attempt $attempt" >> $LOG; rm -f $D/$name.mp4
  done
  echo "$name $(( $(date +%s)-t0 ))s $( [ -f $D/$name.done ] && echo OK || echo FAIL)" >> $LOG
done
echo "RANGE_FINISHED $A-$B $(( $(date +%s)-START ))s" >> $LOG
