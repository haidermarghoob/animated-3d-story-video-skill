#!/usr/bin/env python3
"""Tile images side by side (4 per row) with their frame number: python tools/sheet.py out.jpg a.png b.png ..."""
import sys
from PIL import Image, ImageDraw
fs = sys.argv[2:]; ims = [Image.open(f).convert('RGB') for f in fs]; w, h = ims[0].size; cols = min(4, len(ims)); rows = (len(ims) + cols - 1) // cols
S = Image.new('RGB', (w * cols, (h + 18) * rows), 'white'); d = ImageDraw.Draw(S)
for i, (f, im) in enumerate(zip(fs, ims)):
    x, y = (i % cols) * w, (i // cols) * (h + 18); S.paste(im.resize((w, h)), (x, y + 18)); d.text((x + 4, y + 3), f.split('/')[-1], fill='black')
S.thumbnail((2400, 2400)); S.save(sys.argv[1], quality=85); print('sheet', sys.argv[1], S.size)
