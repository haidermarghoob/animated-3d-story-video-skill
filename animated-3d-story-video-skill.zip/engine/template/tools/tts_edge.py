#!/usr/bin/env python3
"""Free fallback voice (Microsoft Edge neural voices, no key). Sounds less human than Gemini/AI Studio or ElevenLabs - say so.
usage: python tools/tts_edge.py voice_blocks.json audio/vo [--voice en-US-GuyNeural] [--rate +22%] [--pitch +4Hz]
-> audio/vo/vo_01.mp3 ...   then: python tools/voice_prep.py audio/vo/vo_*.mp3 --script script.json
Good picks: en-US-GuyNeural +22% +4Hz (narrator), en-GB-RyanNeural +18% (best edge voice), en-US-AndrewMultilingualNeural.
Hindi/Urdu narration: hi-IN-MadhurNeural, ur-PK-AsadNeural. If it fails with NoAudioReceived: run sequentially, unset proxy vars."""
import argparse, asyncio, json, os, time
import edge_tts
ap = argparse.ArgumentParser(); ap.add_argument('blocks'); ap.add_argument('outdir'); ap.add_argument('--voice', default='en-US-GuyNeural'); ap.add_argument('--rate', default='+22%'); ap.add_argument('--pitch', default='+4Hz')
A = ap.parse_args(); B = json.load(open(A.blocks)); os.makedirs(A.outdir, exist_ok=True)
for i, (emo, text) in enumerate(B, 1):
    out = os.path.join(A.outdir, f'vo_{i:02d}.mp3')
    for attempt in range(4):
        try: asyncio.run(edge_tts.Communicate(text, A.voice, rate=A.rate, pitch=A.pitch).save(out)); break
        except Exception as e: print('retry', i, e); time.sleep(3)
    print('wrote', out, flush=True)
