#!/usr/bin/env bash
# Stitch the finished chunks that cover frames A..B into one checkable clip WITH sound -> out/act_A_B.mp4
# (stage "video hissa hissa": render one act with render.sh A B, then show this clip to the user).
# usage: tools/act.sh A B
cd "$(dirname "$0")/.."
A=$1; B=$2; D=out/chunks; L=/tmp/act_list_$$.txt; : > $L
for f in $(ls $D/c_*.mp4 | sort); do n=$(basename $f .mp4); a=$((10#$(echo $n | cut -d_ -f2))); b=$((10#$(echo $n | cut -d_ -f3)))
  [ -f $D/$n.done ] && [ $b -ge $A ] && [ $a -le $B ] && echo "file '$PWD/$f'" >> $L; done
[ -s $L ] || { echo "no finished chunks in $A-$B"; exit 1; }
first=$(head -1 $L | sed "s/.*c_\([0-9]*\)_.*/\1/"); s0=$(python3 -c "print(int('$first')/30)")
AUD=audio/final_mix.wav; [ -f $AUD ] || AUD=public/voiceover.wav
ffmpeg -v error -y -f concat -safe 0 -i $L -c copy /tmp/act_v_$$.mp4
if [ -f $AUD ]; then ffmpeg -v error -y -i /tmp/act_v_$$.mp4 -ss $s0 -i $AUD -map 0:v -map 1:a -c:v copy -c:a aac -b:a 192k -shortest -movflags +faststart /tmp/act_$$.mp4
else cp /tmp/act_v_$$.mp4 /tmp/act_$$.mp4; fi
mkdir -p out; cp /tmp/act_$$.mp4 out/act_${A}_${B}.mp4; rm -f /tmp/act_*_$$.* /tmp/act_$$.mp4 $L
echo "out/act_${A}_${B}.mp4"
