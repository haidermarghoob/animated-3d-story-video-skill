#!/usr/bin/env bash
# The 5-second trailer: renders frames 0-149 at 720x1280 with sound -> out/preview_5s.mp4 (about 5-10 min on CPU).
# usage (detached): setsid nohup tools/preview.sh > /dev/null 2>&1 &   then poll: cat out/preview.done
cd "$(dirname "$0")/.."
GL=${GL:-swangle}; mkdir -p out; rm -f out/preview.done
N=$(python3 -c "import re;print(round(float(re.search(r'DURATION_S=([0-9.]+)',open('src/timing.js').read()).group(1))*30))")
END=${1:-149}; [ $END -ge $N ] && END=$((N-1))
npx remotion bundle src/index.jsx --out-dir build > out/bundle.log 2>&1 || { echo BUNDLE_FAIL > out/preview.done; exit 1; }
npx remotion render build Story /tmp/prev_v.mp4 --frames=0-$END --gl=$GL --concurrency=2 --timeout=240000 --image-format=jpeg --jpeg-quality=90 --crf=18 --muted > out/preview.log 2>&1 || { echo RENDER_FAIL > out/preview.done; exit 1; }
AUD=audio/final_mix.wav; [ -f $AUD ] || AUD=public/voiceover.wav
if [ -f $AUD ]; then ffmpeg -v error -y -i /tmp/prev_v.mp4 -i $AUD -map 0:v -map 1:a -c:v copy -c:a aac -b:a 192k -shortest -movflags +faststart /tmp/prev.mp4
else cp /tmp/prev_v.mp4 /tmp/prev.mp4; fi
cp /tmp/prev.mp4 out/preview_5s.mp4; echo DONE > out/preview.done
