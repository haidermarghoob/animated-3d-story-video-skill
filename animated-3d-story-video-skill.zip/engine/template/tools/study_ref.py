#!/usr/bin/env python3
"""Study a reference Short (YouTube/TikTok/Instagram link or a video file the user uploaded) so a NEW story can copy its
ANDAAZ (pace, cuts, camera, captions, sound, structure) - never its content.
usage: python tools/study_ref.py <url-or-file> ref/       -> ref/ref.mp4, ref/report.md, ref/contact.jpg, ref/hook.jpg, ref/words.json
Measures: length, size/fps, cuts per minute and average shot length (scene detection), the first 3 s (hook frames),
loudness, speech pace (words/s) and the full transcript with beats, caption look (look at the frames yourself).
If the download is blocked (YouTube often blocks servers: "Sign in to confirm you're not a bot"), ask the user to
download the Short on their phone and upload the file in chat, then run this on the file."""
import subprocess, sys, os, re, json, shutil
src, out = sys.argv[1], sys.argv[2].rstrip('/'); os.makedirs(out, exist_ok=True); vid = f'{out}/ref.mp4'
def run(*a, **k): return subprocess.run(a, capture_output=True, text=True, **k)
if os.path.exists(src): shutil.copy(src, vid)
else:
    r = run('yt-dlp', '-f', 'bv*[height<=1920]+ba/b', '--merge-output-format', 'mp4', '-o', vid, '--no-playlist', src)
    if r.returncode or not os.path.exists(vid):
        print('DOWNLOAD FAILED:', (r.stderr or '')[-600:]); print('-> ask the user to upload the video file itself'); sys.exit(2)
p = json.loads(run('ffprobe', '-v', 'error', '-show_streams', '-show_format', '-of', 'json', vid).stdout)
v = [s for s in p['streams'] if s['codec_type'] == 'video'][0]; dur = float(p['format']['duration'])
r = run('ffmpeg', '-hide_banner', '-i', vid, '-vf', "select='gt(scene,0.30)',showinfo", '-an', '-f', 'null', '-').stderr
cuts = [round(float(x), 2) for x in re.findall(r'pts_time:([0-9.]+)', r)]
shots = [b - a for a, b in zip([0] + cuts, cuts + [dur])]
run('ffmpeg', '-v', 'error', '-y', '-i', vid, '-vf', f'fps=36/{dur},scale=160:-2,tile=6x6', '-frames:v', '1', '-update', '1', f'{out}/contact.jpg')
run('ffmpeg', '-v', 'error', '-y', '-i', vid, '-vf', 'fps=2,scale=240:-2,tile=6x1', '-t', '3', '-frames:v', '1', '-update', '1', f'{out}/hook.jpg')
r = run('ffmpeg', '-hide_banner', '-i', vid, '-af', 'ebur128', '-f', 'null', '-').stderr
lufs = r[r.rindex('I:') + 2:].split('LUFS')[0].strip() if 'I:' in r else '?'
run('ffmpeg', '-v', 'error', '-y', '-i', vid, '-ac', '1', '-ar', '16000', f'{out}/ref_audio.wav')
here = os.path.dirname(os.path.abspath(__file__)); py = sys.executable
w = run(py, f'{here}/words.py', f'{out}/ref_audio.wav', f'{out}/words.json', '--model', os.environ.get('WHISPER_MODEL', 'base'))
words = json.load(open(f'{out}/words.json'))['words'] if os.path.exists(f'{out}/words.json') else []
text = ' '.join(x['t'] for x in words); wps = len(words) / max(0.1, (words[-1]['e'] - words[0]['s'])) if words else 0
rep = f"""# Reference study
- file: {vid}  ({v['width']}x{v['height']}, {v.get('r_frame_rate')}, {dur:.1f} s)
- cuts: {len(cuts)} -> {len(cuts) / dur * 60:.0f} per minute; average shot {sum(shots) / len(shots):.2f} s; shortest {min(shots):.2f} s, longest {max(shots):.2f} s
- cut times: {cuts}
- loudness: {lufs} LUFS integrated
- speech: {len(words)} words, {wps:.2f} words/s, first word at {words[0]['s'] if words else '?'} s
- contact sheet: {out}/contact.jpg (36 frames), hook: {out}/hook.jpg (first 3 s at 2 fps)

## Transcript
{text}

## Fill in after looking at the frames (this is what to copy - the ANDAAZ, not the story)
- hook (first 1-3 s): what is on screen, what line, how fast the payoff
- story shape: schemer vs simple person? beats (setup / but / then / reveal / punchline / loop)
- characters: head/face/limb style, outfits, how many
- world: realism, light (cool/warm), textures, depth of field
- camera: moves per shot (push/orbit/track), angles, hard cuts on jolts vs dissolves
- captions: words per caption, font weight, colour, outline, position (% height)
- sound: music style + where it stops, SFX density, ambience
"""
open(f'{out}/report.md', 'w').write(rep); print(rep)
