#!/usr/bin/env python3
"""Final check of a rendered Short. usage: python tools/qa.py out/final.mp4 [--expect-dur 58.4]
Checks: 1080x1920 (9:16), 30 fps, duration = timing.js DURATION_S, an audio stream, loudness -14 LUFS (+-1) and true peak <= -1 dBTP,
no black frames (blackdetect), no frozen picture > 0.6 s (freezedetect), cut rhythm (scene changes per minute),
captions fit the frame (<= 16 characters), first caption at t=0. Prints PASS/WARN/FAIL lines and a summary."""
import subprocess, sys, json, re, os
f = sys.argv[1]; res = []
def run(*a): return subprocess.run(a, capture_output=True, text=True)
def ok(c, m): res.append(('PASS' if c else 'FAIL', m))
def warn(c, m): res.append(('PASS' if c else 'WARN', m))
p = json.loads(run('ffprobe', '-v', 'error', '-show_streams', '-show_format', '-of', 'json', f).stdout)
v = [s for s in p['streams'] if s['codec_type'] == 'video'][0]; a = [s for s in p['streams'] if s['codec_type'] == 'audio']
dur = float(p['format']['duration'])
ok((v['width'], v['height']) == (1080, 1920), f"size {v['width']}x{v['height']} (want 1080x1920)")
ok(v['r_frame_rate'] in ('30/1', '30000/1000'), f"fps {v['r_frame_rate']}")
try:
    tj = open('src/timing.js').read(); D = float(re.search(r'DURATION_S=([0-9.]+)', tj).group(1))
    ok(abs(dur - D) < 0.1, f"duration {dur:.2f}s vs timing {D:.2f}s")
    caps = json.loads(re.search(r'export const CAPTIONS=(\[.*?\]);', tj).group(1))
    longest = max(caps, key=lambda c: len(c['t'])); ok(len(longest['t']) <= 16, f"longest caption '{longest['t']}' ({len(longest['t'])} chars, max 16 to stay inside the frame)")
    ok(caps[0]['s'] <= 0.05, f"first caption at {caps[0]['s']}s (hook captioned from frame 0)")
except Exception as e: res.append(('WARN', f'timing.js not read: {e}'))
ok(bool(a), 'audio stream present')
if a:
    r = run('ffmpeg', '-hide_banner', '-i', f, '-af', 'ebur128=peak=true', '-f', 'null', '-').stderr
    I = float(r[r.rindex('I:') + 2:].split('LUFS')[0]); TP = float(r[r.rindex('Peak:') + 5:].split('dBFS')[0])
    ok(abs(I + 14) <= 1.0, f'loudness {I:.1f} LUFS (want -14)'); ok(TP <= 0.0, f'true peak {TP:.1f} dBTP (no clipping)'); warn(TP <= -1.0, f'true peak {TP:.1f} dBTP after AAC (target <= -1)')
r = run('ffmpeg', '-hide_banner', '-i', f, '-vf', 'blackdetect=d=0.1:pix_th=0.06', '-an', '-f', 'null', '-').stderr
blacks = re.findall(r'black_start:([0-9.]+)', r); ok(not blacks, f'black frames: {blacks[:5] if blacks else "none"}')
r = run('ffmpeg', '-hide_banner', '-i', f, '-vf', 'freezedetect=n=0.002:d=0.6', '-an', '-f', 'null', '-').stderr
fr = re.findall(r'freeze_start: ([0-9.]+)', r); warn(not fr, f'frozen picture >0.6 s at: {fr[:5] if fr else "none"} (camera must always move)')
r = run('ffmpeg', '-hide_banner', '-i', f, '-vf', "select='gt(scene,0.30)',showinfo", '-an', '-f', 'null', '-').stderr
cuts = [float(x) for x in re.findall(r'pts_time:([0-9.]+)', r)]; cpm = len(cuts) / dur * 60
warn(8 <= cpm <= 45, f'{len(cuts)} visual cuts = {cpm:.0f}/min (WW1 reference style ~25-30/min: many setups, hard cuts on jolts)')
for s, m in res: print(f'{s:4}  {m}')
print('SUMMARY', 'FAIL' if any(s == 'FAIL' for s, _ in res) else ('WARN' if any(s == 'WARN' for s, _ in res) else 'PASS'))
