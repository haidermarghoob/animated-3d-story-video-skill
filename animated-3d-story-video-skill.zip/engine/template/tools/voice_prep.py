#!/usr/bin/env python3
"""Turn the voice-over file(s) the user sent (any format, one file or one per block, in order) into public/voiceover.wav:
joins the files, trims the head/tail, shortens long pauses (> --max-gap) and, if the read is slow, speeds it up
(pitch-preserving atempo, max x1.25) so the video keeps a fast pace instead of being stretched to a slow voice.
usage: python tools/voice_prep.py in1.wav [in2.mp3 ...] --script script.json [--target 4.2] [--max-gap 0.2] [--out public/voiceover.wav]
Prints words/second before and after. The WW1 reference reads at ~4.3 words/s with ~0.1-0.2 s gaps."""
import argparse, json, subprocess, os, numpy as np, wave
ap = argparse.ArgumentParser(); ap.add_argument('inputs', nargs='+'); ap.add_argument('--script'); ap.add_argument('--target', type=float, default=4.2)
ap.add_argument('--min-wps', type=float, default=3.9); ap.add_argument('--max-gap', type=float, default=0.2); ap.add_argument('--out', default='public/voiceover.wav')
A = ap.parse_args(); SR = 48000
def load(p):
    r = subprocess.run(['ffmpeg', '-v', 'error', '-i', p, '-ac', '1', '-ar', str(SR), '-f', 's16le', '-'], capture_output=True, check=True).stdout
    return np.frombuffer(r, np.int16).astype(np.float32) / 32768
def trim(x, th=0.02):
    e = np.abs(x); idx = np.where(e > th * e.max())[0]
    return x[max(0, idx[0] - int(0.03 * SR)): idx[-1] + int(0.12 * SR)] if len(idx) else x
parts = [trim(load(p)) for p in A.inputs]; gap = np.zeros(int(0.1 * SR), np.float32)
x = np.concatenate([np.concatenate([p, gap]) for p in parts])[:-len(gap)]
# shorten pauses: 10 ms frames, silent = below -40 dB of the loud level
fr = int(0.01 * SR); n = len(x) // fr; rms = np.sqrt((x[:n * fr].reshape(n, fr) ** 2).mean(1) + 1e-12)
silent = rms < np.percentile(rms, 95) * 0.03; keep = np.ones(n, bool); run = 0; maxf = int(A.max_gap / 0.01)
for i in range(n):
    run = run + 1 if silent[i] else 0
    if run > maxf: keep[i] = False
y = x[:n * fr].reshape(n, fr)[keep].reshape(-1)
words = sum(len(s['text'].split()) for s in json.load(open(A.script))) if A.script else None
d0 = len(x) / SR; d1 = len(y) / SR
print(f'input {d0:.2f}s -> pauses shortened {d1:.2f}s' + (f'  ({words / d1:.2f} words/s)' if words else ''))
tmp = '/tmp/_vp.wav'
with wave.open(tmp, 'wb') as w: w.setnchannels(1); w.setsampwidth(2); w.setframerate(SR); w.writeframes((np.clip(y, -1, 1) * 32767).astype(np.int16).tobytes())
af = 'highpass=f=70,acompressor=threshold=-20dB:ratio=3:attack=8:release=120:makeup=2'
if words and words / d1 < A.min_wps:
    k = min(1.25, A.target / (words / d1)); af = f'atempo={k:.3f},' + af; print(f'slow read: speeding up x{k:.3f} -> {words / (d1 / k):.2f} words/s')
os.makedirs(os.path.dirname(A.out) or '.', exist_ok=True)
subprocess.run(['ffmpeg', '-v', 'error', '-y', '-i', tmp, '-af', af + ',loudnorm=I=-16:TP=-1.5:LRA=9', '-ar', str(SR), '-ac', '1', A.out], check=True)
d2 = float(subprocess.check_output(['ffprobe', '-v', 'error', '-show_entries', 'format=duration', '-of', 'csv=p=0', A.out]))
print(f'wrote {A.out} {d2:.2f}s' + (f'  {words / d2:.2f} words/s' if words else ''))
