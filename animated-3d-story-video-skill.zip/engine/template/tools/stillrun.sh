#!/usr/bin/env bash
# Stills check: bundle once, render half-scale stills of the given frames, tile them into out/sheet_<tag>.jpg.
# usage: tools/stillrun.sh <tag> [chars] frame1 frame2 ...      (run detached; poll out/stills.done)
#   e.g. setsid nohup tools/stillrun.sh look chars 0 45 120 > /dev/null 2>&1 &
cd "$(dirname "$0")/.."
tag=$1; shift
mkdir -p out; rm -f out/st_*.png out/stills.done
npx remotion bundle src/index.jsx --out-dir build > out/bundle.log 2>&1 || { echo BUNDLE_FAIL > out/stills.done; exit 1; }
node tools/stills.mjs build 0.5 "$@" > out/stills.log 2>&1
ls out/st_*.png >/dev/null 2>&1 && .venv/bin/python tools/sheet.py out/sheet_$tag.jpg $(ls out/st_*.png) >> out/stills.log 2>&1
echo DONE > out/stills.done
