#!/usr/bin/env python3
"""Download the CC0 assets listed in assets.json from Poly Haven into public/assets/ and write public/assets/manifest.json.
usage: python tools/fetch_assets.py [assets.json]
  hdri     {key: id}  -> public/assets/hdri/<id>_1k.hdr          (image-based lighting + reflections; A.hdr[key])
  sky      {key: id}  -> public/assets/hdri/<id>_sky.jpg         (visible photo sky, *_puresky HDRIs only; A.sky[key])
  textures [id]       -> public/assets/tex/<id>_{diff,nor,rough}.jpg (1k PBR sets; pbr(id, {...}))
  models   [id]       -> public/assets/models/<id>/<id>.gltf (+bin, textures) (1k glTF props; placeModel(id, {h}))
  trees    [id]       -> assets_src/models/<id>/ (heavy; bake to impostor PNGs, never load in the video)
  water    true       -> public/assets/tex/waternormals.jpg (three.js repo, MIT)
Poly Haven needs a browser-like User-Agent (HTTP 403 otherwise). Big source files stay in assets_src/ (not bundled).
Safe to re-run: files already downloaded are skipped. A failed id is reported and skipped (the render tolerates it)."""
import json, os, sys, urllib.request
from PIL import Image
Image.MAX_IMAGE_PIXELS = None
op = urllib.request.build_opener(); op.addheaders = [('User-Agent', 'Mozilla/5.0 (3d-story-video asset fetch)')]; urllib.request.install_opener(op)
ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..')
CFG = json.load(open(sys.argv[1] if len(sys.argv) > 1 else os.path.join(ROOT, 'assets.json')))
P = os.path.join(ROOT, 'public', 'assets'); SRC = os.path.join(ROOT, 'assets_src')
ok = {'hdri': {}, 'sky': {}, 'textures': [], 'models': [], 'impostors': CFG.get('impostors', []), 'water': False}; bad = []
def get(url, out):
    if os.path.exists(out) and os.path.getsize(out) > 0: return
    os.makedirs(os.path.dirname(out), exist_ok=True); tmp = out + '.part'
    urllib.request.urlretrieve(url, tmp); os.replace(tmp, out); print('got', os.path.relpath(out, ROOT), os.path.getsize(out), flush=True)
_cache = {}
def files(i):
    if i not in _cache: _cache[i] = json.load(urllib.request.urlopen('https://api.polyhaven.com/files/' + i, timeout=60))
    return _cache[i]
def tryit(kind, i, fn):
    try: fn(); return True
    except Exception as e: bad.append(f'{kind} {i}: {e}'); print('FAILED', kind, i, e, flush=True); return False
for k, i in CFG.get('hdri', {}).items():
    if tryit('hdri', i, lambda: get(files(i)['hdri']['1k']['hdr']['url'], f'{P}/hdri/{i}_1k.hdr')): ok['hdri'][k] = i
def sky(i):
    tm = f'{SRC}/{i}_tm.jpg'; get(files(i)['tonemapped']['url'], tm); out = f'{P}/hdri/{i}_sky.jpg'
    if not os.path.exists(out):  # keep zenith .. -11.25 deg, 6144 wide
        im = Image.open(tm).convert('RGB'); Wd = 6144; im = im.resize((Wd, Wd // 2), Image.LANCZOS); im.crop((0, 0, Wd, Wd // 4 + Wd // 32)).save(out, quality=88)
for k, i in CFG.get('sky', {}).items():
    if tryit('sky', i, lambda: sky(i)): ok['sky'][k] = i
def tex(i):
    d = files(i); n = 0
    for key, s in [('Diffuse', 'diff'), ('nor_gl', 'nor'), ('Rough', 'rough')]:
        if key in d: get(d[key]['1k']['jpg']['url'], f'{P}/tex/{i}_{s}.jpg'); n += 1
    if not n: raise RuntimeError('no 1k jpg maps (is it a texture id?)')
for i in CFG.get('textures', []):
    if tryit('texture', i, lambda: tex(i)): ok['textures'].append(i)
def gltf(i, base):
    g = files(i)['gltf']['1k']['gltf']; get(g['url'], f'{base}/{i}.gltf')
    for rel, v in g.get('include', {}).items(): get(v['url'], f'{base}/{rel}')
for i in CFG.get('models', []):
    if tryit('model', i, lambda: gltf(i, f'{P}/models/{i}')): ok['models'].append(i)
for i in CFG.get('trees', []): tryit('tree', i, lambda: gltf(i, f'{SRC}/models/{i}'))
if CFG.get('water'):
    if tryit('water', 'waternormals', lambda: get('https://raw.githubusercontent.com/mrdoob/three.js/r170/examples/textures/waternormals.jpg', f'{P}/tex/waternormals.jpg')): ok['water'] = True
os.makedirs(P, exist_ok=True); json.dump(ok, open(f'{P}/manifest.json', 'w'), indent=1)
print('manifest:', json.dumps({k: (len(v) if isinstance(v, (list, dict)) else v) for k, v in ok.items()}))
print('FAILED:', bad if bad else 'none'); print('ALLDONE')
