#!/usr/bin/env python3
"""Word timings from the real voice-over (faster-whisper, CPU), snapped to the script's own words.
usage: python tools/words.py public/voiceover.wav words.json [--script script.json] [--model base.en] [--lang en]
  - English: model base.en (fast) or small.en (better). Other languages (Urdu/Hindi narration): --model small --lang ur|hi
  - With --script, the recognised words are aligned to the script text (difflib), so captions use the script's spelling
    and every script word gets a time (unmatched ones are interpolated).
Output: {"words":[{"t","s","e"}], "sent":[{"text","s","e"}]}"""
import argparse, json, re, difflib
ap = argparse.ArgumentParser(); ap.add_argument('audio'); ap.add_argument('out'); ap.add_argument('--script'); ap.add_argument('--model', default='base.en'); ap.add_argument('--lang', default=None)
A = ap.parse_args()
import subprocess, numpy as np
from faster_whisper import WhisperModel
# decode with ffmpeg ourselves (16 kHz mono float) - avoids PyAV version issues inside faster-whisper
pcm = subprocess.run(['ffmpeg', '-v', 'error', '-i', A.audio, '-ac', '1', '-ar', '16000', '-f', 's16le', '-'], capture_output=True, check=True).stdout
audio = np.frombuffer(pcm, np.int16).astype(np.float32) / 32768.0
m = WhisperModel(A.model, device='cpu', compute_type='int8')
lang = A.lang or ('en' if A.model.endswith('.en') else None)
segs, info = m.transcribe(audio, word_timestamps=True, language=lang, vad_filter=False, beam_size=5)
R = [{'t': w.word.strip(), 's': round(w.start, 3), 'e': round(w.end, 3)} for s in segs for w in (s.words or []) if w.word.strip()]
norm = lambda x: re.sub(r"[^a-z0-9']", '', x.lower())
sent = []
if A.script:
    S = json.load(open(A.script)); toks = []; sid = []
    for k, s in enumerate(S):
        for tok in s['text'].split(): toks.append(tok); sid.append(k)
    a = [norm(x['t']) for x in R]; b = [norm(x) for x in toks]
    times = [None] * len(toks)
    for blk in difflib.SequenceMatcher(None, a, b, autojunk=False).get_matching_blocks():
        for j in range(blk.size): times[blk.b + j] = (R[blk.a + j]['s'], R[blk.a + j]['e'])
    # interpolate gaps
    known = [i for i, x in enumerate(times) if x]
    if not known: raise SystemExit('alignment failed: no script word recognised (wrong --lang/--model?)')
    for i in range(len(toks)):
        if times[i]: continue
        p = max([k for k in known if k < i], default=None); n = min([k for k in known if k > i], default=None)
        if p is None: s0 = max(0.0, times[n][0] - 0.25 * (n - i)); times[i] = (s0, s0 + 0.2)
        elif n is None: s0 = times[p][1] + 0.22 * (i - p - 1); times[i] = (s0, s0 + 0.2)
        else:
            ps, pe = times[p]; ns_, ne = times[n]; f0 = (i - p) / (n - p); f1 = (i - p + 1) / (n - p)
            times[i] = (round(pe + (ns_ - pe) * f0, 3), round(pe + (ns_ - pe) * f1, 3))
    W = [{'t': toks[i], 's': round(times[i][0], 3), 'e': round(max(times[i][1], times[i][0] + 0.05), 3)} for i in range(len(toks))]
    for k, s in enumerate(S):
        idx = [i for i in range(len(toks)) if sid[i] == k]
        if idx: sent.append({'text': s['text'], 's': W[idx[0]]['s'], 'e': W[idx[-1]]['e']})
    print('matched', len(known), 'of', len(toks), 'script words')
else:
    W = R
dur = W[-1]['e'] if W else 0
print('words', len(W), 'speech end', dur, 'wps', round(len(W) / max(0.1, dur - W[0]['s']), 2) if W else 0)
json.dump({'words': W, 'sent': sent}, open(A.out, 'w'), indent=0)
