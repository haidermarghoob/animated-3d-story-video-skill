// Render single frames with ONE shared browser (10-25 s per still on CPU instead of ~90 s via the CLI).
// usage: node tools/stills.mjs <bundleDir> <scale> [chars] frame1 frame2 ...   -> out/st_<frame>.png (+ out/chars3d.png)
import { renderStill, selectComposition, openBrowser } from '@remotion/renderer';
const gl = process.env.GL || 'swangle';
let [bundle, scale, ...frames] = process.argv.slice(2);
const browser = await openBrowser('chrome', { chromiumOptions: { gl } });
const log = (l) => { if (l.type === 'error' || /ERR|FAIL|rror|MISSING/.test(l.text)) console.log('BLOG', l.text.slice(0, 600)); };
if (frames[0] === 'chars') {
  frames.shift();
  const cc = await selectComposition({ serveUrl: bundle, id: 'Chars3D', puppeteerInstance: browser, timeoutInMilliseconds: 180000 });
  const t0 = Date.now(); await renderStill({ serveUrl: bundle, composition: cc, frame: 0, output: `out/chars3d.png`, scale: 1, puppeteerInstance: browser, chromiumOptions: { gl }, timeoutInMilliseconds: 180000, onBrowserLog: log });
  console.log('chars done', (Date.now() - t0) / 1000);
}
if (frames.length) {
  const comp = await selectComposition({ serveUrl: bundle, id: 'Story', puppeteerInstance: browser, timeoutInMilliseconds: 180000 });
  for (const f of frames) {
    const t0 = Date.now();
    try {
      await renderStill({ serveUrl: bundle, composition: comp, frame: Number(f), output: `out/st_${String(f).padStart(4, '0')}.png`, scale: Number(scale), puppeteerInstance: browser, chromiumOptions: { gl }, timeoutInMilliseconds: 180000, onBrowserLog: log });
      console.log('done', f, (Date.now() - t0) / 1000);
    } catch (e) { console.log('ERR', f, e.message.slice(0, 2000)); }
  }
}
await browser.close({ silent: true });
process.exit(0);
