# Final mix: voice (master) + SFX/ambience bed (~17.5 LU under the voice, ducked under speech)
#            + music (~19 LU under the voice, ducked 4 dB more under speech; silent at the twist stop).
# Writes  <out>.wav (voice + SFX + music) and <out>_nomusic.wav (voice + SFX), both -14 LUFS integrated,
# true peak <= -1 dBTP, exactly --dur seconds long (the video length).
#   python audio/mix.py --voice public/voiceover.wav --bed audio/sfx_bed.wav --music audio/music_raw.wav --dur 58.4 --out audio/final_mix
# Optional: --bed-lu 17.5 --music-lu 19 (dB under the voice; bigger = quieter), --no-music
import argparse, subprocess, sys, os
import numpy as np
from scipy import signal
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from dsp import SR, ns, read_wav, write_wav, lp

ap = argparse.ArgumentParser()
ap.add_argument('--voice', required=True); ap.add_argument('--bed'); ap.add_argument('--music'); ap.add_argument('--dur', type=float, required=True)
ap.add_argument('--out', default='audio/final_mix'); ap.add_argument('--bed-lu', type=float, default=17.5); ap.add_argument('--music-lu', type=float, default=19.0)
ap.add_argument('--no-music', action='store_true')
A = ap.parse_args(); N = ns(A.dur)

def rd(p):
    x, sr = read_wav(p); x = np.atleast_2d(np.asarray(x, float))
    if x.shape[0] > x.shape[1]: x = x.T
    if sr != SR: x = signal.resample_poly(x, SR, sr, axis=-1)
    if x.shape[0] == 1: x = np.concatenate([x, x])
    out = np.zeros((2, N)); out[:, :min(N, x.shape[1])] = x[:, :N]; return out

def lufs(x):
    write_wav('/tmp/_lufs.wav', x, bits=24)
    r = subprocess.run(['ffmpeg', '-hide_banner', '-i', '/tmp/_lufs.wav', '-af', 'ebur128', '-f', 'null', '-'], capture_output=True, text=True).stderr
    try: return float(r[r.rindex('I:') + 2:].split('LUFS')[0])
    except Exception: return -70.0

def to_wav(p):  # accept mp3/m4a/ogg too
    if p.lower().endswith('.wav'): return p
    o = '/tmp/_in_' + os.path.basename(p) + '.wav'; subprocess.run(['ffmpeg', '-v', 'error', '-y', '-i', p, '-ar', str(SR), '-ac', '2', o], check=True); return o

V = rd(to_wav(A.voice)); v = V.mean(0); Lv = lufs(V)
env = np.sqrt(np.maximum(lp(v ** 2, 6), 0)); env = env / (env.max() + 1e-9); sp = np.clip(env * 6, 0, 1)
mix_nm = V.copy(); parts = {'voice': Lv}
if A.bed and os.path.exists(A.bed):
    bed = rd(A.bed); Lb = lufs(bed)
    if Lb > -69: bedm = bed * 10 ** ((Lv - A.bed_lu - Lb) / 20) * (1 - 0.35 * sp); mix_nm = mix_nm + bedm; parts['bed'] = lufs(bedm)
mix = mix_nm.copy()
if A.music and os.path.exists(A.music) and not A.no_music:
    mus = rd(A.music); Lm = lufs(mus)
    if Lm > -69: musm = mus * 10 ** ((Lv - A.music_lu - Lm) / 20) * 10 ** (-4.0 * sp / 20); mix = mix + musm; parts['music'] = lufs(musm)
print('in-mix LUFS', {k: round(x, 1) for k, x in parts.items()})

def master(x, out):
    L = lufs(x); y = x * 10 ** ((-14.0 - L) / 20)
    tp = 10 ** (-1.6 / 20); a = np.abs(y); k = tp * 0.85   # soft-knee limiter to keep true peak under -1 dBTP
    y = np.sign(y) * np.where(a > k, k + (tp - k) * np.tanh((a - k) / (tp - k)), a)
    f = ns(0.004); y[:, :f] *= np.linspace(0, 1, f); y[:, -f:] *= np.linspace(1, 0, f)
    write_wav(out, y, bits=16)
    r = subprocess.run(['ffmpeg', '-hide_banner', '-i', out, '-af', 'ebur128=peak=true', '-f', 'null', '-'], capture_output=True, text=True).stderr
    I = float(r[r.rindex('I:') + 2:].split('LUFS')[0]); P = r[r.rindex('Peak:') + 5:].split('dBFS')[0].strip()
    print(out, 'I', I, 'LUFS  TP', P, 'dBFS')

master(mix, A.out + '.wav')
master(mix_nm, A.out + '_nomusic.wav')
