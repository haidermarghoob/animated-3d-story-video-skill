# Per-story sound design (TEMPLATE - rewrite the CUES block for each video).
# Reads the voice word timings (words.json), places SFX on the on-screen actions, builds a low ambience bed,
# and writes the story score (music cuts out at the biggest twist, ~1 s silence, then a bass hit).
#   .venv/bin/python audio/make_audio.py            -> audio/sfx_bed.wav, audio/music_raw.wav, audio/cues_used.json
# Then: .venv/bin/python audio/mix.py --voice public/voiceover.wav --bed audio/sfx_bed.wav --music audio/music_raw.wav --dur <DURATION_S>
import os, sys, json, re
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
from sfx import *            # Bed + every generator
from music import score
from dsp import write_wav, ns

ROOT = os.path.dirname(HERE)
W = json.load(open(os.path.join(ROOT, 'words.json')))['words']
src = open(os.path.join(ROOT, 'src', 'timing.js')).read()
DUR = float(re.search(r'DURATION_S=([0-9.]+)', src).group(1))
def wt(word, approx=0.0):
    """start time of `word` (lowercase, no punctuation) nearest to approx seconds"""
    best = None
    for x in W:
        ww = re.sub(r"[^a-z0-9']", '', x['t'].lower())
        if ww == word and (best is None or abs(x['s'] - approx) < abs(best - approx)): best = x['s']
    if best is None: print('WORD MISSING', word); return approx
    return best

bed = Bed(DUR)
# ===================== CUES (demo story; replace per video) =====================
# Rule of thumb: one SFX on every visible action, ON the frame it happens (word time + small offset);
# a whoosh 0.2-0.3 s before every dissolve; a hit/impact on every 'hard' cut; nothing loud under key words.
T = dict(every=wt('everyone', 1.9), but=wt('but', 3.2), magnet=wt('magnet', 4.4), gone=wt('gone', 5.2))
bed.put(cash_register(), 0.35, 0.6, -0.2, 'cash register (hook)')
bed.put(coins(0.8), T['every'] + 0.1, 0.5, 0.3, 'coins (crowd buys)')
bed.put(impact(weight=0.8), T['but'], 0.8, 0, 'hard cut hit')
bed.put(whoosh_soft(), T['gone'] - 0.25, 0.5, 0, 'dissolve whoosh')
for i in range(5): bed.put(ping(f0=1500 + i * 90), T['gone'] + i * 0.04, 0.25, 0.3, 'bars fly' if i == 0 else None)
bed.put(boing(), T['gone'] + 0.4, 0.3)
# ambience: continuous, low, fitted to the place (street -> city + light crowd)
bed.add_loop(city(DUR) * 0.6 + crowd_murmur(DUR) * 0.8, 1.0)
TWIST = T['but']             # the biggest turn of the story: music stops here
SECTIONS = [(0, T['but'], 'sly'), (T['but'], DUR, 'triumph')]
# ================================================================================
bed.save(os.path.join(HERE, 'sfx_bed.wav'))
mus = score(DUR, SECTIONS, stops=[TWIST], gap=min(1.0, max(0.4, (DUR - TWIST) * 0.3)), bpm=108, seed=3, loop=True)
write_wav(os.path.join(HERE, 'music_raw.wav'), mus[:, :ns(DUR)])
json.dump(bed.cues, open(os.path.join(HERE, 'cues_used.json'), 'w'), indent=0)
print('audio ok: dur', DUR, 'cues', len(bed.cues), 'twist', round(TWIST, 2))
