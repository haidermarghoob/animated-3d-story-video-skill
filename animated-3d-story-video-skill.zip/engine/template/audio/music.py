# Procedural background score (numpy + scipy, no samples, no licences). 48 kHz stereo.
# The music follows the story in sections, and CUTS OUT at the biggest twist: music stops dead, ~1 s of silence,
# then a sub-bass hit and the music comes back (the "khamoshi -> jhatka" moment).
#
#   from music import score
#   mus = score(DUR, sections=[(0, 12.4, 'sly'), (12.4, 40.0, 'tense'), (40.0, DUR, 'triumph')],
#               stops=[t_twist], bpm=108, seed=3, loop=True)
#   write_wav('audio/music_raw.wav', mus)
#
# moods: 'sly' (sneaky pizzicato, the schemer), 'tense' (low pulse + drone), 'day' (light bouncy), 'night' (cool, sparse),
#        'action' (driving), 'triumph' (bright resolve), 'calm' (soft pad only).
# stops: list of times; the music is silent from t to t+gap (default 1.0 s) and a bass hit lands at t+gap.
# loop=True: the tail crossfades into the head so the Short loops without a bump.
import numpy as np
from dsp import SR, ns, rng, lp, hp, bp, fades, st, pan

def _m(n): return 440.0 * 2 ** ((n - 69) / 12)

MOODS = {
    #           chords (MIDI roots + triads)                          instruments
    'sly':     dict(prog=[[57, 60, 64], [57, 60, 64], [53, 57, 60], [52, 56, 59]], pizz=1, bass=1, kick=0.6, hat=0.5, pad=0.2),
    'tense':   dict(prog=[[50, 53, 57], [50, 53, 57], [46, 50, 53], [45, 49, 52]], pulse=1, bass=1, kick=0.8, hat=0.3, pad=0.5, drone=1),
    'day':     dict(prog=[[60, 64, 67], [57, 60, 64], [53, 57, 60], [55, 59, 62]], pizz=0.8, bass=1, kick=0.7, hat=0.6, clap=0.5, pad=0.3),
    'night':   dict(prog=[[57, 60, 64], [53, 57, 60], [48, 52, 55], [55, 59, 62]], pluck=0.6, bass=0.7, kick=0.3, pad=0.6),
    'action':  dict(prog=[[50, 53, 57], [46, 50, 53], [48, 52, 55], [45, 49, 52]], pulse=1, bass=1.2, kick=1.0, hat=0.8, clap=0.7, pad=0.4),
    'triumph': dict(prog=[[53, 57, 60], [55, 59, 62], [60, 64, 67], [60, 64, 67]], pluck=0.8, bass=1, kick=0.8, hat=0.6, clap=0.6, pad=0.6),
    'calm':    dict(prog=[[60, 64, 67], [57, 60, 64], [53, 57, 60], [55, 59, 62]], pad=0.8, pluck=0.3),
}

def _adsr(n, a, d, s, r):
    A, D, R = ns(a), ns(d), ns(r); S = max(0, n - A - D - R)
    e = np.concatenate([np.linspace(0, 1, A, False), np.linspace(1, s, D, False), np.full(S, s), np.linspace(s, 0, R)])
    return np.pad(e, (0, max(0, n - len(e))))[:n]

def _saw(f, n, r, detune=0.0):
    t = np.arange(n) / SR; ph = r.random()
    return 2 * ((f * (1 + detune) * t + ph) % 1.0) - 1

def score(dur, sections, stops=(), gap=1.0, bpm=108, seed=1, loop=True, hit=True):
    r = rng(seed); N = ns(dur); out = np.zeros((2, N)); beat = 60.0 / bpm; bar = beat * 4
    def mood_at(t):
        for a, b, m in sections:
            if a <= t < b: return MOODS[m]
        return MOODS[sections[-1][2]]
    def add(x, t, g=1.0, p=0.0):
        i = ns(t); x = pan(x, p) if x.ndim == 1 else x; a, b = max(0, i), min(N, i + x.shape[1])
        if b > a: out[:, a:b] += g * x[:, a - i:b - i]
    nb = int(np.ceil(dur / bar)) + 1
    for k in range(nb):
        t0 = k * bar; M = mood_at(t0 + 0.01); ch = M['prog'][k % 4]; root = ch[0] - 24
        # pad (detuned saws through a low-pass)
        if M.get('pad'):
            n = ns(bar + 0.3); x = sum(_saw(_m(c), n, r, d) for c in ch for d in (-0.004, 0.004)) / 6
            add(lp(x, 900) * _adsr(n, 0.25, 0.3, 0.8, 0.3) * M['pad'] * 0.35, t0, 1.0, 0)
        if M.get('drone'):
            n = ns(bar + 0.2); x = _saw(_m(root + 12), n, r) + _saw(_m(root + 19), n, r, 0.003)
            add(lp(x, 300) * _adsr(n, 0.3, 0.1, 1, 0.2) * 0.25, t0)
        for b8 in range(8):  # eighth notes
            tb = t0 + b8 * beat / 2
            if tb >= dur: break
            if M.get('pizz') and b8 % 2 == 0 or (M.get('pizz') and b8 in (3, 7) and r.random() < 0.5):
                f = _m(ch[(b8 // 2) % 3] + (12 if b8 >= 4 else 0)); n = ns(0.25); tt_ = np.arange(n) / SR
                x = (np.sin(2 * np.pi * f * tt_) + 0.3 * np.sin(4 * np.pi * f * tt_)) * np.exp(-tt_ / 0.07)
                add(x * 0.28 * M['pizz'], tb, 1.0, (b8 % 3 - 1) * 0.4)
            if M.get('pluck'):
                f = _m(ch[b8 % 3] + 12); n = ns(0.5); tt_ = np.arange(n) / SR
                x = lp(_saw(f, n, r), 2500) * np.exp(-tt_ / 0.18)
                add(x * 0.12 * M['pluck'], tb, 1.0, 0.3 if b8 % 2 else -0.3)
            if M.get('pulse'):
                f = _m(root + 24); n = ns(beat / 2 * 0.9); x = lp(_saw(f, n, r), 700) * _adsr(n, 0.005, 0.05, 0.6, 0.05)
                add(x * 0.2 * M['pulse'], tb)
            if M.get('hat') and b8 % 2 == 1:
                n = ns(0.06); add(hp(r.standard_normal(n), 7000) * np.exp(-np.arange(n) / SR / 0.012) * 0.12 * M['hat'], tb, 1.0, 0.2)
        for b4 in range(4):  # quarter notes
            tb = t0 + b4 * beat
            if tb >= dur: break
            if M.get('bass') and b4 in (0, 2):
                f = _m(root + 12); n = ns(beat * 1.6); tt_ = np.arange(n) / SR
                x = (np.sin(2 * np.pi * f * tt_) + 0.25 * lp(_saw(f, n, r), 400)) * _adsr(n, 0.01, 0.2, 0.5, 0.15)
                add(x * 0.35 * M['bass'], tb)
            if M.get('kick') and b4 in (0, 2):
                n = ns(0.3); tt_ = np.arange(n) / SR
                add(np.sin(2 * np.pi * np.cumsum(50 + 90 * np.exp(-tt_ / 0.03)) / SR) * np.exp(-tt_ / 0.12) * 0.45 * M['kick'], tb)
            if M.get('clap') and b4 in (1, 3):
                n = ns(0.15); add(bp(r.standard_normal(n), 900, 4000) * np.exp(-np.arange(n) / SR / 0.03) * 0.18 * M['clap'], tb)
    # stops: dead silence for `gap`, then a sub hit
    for ts in stops:
        a, b = ns(ts), min(N, ns(ts + gap)); f = ns(0.012)
        if a < N:
            out[:, max(0, a - f):a] *= np.linspace(1, 0, min(f, a))
            out[:, a:b] = 0
            if b < N: out[:, b:min(N, b + ns(0.4))] *= np.linspace(0, 1, min(N, b + ns(0.4)) - b)
            if hit and b < N:
                tt_ = np.arange(ns(2.2)) / SR
                h = np.tanh(1.6 * np.sin(2 * np.pi * np.cumsum(46 * (1 + 1.5 * np.exp(-tt_ / 0.04))) / SR) * np.exp(-tt_ / 0.8))
                add(h * 0.9, ts + gap)
    out = lp(out, 9000)
    if loop:  # crossfade the last 0.6 s into the first 0.6 s so the Short loops cleanly
        L = ns(0.6); head = out[:, :L].copy(); w = np.linspace(0, 1, L)
        out[:, -L:] = out[:, -L:] * (1 - w) + head * w
    return fades(out / (np.abs(out).max() + 1e-9) * 0.9, 0.01 if not loop else 0.0, 0.01 if not loop else 0.0)
