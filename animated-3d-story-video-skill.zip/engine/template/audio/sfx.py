# Procedural sound effects (numpy + scipy only, no samples, no licences needed). 48 kHz.
# Every generator returns a mono float array (or stereo (2, n)). Place them on a Bed timed to the voice words.
#
#   from sfx import *            (run from the project's audio/ folder, or sys.path.insert(0, 'audio'))
#   bed = Bed(DUR)
#   bed.put(whoosh(), t_cut - 0.25, 0.5)            # whoosh into every dissolve / big move
#   bed.put(impact(), t_word, 0.9)                  # hits land ON the word / on-screen action frame
#   bed.add_loop(wind(DUR), 0.5)                    # continuous low ambience fitted to the place
#   bed.save('audio/sfx_bed.wav')
#
# Ambience: wind, rain, room_tone, city, crowd_murmur, fire_crackle, sea.
# One-shots: whoosh, whoosh_soft, swish, impact, thud, punch, bass_hit, boom_far, explosion, rifle, ricochet, ping,
#   dirt, pop, click, ding, cash_register, coins, paper_flutter, phone_ring, footsteps, boing, glass_break, riser,
#   whistle_fall, engine_pass, typing, splash, beep.
import numpy as np
from dsp import SR, ns, tt, rng, lp, hp, bp, fades, phase, pan, st, write_wav, make_ir, convolve_st, shape

__all__ = [n for n in dir() if not n.startswith('_')]


class Bed:
    """A stereo SFX/ambience track of fixed length."""
    def __init__(self, dur):
        self.dur = dur; self.N = ns(dur); self.x = np.zeros((2, self.N))
        self.cues = []

    def put(self, x, t, g=1.0, p=0.0, name=None):
        x = np.asarray(x, float)
        if x.ndim == 1: x = pan(x, p)
        i = ns(t); a, b = max(0, i), min(self.N, i + x.shape[1])
        if b > a: self.x[:, a:b] += g * x[:, a - i:b - i]
        if name: self.cues.append((round(t, 3), name))

    def add_loop(self, x, g=1.0):
        x = st(x); n = min(self.N, x.shape[1]); self.x[:, :n] += g * x[:, :n]

    def save(self, path, peak=0.9):
        y = self.x / (np.abs(self.x).max() + 1e-9) * peak
        write_wav(path, y); return y


def _n(r, n): return r.standard_normal(n)

# ------------------------------------------------------------------ ambience (long, continuous)
def wind(dur, seed=1, strength=1.0):
    r = rng(seed); N = ns(dur)
    x = lp(_n(r, N), 380) * 0.35 + lp(_n(r, N), 120) * 0.25
    return x * (0.75 + 0.25 * np.sin(np.arange(N) / SR * 0.35)) * strength

def rain(dur, seed=2, heavy=0.5):
    r = rng(seed); N = ns(dur)
    x = hp(_n(r, N), 1800) * 0.25 + bp(_n(r, N), 300, 2500) * 0.15 * heavy
    drops = (r.random(N) < 0.0015 * (1 + heavy)) * r.random(N)
    return x + bp(drops, 2000, 9000) * 1.5

def room_tone(dur, seed=3):
    r = rng(seed); N = ns(dur); t = np.arange(N) / SR
    return lp(_n(r, N), 200) * 0.2 + np.sin(2 * np.pi * 60 * t) * 0.01

def city(dur, seed=4):
    r = rng(seed); N = ns(dur)
    x = lp(_n(r, N), 500) * 0.3
    for k in range(int(dur / 4)):  # distant car passes
        c = engine_pass(3.0, seed + k) * 0.25; i = ns(k * 4 + r.random() * 2)
        if i + len(c) < N: x[i:i + len(c)] += c
    return x

def crowd_murmur(dur, seed=5, size=1.0):
    r = rng(seed); N = ns(dur); x = np.zeros(N)
    for v in range(10):
        f = 110 + r.random() * 120; env = np.clip(lp(_n(r, N), 3) * 40, 0, 1)
        x += bp(_n(r, N), f * 2, f * 8) * env * 0.12
    return x * size

def fire_crackle(dur, seed=6):
    r = rng(seed); N = ns(dur)
    return lp(_n(r, N), 300) * 0.1 + bp((r.random(N) < 0.0012) * _n(r, N), 1500, 6000) * 2.0

def sea(dur, seed=7):
    r = rng(seed); N = ns(dur); t = np.arange(N) / SR
    return lp(_n(r, N), 600) * (0.4 + 0.35 * np.sin(2 * np.pi * t / 6.5) ** 2)

# ------------------------------------------------------------------ transitions / movement
def whoosh(dur=0.55, seed=11, bright=1.0):
    r = rng(seed); t = tt(dur); n = len(t)
    env = np.sin(np.pi * np.clip(t / dur, 0, 1)) ** 2
    def gain(tf, f):  # band-pass whose centre sweeps up and back down over the whoosh
        fc = 400 + 2600 * bright * np.sin(np.pi * np.clip(tf / dur, 0, 1))
        return np.exp(-0.5 * (np.log2((f[:, None] + 1) / fc[None, :]) / 0.8) ** 2)
    x = shape(_n(r, n), gain)
    return fades(x * env / (np.abs(x).max() + 1e-9), 0.01, 0.05)

def whoosh_soft(dur=0.45, seed=12): return lp(whoosh(dur, seed, 0.6), 3500) * 0.8
def swish(seed=13): return whoosh(0.22, seed, 1.3)

def riser(dur=1.5, seed=14):
    r = rng(seed); t = tt(dur); u = t / dur
    x = bp(_n(r, len(t)), 500, 6000) * u ** 2 + np.sin(phase(200 + 900 * u ** 2)) * 0.25 * u
    return fades(x, 0.05, 0.02)

# ------------------------------------------------------------------ hits
def impact(seed=21, weight=1.0):
    r = rng(seed); t = tt(0.9)
    sub = np.sin(phase(55 * (1 + 2 * np.exp(-t / 0.02)))) * np.exp(-t / 0.18) * weight
    crack = bp(_n(r, len(t)), 800, 6000) * np.exp(-t / 0.015)
    return fades(sub + crack * 0.7, 0.0005, 0.1)

def thud(seed=22): t = tt(0.5); r = rng(seed); return fades(np.sin(phase(70 * (1 + np.exp(-t / 0.02)))) * np.exp(-t / 0.08) + lp(_n(r, len(t)), 600) * np.exp(-t / 0.03) * 0.5, 0.0005, 0.05)
def punch(seed=23): t = tt(0.35); r = rng(seed); return fades(bp(_n(r, len(t)), 200, 3000) * np.exp(-t / 0.03) + np.sin(phase(90 * (1 + np.exp(-t / 0.01)))) * np.exp(-t / 0.06), 0.0005, 0.05)

def bass_hit(seed=24, f0=48):
    """the 'silence -> BOOM' hit for the biggest twist (pairs with music.score(stops=[t]))"""
    r = rng(seed); t = tt(2.6)
    sub = np.sin(phase(f0 * (1 + 1.5 * np.exp(-t / 0.04)))) * np.exp(-t / 0.9)
    click = hp(_n(r, len(t)), 2000) * np.exp(-t / 0.004) * 0.4
    body = lp(_n(r, len(t)), 180) * np.exp(-t / 0.4) * 0.5
    return fades(np.tanh((sub * 1.3 + click + body) * 1.5), 0.0005, 0.4)

def boom_far(seed=25):
    r = rng(seed); t = tt(2.5)
    return fades(lp(_n(r, len(t)), 160) * np.exp(-t / 0.7) * 2 + np.sin(phase(38 * (1 + 0.5 * np.exp(-t / 0.08)))) * np.exp(-t / 0.5), 0.01, 0.4)

def explosion(seed=26):
    r = rng(seed); t = tt(3.5)
    sub = np.sin(phase(42 * (1 + 1.2 * np.exp(-t / 0.05)))) * np.exp(-t / 0.5)
    body = lp(_n(r, len(t)), 900) * np.exp(-t / 0.6) * 1.2 + lp(_n(r, len(t)), 250) * np.exp(-t / 1.4)
    crack = hp(_n(r, len(t)), 1500) * np.exp(-t / 0.03) * 0.8
    x = sub * 1.4 + body + crack
    y = convolve_st(st(x), make_ir(2.2, 9, hf=0.5))[:, :len(t)]
    return fades(st(x) * 0.8 + y * 0.5, 0.001, 0.5)

def rifle(dist=0.0, seed=27):
    r = rng(seed); t = tt(0.9)
    crack = bp(_n(r, len(t)), 900, 7000) * np.exp(-t / 0.012)
    thump = np.sin(phase(70 * (1 + 1.5 * np.exp(-t / 0.01)))) * np.exp(-t / 0.07)
    x = crack * (1.0 - 0.6 * dist) + thump * 0.8
    if dist > 0: x = lp(x, 6000 - 4500 * dist)
    y = convolve_st(st(x), make_ir(1.4, 3, hf=0.6))[:, :len(t) + ns(1.2)]
    out = np.zeros_like(y); out[:, :len(x)] += st(x) * (1 - 0.5 * dist)
    return fades(out + y * (0.35 + 0.5 * dist), 0.001, 0.2)

def ricochet(seed=28):
    r = rng(seed); t = tt(0.55); f = 3200 * np.exp(-t / 0.35) + 700
    x = np.sin(phase(f)) * np.exp(-t / 0.25) * 0.5 + bp(_n(r, len(t)), 2000, 8000) * np.exp(-t / 0.01) * 0.6
    return fades(x, 0.001, 0.08)

def ping(seed=29, f0=1350):
    r = rng(seed); t = tt(1.2); x = np.zeros(len(t))
    for m, a, d in [(1, 1, 0.5), (2.76, 0.6, 0.3), (5.4, 0.35, 0.18), (8.93, 0.2, 0.1)]: x += a * np.sin(2 * np.pi * f0 * m * t) * np.exp(-t / d)
    return fades((x + bp(_n(r, len(t)), 3000, 10000) * np.exp(-t / 0.006) * 0.8) * 0.6, 0.0005, 0.1)

def dirt(seed=30):
    r = rng(seed); t = tt(0.6)
    return fades(lp(_n(r, len(t)), 1800) * np.exp(-t / 0.05) + np.sin(phase(55 * (1 + np.exp(-t / 0.02)))) * np.exp(-t / 0.06) * 0.6, 0.001, 0.1)

def glass_break(seed=31):
    r = rng(seed); t = tt(1.2); x = hp(_n(r, len(t)), 3000) * np.exp(-t / 0.05)
    for k in range(25):
        t0 = r.random() * 0.6; f = 2500 + r.random() * 6000; m = t > t0
        x[m] += np.sin(2 * np.pi * f * (t[m] - t0)) * np.exp(-(t[m] - t0) / 0.03) * 0.3
    return fades(x, 0.0005, 0.1)

def splash(seed=32):
    r = rng(seed); t = tt(1.0)
    return fades(bp(_n(r, len(t)), 300, 5000) * np.exp(-t / 0.18) + lp(_n(r, len(t)), 400) * np.exp(-t / 0.08), 0.002, 0.1)

# ------------------------------------------------------------------ small / comic
def pop(seed=41): t = tt(0.12); return fades(np.sin(phase(900 * np.exp(-t / 0.02) + 300)) * np.exp(-t / 0.025), 0.0005, 0.02)
def click(seed=42): r = rng(seed); t = tt(0.05); return fades(bp(_n(r, len(t)), 2000, 8000) * np.exp(-t / 0.004), 0.0002, 0.01)
def beep(f=1000, dur=0.15): t = tt(dur); return fades(np.sign(np.sin(2 * np.pi * f * t)) * 0.3, 0.003, 0.01)

def ding(f0=1568.0, seed=43):
    t = tt(1.6); x = sum(a * np.sin(2 * np.pi * f0 * m * t) * np.exp(-t / d) for m, a, d in [(1, 1, 0.9), (2.0, 0.4, 0.5), (3.0, 0.2, 0.3), (4.2, 0.1, 0.2)])
    return fades(x * 0.5, 0.001, 0.2)

def cash_register(seed=44):
    x = np.zeros(ns(1.4)); a = click(seed); x[:len(a)] += a; b = ding(2093.0); x[ns(0.12):ns(0.12) + len(b)] += b[:len(x) - ns(0.12)]
    c = coins(0.5, seed); x[ns(0.25):ns(0.25) + len(c)] += c[:len(x) - ns(0.25)] * 0.6
    return x

def coins(dur=1.0, seed=45):
    r = rng(seed); t = tt(dur); x = np.zeros(len(t))
    for k in range(int(dur * 14)):
        t0 = r.random() * dur * 0.8; f = 3000 + r.random() * 3000; m = t > t0
        x[m] += np.sin(2 * np.pi * f * (t[m] - t0)) * np.exp(-(t[m] - t0) / 0.05) * 0.2
    return fades(x, 0.001, 0.05)

def paper_flutter(dur=1.2, seed=46):
    r = rng(seed); t = tt(dur)
    return fades(bp(_n(r, len(t)), 1500, 7000) * (0.4 + 0.6 * np.abs(np.sin(2 * np.pi * 9 * t + r.random() * 3))) * 0.3, 0.05, 0.2)

def phone_ring(rings=2, seed=47):
    out = []
    for _ in range(rings):
        t = tt(1.0); x = np.sin(2 * np.pi * 440 * t) + np.sin(2 * np.pi * 480 * t)
        x *= (np.sin(2 * np.pi * 20 * t) > 0); out += [x * 0.25, np.zeros(ns(0.6))]
    return fades(np.concatenate(out), 0.005, 0.02)

def footsteps(n=4, rate=2.2, seed=48, surface='hard'):
    r = rng(seed); step = ns(1 / rate); x = np.zeros(step * n + ns(0.3))
    for k in range(n):
        t = tt(0.18); f = 160 + r.random() * 20
        s = np.sin(2 * np.pi * f * t) * np.exp(-t / 0.03) + bp(_n(r, len(t)), 400 if surface == 'hard' else 150, 3000) * np.exp(-t / 0.02) * 0.6
        x[k * step:k * step + len(t)] += s * (0.8 + 0.2 * r.random())
    return x

def boing(seed=49): t = tt(0.6); return fades(np.sin(phase(220 + 160 * np.sin(2 * np.pi * 9 * t) * np.exp(-t / 0.25))) * np.exp(-t / 0.3) * 0.5, 0.001, 0.05)
def whistle_fall(dur=0.8): t = tt(dur); return fades(np.sin(phase(2600 - 1500 * t / dur)) * 0.25 * np.clip(t / 0.1, 0, 1), 0.01, 0.05)

def engine_pass(dur=2.6, seed=50, f0=95):
    r = rng(seed); t = tt(dur)
    f = f0 * (1.08 - 0.16 / (1 + np.exp(-(t - dur * 0.45) * 4)))
    x = sum(np.sin(phase(f * k)) / k for k in range(1, 9)) + lp(_n(r, len(t)), 1200) * 0.25
    return fades(lp(x, 2500) * np.exp(-((t - dur * 0.45) / (dur * 0.33)) ** 2), 0.05, 0.3)

def typing(dur=1.5, seed=51):
    r = rng(seed); x = np.zeros(ns(dur)); k = 0.0
    while k < dur - 0.05:
        c = click(seed + int(k * 100)); i = ns(k); x[i:i + len(c)] += c * (0.5 + 0.5 * r.random()); k += 0.06 + r.random() * 0.1
    return x

__all__ = [n for n in dir() if not n.startswith('_') and n not in ('np',)]
