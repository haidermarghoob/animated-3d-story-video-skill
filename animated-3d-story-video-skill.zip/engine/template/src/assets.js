// CC0 assets (Poly Haven HDRIs, PBR texture sets, glTF props, baked impostors) loaded once before the scene mounts.
// What to load comes from public/assets/manifest.json, written by `python3 tools/fetch_assets.py` from ../assets.json.
// Every load is fault-tolerant: a missing file is logged and skipped, so a render never dies on one asset
// (pbr() falls back to a plain colour, placeModel() to an empty group).
import * as THREE from 'three';
import { staticFile } from 'remotion';
import { RGBELoader } from 'three/examples/jsm/loaders/RGBELoader.js';
import { GLTFLoader } from 'three/examples/jsm/loaders/GLTFLoader.js';

export const A = { ready: false, hdr: {}, sky: {}, tex: {}, imp: {}, models: {}, sunDir: {}, missing: [] };
const F = (p) => staticFile('assets/' + p);

let _p = null;
export function loadAssets() {
  if (_p) return _p;
  _p = fetch(F('manifest.json')).then((r) => (r.ok ? r.json() : {})).catch(() => ({})).then((man) => {
    const HDR = man.hdri || {}, SKY = man.sky || {}, TEX = man.textures || [], MODELS = man.models || [], IMP = man.impostors || [];
    const tl = new THREE.TextureLoader(), rl = new RGBELoader(), gl = new GLTFLoader();
    const miss = (what) => (e) => { A.missing.push(what); console.warn('ASSET MISSING', what, e && e.message); };
    const tex = (url, srgb, repeat = true) => new Promise((res, rej) => tl.load(url, (t) => {
      t.colorSpace = srgb ? THREE.SRGBColorSpace : THREE.NoColorSpace;
      if (repeat) { t.wrapS = t.wrapT = THREE.RepeatWrapping; }
      t.anisotropy = 4; res(t);
    }, undefined, rej));
    const jobs = [];
    for (const [k, n] of Object.entries(HDR)) jobs.push(new Promise((res, rej) => rl.load(F(`hdri/${n}_1k.hdr`), (t) => { t.mapping = THREE.EquirectangularReflectionMapping; A.hdr[k] = t; A.sunDir[k] = brightestDir(t); res(); }, undefined, rej)).catch(miss('hdri ' + n)));
    for (const [k, n] of Object.entries(SKY)) jobs.push(tex(F(`hdri/${n}_sky.jpg`), true, false).then((t) => { t.wrapS = THREE.RepeatWrapping; t.wrapT = THREE.ClampToEdgeWrapping; t.anisotropy = 1; t.generateMipmaps = true; A.sky[k] = t; }).catch(miss('sky ' + n)));
    for (const n of TEX) {
      A.tex[n] = {};
      jobs.push(tex(F(`tex/${n}_diff.jpg`), true).then((t) => { A.tex[n].map = t; }).catch(miss('tex ' + n)));
      jobs.push(tex(F(`tex/${n}_nor.jpg`), false).then((t) => { A.tex[n].normal = t; }).catch(() => {}));
      jobs.push(tex(F(`tex/${n}_rough.jpg`), false).then((t) => { A.tex[n].rough = t; }).catch(() => {}));
    }
    if (IMP.length) jobs.push(fetch(F('imp/meta.json')).then((r) => r.json()).then((meta) => Promise.all(IMP.map((n) => tex(F(`imp/${n}.png`), true, false).then((t) => { t.anisotropy = 2; A.imp[n] = { tex: t, aspect: meta[n].aspect }; }).catch(miss('imp ' + n))))).catch(miss('imp/meta.json')));
    for (const n of MODELS) jobs.push(new Promise((res, rej) => gl.load(F(`models/${n}/${n}.gltf`), (g) => { A.models[n] = g.scene; res(); }, undefined, rej)).catch(miss('model ' + n)));
    if (man.water) jobs.push(tex(F('tex/waternormals.jpg'), false).then((t) => { A.tex.water = { normal: t }; }).catch(miss('waternormals')));
    return Promise.all(jobs).then(() => { A.ready = true; if (A.missing.length) console.warn('ASSETS MISSING:', A.missing.join(', ')); return A; });
  });
  return _p;
}

// direction of the sun in an equirect HDR (brightest texel), used to rotate the sky so it matches the key light
function brightestDir(t) {
  const { data, width, height } = t.image; let best = -1, bi = 0;
  const half = t.type === THREE.HalfFloatType;
  const rd = (i) => (half ? THREE.DataUtils.fromHalfFloat(data[i]) : data[i]);
  const stride = data.length / (width * height);
  for (let y = 0; y < height / 2; y++) for (let x = 0; x < width; x++) {
    const i = (y * width + x) * stride; const l = rd(i) * 0.2126 + rd(i + 1) * 0.7152 + rd(i + 2) * 0.0722;
    if (l > best) { best = l; bi = y * width + x; }
  }
  const x = bi % width, y = Math.floor(bi / width);
  const u = (x + 0.5) / width, v = (y + 0.5) / height;
  const phi = (u - 0.5) * Math.PI * 2, th = v * Math.PI;
  return { u, v, phi, th, lum: best };
}

// clone a glTF scene, enable shadows, return a group normalised so its base sits at y=0 and its height = h (if given)
export function placeModel(name, o = {}) {
  const src = A.models[name]; if (!src) return new THREE.Group();
  const g = src.clone(true);
  g.traverse((m) => { if (m.isMesh) { m.castShadow = o.cast ?? true; m.receiveShadow = true; if (m.material && o.envI !== undefined) m.material.envMapIntensity = o.envI; } });
  const wrap = new THREE.Group(); wrap.add(g);
  if (o.h) {
    const b = new THREE.Box3().setFromObject(g); const s = b.getSize(new THREE.Vector3());
    const k = o.h / s.y; g.scale.setScalar(k); g.position.y = -b.min.y * k;
  }
  return wrap;
}

// PBR material from a downloaded texture set (plain colour if the set is missing)
export function pbr(name, o = {}) {
  const t = A.tex[name] || {};
  const rep = o.repeat || [1, 1];
  const cl = (x) => { if (!x) return null; const c = x.clone(); c.repeat.set(rep[0], rep[1]); c.needsUpdate = true; return c; };
  const m = new THREE.MeshStandardMaterial({
    color: new THREE.Color(o.color || '#ffffff'), map: cl(t.map), normalMap: o.noNormal ? null : cl(t.normal), roughnessMap: cl(t.rough),
    roughness: o.rough ?? 1, metalness: o.metal ?? 0, envMapIntensity: o.envI ?? 1,
  });
  if (m.normalMap) m.normalScale.set(o.ns ?? 1, o.ns ?? 1);
  return m;
}
