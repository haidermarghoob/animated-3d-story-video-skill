// v4: real 3D characters in the house design (white sphere head, bean torso, tapered tube limbs, oval feet,
// disc hands, hats/hair/mustache as meshes or projected decals), black screen-space inverted-hull outlines,
// soft PBR shading from the scene key light + rim light, cast + contact shadows. Faces are crisp black line art
// drawn on a canvas and projected onto the front of the head; expressions switch on the words as before.
import * as THREE from 'three';
import { INK_HEX } from './kit';
import { drawFace, hairCap, drawProp, torsoPath, drawTorsoFill, CHAR_LIGHT } from './chars';

export { CHAR_LIGHT };
const INK = new THREE.Color(INK_HEX);
const PX = 1 / 512; // one canvas pixel of the old 512-px figure in body units

// ---------- shared uniforms (set once per frame from world.update) ----------
export const CHAR_U = {
  uRim: { value: new THREE.Color(1, 1, 1) }, uRimAmt: { value: 0.3 }, uCap: { value: 1.0 },
  uRes: { value: new THREE.Vector2(720, 1280) }, uLinePx: { value: 5.2 },
};
export function syncCharLight() {
  CHAR_U.uRim.value.copy(CHAR_LIGHT.rim); CHAR_U.uRimAmt.value = CHAR_LIGHT.rimAmt;
}

// ---------- outline: back-face hull pushed out in screen space (constant pixel width, thinner far away) ----------
const outlineMat = new THREE.ShaderMaterial({
  uniforms: THREE.UniformsUtils.merge([THREE.UniformsLib.fog, { uCol: { value: INK.clone() } }]),
  vertexShader: `#include <common>
#include <fog_pars_vertex>
uniform vec2 uRes; uniform float uLinePx;
void main(){
  vec4 mvPosition = modelViewMatrix * vec4(position, 1.0);
  vec4 clip = projectionMatrix * mvPosition;
  vec3 vn = normalize(normalMatrix * normal);
  vec2 dir = (projectionMatrix * vec4(vn, 0.0)).xy; float dl = length(dir); dir = dl > 1e-5 ? dir / dl : vec2(0.0);
  float px = uLinePx * (uRes.y / 1280.0) * clamp(3.2 / max(-mvPosition.z, 0.05), 0.55, 1.7);
  clip.xy += dir * px * 2.0 / uRes * clip.w;
  clip.z += 0.0004 * clip.w;
  gl_Position = clip;
  #include <fog_vertex>
}`,
  fragmentShader: `#include <common>
#include <fog_pars_fragment>
uniform vec3 uCol;
void main(){ gl_FragColor = vec4(uCol, 1.0);
#include <fog_fragment>
}`,
  side: THREE.BackSide, fog: true,
});
outlineMat.uniforms.uRes = CHAR_U.uRes; outlineMat.uniforms.uLinePx = CHAR_U.uLinePx;

// ---------- character surface material: PBR + rim light + cap (heads never bloom) + optional front decal ----------
// decal: map holds a canvas projected along +z of the object; front faces get it, back faces get the edge colour
function charMat(color, o = {}) {
  const m = new THREE.MeshStandardMaterial({ color: new THREE.Color(color), roughness: o.rough ?? 0.48, metalness: 0, envMapIntensity: o.env ?? 0.55 });
  if (o.map) m.map = o.map;
  m.onBeforeCompile = (sh) => {
    sh.uniforms.uRim = CHAR_U.uRim; sh.uniforms.uRimAmt = CHAR_U.uRimAmt; sh.uniforms.uCap = CHAR_U.uCap;
    sh.vertexShader = sh.vertexShader.replace('#include <common>', '#include <common>\nvarying float vObjNz;')
      .replace('#include <begin_vertex>', '#include <begin_vertex>\nvObjNz = normal.z;');
    let frag = sh.fragmentShader.replace('#include <common>', '#include <common>\nuniform vec3 uRim; uniform float uRimAmt; uniform float uCap; varying float vObjNz;');
    if (o.map) {
      const decal = o.decal === 'overlay'
        ? `{ vec4 fc = texture2D(map, vMapUv); float fr = smoothstep(0.02, 0.32, vObjNz); diffuseColor.rgb = mix(diffuseColor.rgb, fc.rgb, fc.a * fr); }`
        : `{ vec4 fc = texture2D(map, vMapUv); vec4 bc = texture2D(map, vec2(0.012, vMapUv.y)); diffuseColor.rgb *= mix(bc.rgb, fc.rgb, smoothstep(-0.12, 0.3, vObjNz)); }`;
      frag = frag.replace('#include <map_fragment>', decal);
    }
    frag = frag.replace('#include <opaque_fragment>', `{
      vec3 Vv = normalize(vViewPosition);
      float rimF = pow(1.0 - clamp(dot(normal, Vv), 0.0, 1.0), 3.0);
      outgoingLight += uRim * uRimAmt * rimF;
      outgoingLight = min(outgoingLight, vec3(uCap));
    }
    #include <opaque_fragment>`);
    sh.fragmentShader = frag;
  };
  m.customProgramCacheKey = () => 'char' + (o.map ? (o.decal || 'mul') : 'plain');
  return m;
}
const inkSurf = new THREE.MeshStandardMaterial({ color: INK.clone(), roughness: 0.3, metalness: 0, envMapIntensity: 0.9 });

function withOutline(geo, mat, parent, cast = true) {
  const m = new THREE.Mesh(geo, mat); m.castShadow = cast; m.receiveShadow = true; parent.add(m);
  const o = new THREE.Mesh(geo, outlineMat); o.castShadow = false; parent.add(o);
  return m;
}
const _geo = {};
const G = (k, f) => (_geo[k] || (_geo[k] = f()));

// ---------- tapered tube (limb) updated in place each frame ----------
class Limb {
  constructor(parent, segs = 10, rad = 7) {
    this.segs = segs; this.rad = rad;
    const n = (segs + 1) * rad;
    this.geo = new THREE.BufferGeometry();
    this.geo.setAttribute('position', new THREE.BufferAttribute(new Float32Array(n * 3), 3));
    this.geo.setAttribute('normal', new THREE.BufferAttribute(new Float32Array(n * 3), 3));
    const idx = [];
    for (let i = 0; i < segs; i++) for (let j = 0; j < rad; j++) {
      const a = i * rad + j, b = i * rad + (j + 1) % rad, c = (i + 1) * rad + j, d = (i + 1) * rad + (j + 1) % rad;
      idx.push(a, c, b, b, c, d);
    }
    this.geo.setIndex(idx);
    this.mesh = new THREE.Mesh(this.geo, inkSurf); this.mesh.castShadow = true; this.mesh.frustumCulled = false; parent.add(this.mesh);
    this.cap0 = new THREE.Mesh(G('capS', () => new THREE.SphereGeometry(1, 8, 6)), inkSurf); this.cap1 = this.cap0.clone();
    this.cap0.castShadow = this.cap1.castShadow = true; parent.add(this.cap0, this.cap1);
  }
  set(p0, p1, p2, r0, r1) { // quadratic bezier p0 -> p1 (control) -> p2, radius r0 -> r1
    const P = this.geo.attributes.position.array, N = this.geo.attributes.normal.array;
    const pt = new THREE.Vector3(), tg = new THREE.Vector3(), nA = new THREE.Vector3(), nB = new THREE.Vector3(), tmp = new THREE.Vector3();
    let k = 0;
    for (let i = 0; i <= this.segs; i++) {
      const t = i / this.segs, a = 1 - t;
      pt.set(a * a * p0.x + 2 * a * t * p1.x + t * t * p2.x, a * a * p0.y + 2 * a * t * p1.y + t * t * p2.y, a * a * p0.z + 2 * a * t * p1.z + t * t * p2.z);
      tg.set(2 * a * (p1.x - p0.x) + 2 * t * (p2.x - p1.x), 2 * a * (p1.y - p0.y) + 2 * t * (p2.y - p1.y), 2 * a * (p1.z - p0.z) + 2 * t * (p2.z - p1.z)).normalize();
      tmp.set(0, 0, 1); if (Math.abs(tg.z) > 0.9) tmp.set(1, 0, 0);
      nA.crossVectors(tg, tmp).normalize(); nB.crossVectors(tg, nA).normalize();
      const r = r0 + (r1 - r0) * t;
      for (let j = 0; j < this.rad; j++) {
        const ang = j / this.rad * Math.PI * 2, c = Math.cos(ang), s = Math.sin(ang);
        const nx = nA.x * c + nB.x * s, ny = nA.y * c + nB.y * s, nz = nA.z * c + nB.z * s;
        P[k * 3] = pt.x + nx * r; P[k * 3 + 1] = pt.y + ny * r; P[k * 3 + 2] = pt.z + nz * r;
        N[k * 3] = nx; N[k * 3 + 1] = ny; N[k * 3 + 2] = nz; k++;
      }
    }
    this.geo.attributes.position.needsUpdate = true; this.geo.attributes.normal.needsUpdate = true;
    this.cap0.position.copy(p0); this.cap0.scale.setScalar(r0); this.cap1.position.copy(p2); this.cap1.scale.setScalar(r1);
  }
}

// ---------- body geometry ----------
const TORSO_Y0 = 0.465, TORSO_Y1 = 0.95, TORSO_C = (TORSO_Y0 + TORSO_Y1) / 2;
function torsoGeo() {
  return G('torso', () => {
    // bean/pear profile from the 2D path (radius vs height), lathed, flattened front-to-back
    const prof = [[0.0, 0.0], [0.07, 0.006], [0.13, 0.025], [0.175, 0.06], [0.196, 0.12], [0.194, 0.2], [0.18, 0.28], [0.155, 0.36], [0.12, 0.43], [0.075, 0.47], [0.0, 0.487]];
    const pts = prof.map(([r, y]) => new THREE.Vector2(r, y));
    const g = new THREE.LatheGeometry(pts, 28);
    g.scale(1, 1, 0.68); g.translate(0, TORSO_Y0 - TORSO_C, 0);
    g.computeVertexNormals();
    // front projection UV into the torso canvas (old figure px: x cx±110, y 476..744)
    const pos = g.attributes.position, uv = new Float32Array(pos.count * 2);
    for (let i = 0; i < pos.count; i++) {
      const x = pos.getX(i), y = pos.getY(i) + TORSO_C;
      const px = x / PX + 110, py = 1024 - (y + 0.05) / PX - 476;
      uv[i * 2] = px / 220; uv[i * 2 + 1] = 1 - py / 268;
    }
    g.setAttribute('uv', new THREE.BufferAttribute(uv, 2));
    return g;
  });
}
const HR = 150 * PX; // head radius (body units)
function headGeo() {
  return G('head', () => {
    const g = new THREE.SphereGeometry(HR, 40, 28);
    const pos = g.attributes.position, uv = g.attributes.uv;
    for (let i = 0; i < pos.count; i++) uv.setXY(i, pos.getX(i) / (2.4 * HR) + 0.5, pos.getY(i) / (2.4 * HR) + 0.5);
    return g;
  });
}

// ---------- hats as meshes ----------
function buildHat(sp, grp) {
  const r = HR, hc = sp.hatColor || '#f2c230';
  const gloss = charMat(hc, { rough: 0.28, env: 0.9 });
  const add = (geo, mat, x = 0, y = 0, z = 0, rx = 0, ry = 0, rz = 0, sx = 1, sy = 1, sz = 1) => {
    const h = new THREE.Group(); h.position.set(x, y, z); h.rotation.set(rx, ry, rz); h.scale.set(sx, sy, sz); grp.add(h); withOutline(geo, mat, h); return h;
  };
  const dome = (rx, ry, rz) => new THREE.SphereGeometry(1, 28, 14, 0, Math.PI * 2, 0, Math.PI / 2).scale(rx, ry, rz);
  if (sp.hat === 'hardhat') {
    add(dome(r * 1.0, r * 0.82, r * 1.0), gloss, 0, r * 0.42, 0);
    add(new THREE.CylinderGeometry(r * 1.2, r * 1.22, r * 0.12, 32), gloss, 0, r * 0.42, r * 0.06);
    add(new THREE.BoxGeometry(r * 0.16, r * 0.12, r * 1.6), gloss, 0, r * 1.15, 0, 0, 0, 0, 1, 1, 1).scale.set(1, 1, 1);
  } else if (sp.hat === 'bowler') {
    add(dome(r * 0.84, r * 0.86, r * 0.84), gloss, 0, r * 0.62, 0);
    add(new THREE.CylinderGeometry(r * 0.85, r * 0.86, r * 0.17, 28), charMat(sp.band || '#6a3a42', { rough: 0.5 }), 0, r * 0.7, 0);
    add(new THREE.TorusGeometry(r * 1.02, r * 0.12, 8, 32).rotateX(Math.PI / 2), gloss, 0, r * 0.6, 0, 0, 0, 0, 1, 0.8, 1);
    add(new THREE.CylinderGeometry(r * 1.06, r * 1.06, r * 0.05, 32), gloss, 0, r * 0.6, 0);
  } else if (sp.hat === 'fedora') {
    add(new THREE.CylinderGeometry(r * 0.66, r * 0.84, r * 0.66, 28), gloss, 0, r * 0.95, 0);
    add(dome(r * 0.66, r * 0.16, r * 0.66), gloss, 0, r * 1.27, 0);
    add(new THREE.CylinderGeometry(r * 0.83, r * 0.85, r * 0.18, 28), charMat(sp.band || '#3a2a2a', { rough: 0.5 }), 0, r * 0.74, 0);
    add(new THREE.CylinderGeometry(r * 1.34, r * 1.38, r * 0.06, 36), gloss, 0, r * 0.64, 0, 0.06, 0, 0);
  } else if (sp.hat === 'cap' || sp.hat === 'rainhat') {
    const rain = sp.hat === 'rainhat';
    let capMat = gloss;
    if (sp.capStripes) capMat = charMat('#ffffff', { rough: 0.4, map: stripeTex(hc, sp.capStripes), decal: 'mul' });
    add(dome(r * 1.01, r * (rain ? 0.74 : 0.7), r * 1.01), capMat, 0, r * 0.45, 0);
    if (rain) add(new THREE.CylinderGeometry(r * 1.0, r * 1.38, r * 0.3, 32, 1, true), gloss, 0, r * 0.36, 0);
    else {
      const bill = new THREE.CylinderGeometry(r * 0.72, r * 0.72, r * 0.07, 24, 1, false, -Math.PI / 2, Math.PI);
      add(bill, gloss, 0, r * 0.47, r * 0.62, 0.12, 0, 0, 1, 1, 0.75);
      add(new THREE.SphereGeometry(r * 0.08, 10, 8), gloss, 0, r * 1.15, 0);
    }
    if (sp.capBadge) {
      const sh = new THREE.Shape(); for (let k = 0; k < 10; k++) { const a = -Math.PI / 2 + k * Math.PI / 5, rr = (k % 2 ? 0.4 : 1) * r * 0.16; k ? sh.lineTo(Math.cos(a) * rr, -Math.sin(a) * rr) : sh.moveTo(Math.cos(a) * rr, -Math.sin(a) * rr); }
      add(new THREE.ExtrudeGeometry(sh, { depth: r * 0.04, bevelEnabled: false }), charMat('#ffd23a', { rough: 0.25, env: 1.2 }), 0, r * 0.82, r * 0.72, -0.5);
    }
  } else if (sp.hat === 'bicorne') {
    // naval bicorne: a crescent worn side to side, gold edge trim, red/white cockade on the front
    const sh = new THREE.Shape(); const w = r * 1.55, hh = r * 0.95;
    sh.moveTo(-w, 0); sh.quadraticCurveTo(-w * 0.75, hh * 0.85, 0, hh); sh.quadraticCurveTo(w * 0.75, hh * 0.85, w, 0); sh.quadraticCurveTo(0, hh * 0.12, -w, 0);
    const navy = charMat(sp.hatColor || '#24419e', { rough: 0.4, env: 0.7 });
    const body = new THREE.ExtrudeGeometry(sh, { depth: r * 0.5, bevelEnabled: true, bevelThickness: r * 0.12, bevelSize: r * 0.06, bevelSegments: 3, curveSegments: 24 });
    body.translate(0, 0, -r * 0.25);
    add(body, navy, 0, r * 0.62, 0);
    // gold trim along the top edge (tube on the crescent curve)
    const pts = []; for (let i = 0; i <= 40; i++) { const u = i / 40, a = 1 - u; const p0 = [-w, 0], p1 = [-w * 0.75, hh * 0.85], p2 = [0, hh], p3 = [w * 0.75, hh * 0.85], p4 = [w, 0];
      const q = u < 0.5 ? (() => { const t = u * 2, b = 1 - t; return [b * b * p0[0] + 2 * b * t * p1[0] + t * t * p2[0], b * b * p0[1] + 2 * b * t * p1[1] + t * t * p2[1]]; })() : (() => { const t = (u - 0.5) * 2, b = 1 - t; return [b * b * p2[0] + 2 * b * t * p3[0] + t * t * p4[0], b * b * p2[1] + 2 * b * t * p3[1] + t * t * p4[1]]; })();
      pts.push(new THREE.Vector3(q[0], q[1] + r * 0.62, 0)); }
    for (const z of [r * 0.34, -r * 0.34]) { const tg = new THREE.Group(); grp.add(tg); const m = new THREE.Mesh(new THREE.TubeGeometry(new THREE.CatmullRomCurve3(pts), 48, r * 0.045, 6), charMat('#f4c430', { rough: 0.25, env: 1.2 })); m.position.z = z; m.castShadow = true; tg.add(m); }
    const ck = new THREE.Group(); ck.position.set(0, r * 1.05, r * 0.4); grp.add(ck);
    withOutline(new THREE.CylinderGeometry(r * 0.2, r * 0.2, r * 0.05, 24).rotateX(Math.PI / 2), charMat('#ffffff', { rough: 0.4 }), ck);
    const ck2 = new THREE.Mesh(new THREE.CylinderGeometry(r * 0.13, r * 0.13, r * 0.06, 24).rotateX(Math.PI / 2), charMat('#d8352a', { rough: 0.4 })); ck2.position.z = r * 0.01; ck.add(ck2);
    const ck3 = new THREE.Mesh(new THREE.CylinderGeometry(r * 0.05, r * 0.05, r * 0.07, 16).rotateX(Math.PI / 2), charMat('#24419e', { rough: 0.4 })); ck3.position.z = r * 0.02; ck.add(ck3);
  } else if (sp.hat === 'chef') {
    // tall puffy toque: band + cluster of overlapping puffs
    const white = charMat('#ffffff', { rough: 0.7, env: 0.5 });
    add(new THREE.CylinderGeometry(r * 0.86, r * 0.82, r * 0.5, 32), white, 0, r * 0.82, 0);
    const puffs = [[0, 1.55, 0, 0.62], [-0.5, 1.38, 0.1, 0.48], [0.5, 1.4, 0.05, 0.5], [0.1, 1.42, 0.45, 0.46], [-0.15, 1.4, -0.42, 0.46], [0.15, 1.85, 0.05, 0.42]];
    for (const [x, y, z, s] of puffs) add(new THREE.SphereGeometry(r * s, 24, 16), white, x * r, y * r, z * r);
  } else if (sp.hat === 'tophat') {
    const blk = charMat(hc, { rough: 0.22, env: 1.1 });
    add(new THREE.CylinderGeometry(r * 0.7, r * 0.66, r * 1.05, 32), blk, 0, r * 1.18, 0);
    add(new THREE.CylinderGeometry(r * 0.7, r * 0.7, r * 0.03, 32), blk, 0, r * 1.71, 0);
    add(new THREE.CylinderGeometry(r * 0.675, r * 0.675, r * 0.2, 32), charMat(sp.band || '#e0a92a', { rough: 0.25, env: 1.3 }), 0, r * 0.78, 0);
    add(new THREE.CylinderGeometry(r * 1.18, r * 1.18, r * 0.06, 40), blk, 0, r * 0.66, 0, 0.0, 0, 0);
    add(new THREE.TorusGeometry(r * 1.18, r * 0.05, 8, 40).rotateX(Math.PI / 2), charMat(sp.band || '#e0a92a', { rough: 0.25, env: 1.3 }), 0, r * 0.67, 0);
  } else if (sp.hat === 'headset') {
    const dk = charMat('#2a2d33', { rough: 0.35, env: 0.9 });
    add(new THREE.TorusGeometry(r * 1.04, r * 0.07, 8, 32, Math.PI), dk, 0, 0, 0, 0, 0, 0);
    for (const s of [-1, 1]) add(new THREE.CylinderGeometry(r * 0.3, r * 0.3, r * 0.2, 24).rotateZ(Math.PI / 2), dk, s * r * 1.02, -r * 0.05, 0);
    const pts = [new THREE.Vector3(-r * 1.08, -r * 0.1, 0.0), new THREE.Vector3(-r * 1.0, -r * 0.55, r * 0.55), new THREE.Vector3(-r * 0.35, -r * 0.62, r * 0.98)];
    const boom = new THREE.Mesh(new THREE.TubeGeometry(new THREE.CatmullRomCurve3(pts), 16, r * 0.035, 6), dk); boom.castShadow = true; grp.add(boom);
    const mic = new THREE.Mesh(new THREE.SphereGeometry(r * 0.09, 12, 8), charMat('#111', { rough: 0.6 })); mic.position.copy(pts[2]); grp.add(mic);
  } else if (sp.hat === 'pilotcap') {
    // airline peaked cap: wide flat crown, black band, glossy black visor, gold badge + gold cord
    const navy = charMat(sp.hatColor || '#1b2440', { rough: 0.45, env: 0.7 });
    add(new THREE.CylinderGeometry(r * 1.12, r * 0.9, r * 0.42, 32), navy, 0, r * 0.98, -r * 0.04, -0.12);
    add(new THREE.CylinderGeometry(r * 0.92, r * 0.92, r * 0.26, 32), charMat('#121216', { rough: 0.5 }), 0, r * 0.7, 0, -0.12);
    const bill = new THREE.CylinderGeometry(r * 0.78, r * 0.78, r * 0.05, 24, 1, false, -Math.PI / 2, Math.PI);
    add(bill, charMat('#0c0c0e', { rough: 0.15, env: 1.4 }), 0, r * 0.6, r * 0.52, 0.28, 0, 0, 1, 1, 0.7);
    const cord = new THREE.Mesh(new THREE.TorusGeometry(r * 0.75, r * 0.03, 6, 24, Math.PI), charMat('#f2c23a', { rough: 0.25, env: 1.3 })); cord.position.set(0, r * 0.66, r * 0.52); cord.rotation.set(0.25, 0, Math.PI); cord.scale.set(1, 0.18, 1); grp.add(cord);
    add(new THREE.SphereGeometry(r * 0.16, 16, 10).scale(1.3, 1, 0.4), charMat('#f2c23a', { rough: 0.2, env: 1.4 }), 0, r * 0.98, r * 0.86, -0.3);
  } else if (sp.hat === 'helmet') {
    // racing helmet: full glossy shell (face left open), coloured stripe, dark visor pushed up
    const shell = charMat(sp.hatColor || '#d8352a', { rough: 0.18, env: 1.3 });
    add(new THREE.SphereGeometry(r * 1.1, 32, 20, 0, Math.PI * 2, 0, Math.PI * 0.56), shell, 0, r * 0.06, -r * 0.06, -0.25);
    add(new THREE.TorusGeometry(r * 1.06, r * 0.07, 8, 32, Math.PI).rotateY(Math.PI / 2), charMat(sp.band || '#ffffff', { rough: 0.3 }), 0, r * 0.2, -r * 0.05, 0, 0, 0);
    add(new THREE.CylinderGeometry(r * 1.05, r * 1.05, r * 0.28, 28, 1, true, -1.1, 2.2), charMat('#15181f', { rough: 0.08, env: 1.6 }), 0, r * 0.82, 0.0, -0.35);
  } else if (sp.hat === 'brodie') {
    // British Brodie steel helmet: shallow dome + wide flat brim, matte khaki-green paint, chin strap
    const steel = charMat(sp.hatColor || '#5d5f3a', { rough: 0.62, env: 0.6 });
    add(dome(r * 0.86, r * 0.62, r * 0.86), steel, 0, r * 0.66, -r * 0.04, -0.12);
    add(new THREE.CylinderGeometry(r * 1.42, r * 1.48, r * 0.06, 40), steel, 0, r * 0.66, -r * 0.04, -0.12);
    add(new THREE.TorusGeometry(r * 1.45, r * 0.035, 6, 40).rotateX(Math.PI / 2), charMat('#3d3f26', { rough: 0.5 }), 0, r * 0.66, -r * 0.04, -0.12);
    const strap = new THREE.Mesh(new THREE.TorusGeometry(r * 0.98, r * 0.03, 6, 32, Math.PI), charMat('#5a3e22', { rough: 0.7 }));
    strap.rotation.set(-0.15, 0, Math.PI); strap.position.set(0, r * 0.12, 0); strap.scale.set(1.04, 1.04, 1); grp.add(strap);
  } else if (sp.hat === 'stahlhelm') {
    // German M1916 Stahlhelm: deep dome, coal-scuttle flare at sides and back, short visor, lugs
    const steel = charMat(sp.hatColor || '#55604f', { rough: 0.55, env: 0.6 });
    add(new THREE.SphereGeometry(r * 1.06, 32, 16, 0, Math.PI * 2, 0, Math.PI * 0.5), steel, 0, r * 0.22, -r * 0.05, -0.18);
    add(new THREE.CylinderGeometry(r * 1.06, r * 1.32, r * 0.42, 36, 1, true, Math.PI * 0.35, Math.PI * 1.3), steel, 0, r * 0.02, -r * 0.06, -0.18);
    add(new THREE.CylinderGeometry(r * 1.06, r * 1.18, r * 0.12, 24, 1, true, -Math.PI * 0.3, Math.PI * 0.6), steel, 0, r * 0.2, r * 0.02, -0.4);
    for (const s2 of [-1, 1]) add(new THREE.CylinderGeometry(r * 0.09, r * 0.09, r * 0.14, 12).rotateZ(Math.PI / 2), charMat('#3a4036', { rough: 0.4, env: 1.0 }), s2 * r * 1.04, r * 0.55, -r * 0.05);
  } else if (sp.hat === 'officercap') {
    const kh = charMat(sp.hatColor || '#7a6a42', { rough: 0.6, env: 0.5 });
    add(new THREE.CylinderGeometry(r * 1.08, r * 0.92, r * 0.38, 32), kh, 0, r * 0.96, -r * 0.04, -0.14);
    add(new THREE.CylinderGeometry(r * 0.93, r * 0.93, r * 0.24, 32), charMat('#4a3a22', { rough: 0.6 }), 0, r * 0.7, 0, -0.14);
    const bill = new THREE.CylinderGeometry(r * 0.78, r * 0.78, r * 0.05, 24, 1, false, -Math.PI / 2, Math.PI);
    add(bill, charMat('#2a1d12', { rough: 0.2, env: 1.2 }), 0, r * 0.6, r * 0.52, 0.28, 0, 0, 1, 1, 0.7);
    add(new THREE.SphereGeometry(r * 0.13, 16, 10).scale(1.2, 1, 0.4), charMat('#d8b04a', { rough: 0.25, env: 1.3 }), 0, r * 0.95, r * 0.9, -0.3);
  } else if (sp.hat === 'goggles') {
    add(new THREE.TorusGeometry(r * 1.0, r * 0.06, 8, 40).rotateX(Math.PI / 2), charMat('#4b3b40', { rough: 0.6 }), 0, r * 0.5, 0, -0.18);
    for (const s of [-1, 1]) {
      add(new THREE.CylinderGeometry(r * 0.2, r * 0.22, r * 0.18, 20).rotateX(Math.PI / 2), charMat('#4b3b40', { rough: 0.4 }), s * r * 0.32, r * 0.58, r * 0.8, -0.35);
      const lens = new THREE.Mesh(new THREE.CircleGeometry(r * 0.17, 20), new THREE.MeshStandardMaterial({ color: '#9ad8e8', roughness: 0.05, metalness: 0.2, envMapIntensity: 1.6 }));
      lens.position.set(s * r * 0.32, r * 0.62, r * 0.9); lens.rotation.x = -0.35; grp.add(lens);
    }
  }
}
const _stripe = {};
function stripeTex(base, stripe) {
  const k = base + stripe; if (_stripe[k]) return _stripe[k];
  const c = document.createElement('canvas'); c.width = 64; c.height = 64; const g = c.getContext('2d');
  g.fillStyle = base; g.fillRect(0, 0, 64, 64); g.fillStyle = stripe; for (let x = 4; x < 64; x += 16) g.fillRect(x, 0, 6, 64);
  const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; t.wrapS = t.wrapT = THREE.RepeatWrapping; t.repeat.set(4, 1);
  return (_stripe[k] = t);
}

// ---------- the character ----------
export class Character {
  constructor(spec, o = {}) {
    this.spec = spec; this.crawl = !!o.crawl; this.scale = o.scale || 1;
    this.poseFn = o.pose || (() => ({})); this.yawBias = o.yawBias || 0;
    const s = this.scale, sp = spec;
    this.root = new THREE.Group();
    this.pivot = new THREE.Group(); this.root.add(this.pivot); // faces the camera (yaw)
    this.body = new THREE.Group(); this.body.scale.setScalar(s); this.pivot.add(this.body);
    // torso
    this.torsoCanvas = document.createElement('canvas'); this.torsoCanvas.width = 330; this.torsoCanvas.height = 402;
    { const g = this.torsoCanvas.getContext('2d'); g.save(); g.scale(330 / 220, 402 / 268); g.translate(-(256 - 110), -476); drawTorsoFill(g, sp, 256, 0, {}); g.restore(); }
    const tt = new THREE.CanvasTexture(this.torsoCanvas); tt.colorSpace = THREE.SRGBColorSpace; tt.anisotropy = 4;
    this.torso = new THREE.Group(); this.body.add(this.torso);
    withOutline(torsoGeo(), charMat('#ffffff', { rough: 0.62, map: tt, decal: 'mul' }), this.torso);
    // head
    this.head = new THREE.Group(); this.body.add(this.head);
    this.faceCanvas = document.createElement('canvas'); this.faceCanvas.width = this.faceCanvas.height = 640;
    this.faceTex = new THREE.CanvasTexture(this.faceCanvas); this.faceTex.colorSpace = THREE.SRGBColorSpace; this.faceTex.anisotropy = 8;
    this.headMesh = withOutline(headGeo(), charMat('#ffffff', { rough: 0.42, map: this.faceTex, decal: 'overlay', env: 0.5 }), this.head);
    if (sp.hair) { // flat cap of hair on the crown (the fringe is part of the face decal)
      const cap = new THREE.SphereGeometry(HR * 1.025, 28, 12, 0, Math.PI * 2, 0, Math.PI * 0.4);
      const hg = new THREE.Group(); hg.rotation.x = -0.32; this.head.add(hg);
      withOutline(cap, charMat(sp.hair, { rough: 0.55 }), hg);
    }
    this.hatG = new THREE.Group(); this.head.add(this.hatG);
    if (sp.hat && sp.hat !== 'none') buildHat(sp, this.hatG);
    // fx card in front of the head: panic lines + sweat drops that leave the head silhouette
    this.fxCanvas = document.createElement('canvas'); this.fxCanvas.width = this.fxCanvas.height = 384;
    this.fxTex = new THREE.CanvasTexture(this.fxCanvas); this.fxTex.colorSpace = THREE.SRGBColorSpace;
    this.fx = new THREE.Mesh(new THREE.PlaneGeometry(HR * 2.9, HR * 2.9), new THREE.MeshBasicMaterial({ map: this.fxTex, transparent: true, alphaTest: 0.05, depthWrite: false, fog: true }));
    this.fx.position.z = HR * 1.05; this.fx.renderOrder = 3; this.head.add(this.fx);
    // limbs, hands, feet
    this.arms = [new Limb(this.body), new Limb(this.body)];
    this.legs = [new Limb(this.body), new Limb(this.body)];
    if (sp.puttees) { const pm = new THREE.MeshStandardMaterial({ color: sp.puttees, roughness: 0.9, envMapIntensity: 0.3 }); this.puttees = [new Limb(this.body, 6, 8), new Limb(this.body, 6, 8)]; this.puttees.forEach((L) => { L.mesh.material = pm; L.cap0.material = pm; L.cap1.material = pm; }); }
    const handGeo = G('hand', () => new THREE.SphereGeometry(24 * PX, 14, 10).scale(1, 1, 0.6));
    const footGeo = G('foot', () => new THREE.SphereGeometry(1, 18, 12).scale(44 * PX, 19 * PX, 60 * PX));
    this.hands = [0, 1].map(() => { const h = new THREE.Mesh(handGeo, inkSurf); h.castShadow = true; this.body.add(h); return h; });
    this.feet = [0, 1].map(() => { const f = new THREE.Mesh(footGeo, inkSurf); f.castShadow = true; this.body.add(f); return f; });
    // prop card (2D props as before, drawn only when held)
    this.propCanvas = null;
    // contact blob
    const sh = new THREE.Mesh(new THREE.CircleGeometry(0.36 * s * (this.crawl ? 1.6 : 1), 24), new THREE.MeshBasicMaterial({ color: 0x0c0a10, transparent: true, opacity: 0.42, depthWrite: false }));
    sh.rotation.x = -Math.PI / 2; sh.position.y = 0.012; sh.scale.set(1, 0.55, 1); sh.renderOrder = 1;
    this.root.add(sh); this.shadow = sh;
    this.mesh = this.body; // compatibility
    this._faceKey = ''; this._fxKey = '';
  }
  _ensureProp() {
    if (this.propCanvas) return;
    this.propCanvas = document.createElement('canvas'); this.propCanvas.width = 768; this.propCanvas.height = 1024;
    this.propTex = new THREE.CanvasTexture(this.propCanvas); this.propTex.colorSpace = THREE.SRGBColorSpace; this.propTex.anisotropy = 4;
    const geo = new THREE.PlaneGeometry(768 * PX, 1024 * PX); geo.translate(0, 512 * PX - 0.05, 0);
    this.propMesh = new THREE.Mesh(geo, new THREE.MeshStandardMaterial({ map: this.propTex, transparent: true, alphaTest: 0.06, side: THREE.DoubleSide, roughness: 0.6, envMapIntensity: 0.5 }));
    this.propMesh.castShadow = true;
    this.propMesh.customDepthMaterial = new THREE.MeshDepthMaterial({ depthPacking: THREE.RGBADepthPacking, map: this.propTex, alphaTest: 0.5 });
    this.propMesh.position.z = 0.055; this.body.add(this.propMesh);
  }
  _drawFace(e) {
    const sp = this.spec;
    const key = JSON.stringify([e.eyes, e.brows, e.mouth, e.look, e.lookY, e.blush, sp.glasses, sp.mustache]);
    if (key !== this._faceKey) {
      this._faceKey = key;
      const g = this.faceCanvas.getContext('2d'), F = 640, k = F / (2.4 * 150);
      g.clearRect(0, 0, F, F); g.save(); g.translate(F / 2, F / 2); g.scale(k, k);
      g.save(); g.beginPath(); g.arc(0, 0, 148, 0, 7); g.clip();
      if (sp.hair) hairCap(g, 0, 0, 150, 1, sp);
      g.restore();
      drawFace(g, 0, 0, 1, { ...e, sweat: false, lines: false }, sp);
      g.restore();
      g.clearRect(0, 0, F, 3); g.clearRect(0, F - 3, F, 3); g.clearRect(0, 0, 3, F); g.clearRect(F - 3, 0, 3, F);
      this.faceTex.needsUpdate = true;
    }
    const fxKey = JSON.stringify([e.sweat, e.sweat2, e.lines, e.sweat ? Math.round((e.sweatY || 0) / 6) : 0]);
    if (fxKey !== this._fxKey) {
      this._fxKey = fxKey;
      const g = this.fxCanvas.getContext('2d'), F = 384, k = F / (2.9 * 150);
      g.clearRect(0, 0, F, F);
      if (e.sweat || e.lines) {
        g.save(); g.translate(F / 2, F / 2); g.scale(k, k);
        drawFace(g, 0, 0, 1, { eyes: 'none', brows: 'none', mouth: 'none', sweat: e.sweat, sweat2: e.sweat2, sweatY: e.sweatY, lines: e.lines }, {});
        g.restore();
      }
      this.fxTex.needsUpdate = true;
      this.fx.visible = !!(e.sweat || e.lines);
    }
  }
  update(t, cam) {
    if (!this.root.visible) return;
    const p = this.poseFn(t) || {}; p.t = t;
    const sp = this.spec, e = p.expr || {};
    this.lastPose = p; if (this.hatG) this.hatG.visible = !p.hatOff;
    this._drawFace(e);
    if (this.crawl) this._poseCrawl(p, t); else this._poseStand(p, t);
    // props
    const hasProp = !this.crawl && (p.propL || p.propR || p.propC);
    if (hasProp) {
      this._ensureProp();
      const g = this.propCanvas.getContext('2d'); g.clearRect(0, 0, 768, 1024);
      g.save(); g.translate(128, 0);
      g.translate(256, 1000); g.rotate(p.lean || 0); g.translate(-256, -1000);
      g.translate(0, -(p.jump || 0));
      const [hl, hr] = this._handPx;
      if (p.propL) drawProp(g, p.propL, hl[0], hl[1], 1, -1, t);
      if (p.propR) drawProp(g, p.propR, hr[0], hr[1], 1, 1, t);
      if (p.propC) drawProp(g, p.propC, 256, 650 + this._ty, 1, 1, t);
      g.restore();
      this.propTex.needsUpdate = true; this.propMesh.visible = true;
    } else if (this.propMesh) this.propMesh.visible = false;
    // face the camera (yaw only, in parent space)
    this.root.updateWorldMatrix(true, false);
    const inv = new THREE.Matrix4().copy(this.root.matrixWorld).invert();
    const lc = cam.position.clone().applyMatrix4(inv);
    this.pivot.rotation.y = (p.yawAbs !== undefined ? p.yawAbs : Math.atan2(lc.x, lc.z) + this.yawBias + (p.yaw || 0)) + (this.crawl ? 1.05 : 0);
    // head pitch toward the camera a little (keeps the face reading from high/low cameras)
    const hw = new THREE.Vector3(); this.head.getWorldPosition(hw);
    const dv = cam.position.clone().sub(hw); const pitch = Math.atan2(dv.y, Math.hypot(dv.x, dv.z));
    this.head.rotation.x = -Math.max(-0.45, Math.min(0.45, pitch)) * 0.55;
  }
  _poseStand(p, t) {
    const sp = this.spec;
    const crouch = p.crouch || 0;
    const bob = (p.bob ?? Math.sin(t * 3.1 + (sp.seed || 0)) * 6) + crouch * 300;
    const jump = (p.jump || 0) * PX, lean = p.lean || 0;
    const ty = bob - (p.jump || 0); this._ty = ty;
    // whole figure leans around the feet; jump lifts it
    this.body.position.y = jump * this.scale; this.body.rotation.z = -lean;
    const Y = (py) => (1024 - py) * PX - 0.05; // old canvas y -> body units
    const X = (px) => (px - 256) * PX;
    this.torso.position.y = TORSO_C - bob * PX;
    this.torso.rotation.y = 0.18;
    // head
    const hs = p.headScale || 1;
    const hy = 330 + bob + (p.headY || 0) + (1 - hs) * 140;
    this.head.position.set(0, Y(hy), 0.02); this.head.scale.setScalar(hs); this.head.rotation.z = -(p.tilt || 0);
    // legs
    const hipY = 712 + bob * 0.4 + crouch * 150, kneel = (p.squat || 0) + crouch * 0.6;
    const step = p.walk ? Math.sin(p.walk) * 40 : 0;
    this.legs.forEach((L, i) => {
      const side = i ? 1 : -1;
      const fx = 256 + side * 40 + step * 0.6, fy = 990 - (p.walk ? Math.max(0, Math.sin(p.walk * side)) * 20 : 0);
      const a = new THREE.Vector3(X(256 + side * 30), Y(hipY) + (p.jump || 0) * 0, 0);
      const b = new THREE.Vector3(X(fx), Y(fy), 0.01);
      const m = a.clone().lerp(b, 0.5); m.x += side * kneel * 0.06; m.z += 0.03 + kneel * 0.08 + crouch * 0.3;
      L.set(a, m, b, 16 * PX * 0.5, 9 * PX * 0.5 + 0.004);
      if (this.puttees) { const q0 = new THREE.Vector3(), q1 = new THREE.Vector3(); const bz = (u, o) => { const w = 1 - u; o.set(w * w * a.x + 2 * w * u * m.x + u * u * b.x, w * w * a.y + 2 * w * u * m.y + u * u * b.y, w * w * a.z + 2 * w * u * m.z + u * u * b.z); return o; };
        bz(0.52, q0); bz(0.93, q1); const qm = q0.clone().lerp(q1, 0.5); this.puttees[i].set(q0, qm, q1, 0.034, 0.03); this.puttees[i].mesh.visible = this.puttees[i].cap0.visible = this.puttees[i].cap1.visible = true; }
      this.feet[i].position.set(X(fx + side * 12), Y(fy) + 0.012, 0.035); this.feet[i].rotation.y = side * 0.25;
    });
    // arms
    this._handPx = [];
    this.arms.forEach((A, i) => {
      const side = i ? 1 : -1;
      const arm = side < 0 ? (p.armL ?? 0.25) : (p.armR ?? 0.25);
      const len = 180, sx = 256 + side * 82, sy = 534 + ty;
      const hx = sx + side * Math.sin(arm) * len, hy2 = sy + Math.cos(arm) * len;
      this._handPx.push([hx, hy2]);
      const a = new THREE.Vector3(X(sx - side * 8), Y(sy), 0.0);
      const b = new THREE.Vector3(X(hx), Y(hy2), 0.07);
      const m = a.clone().lerp(b, 0.5); const d = b.clone().sub(a); m.x += -d.y * 0.12 * side * 0.6; m.y += d.x * 0.12 * side * 0.6; m.z += 0.02;
      A.set(a, m, b, 14 * PX * 0.5, 8 * PX * 0.5 + 0.003);
      this.hands[i].position.copy(b); this.hands[i].position.z = 0.075;
    });
  }
  _poseCrawl(p, t) {
    if (this.puttees) this.puttees.forEach((L) => { L.mesh.visible = L.cap0.visible = L.cap1.visible = false; });
    // on hands and knees, facing the camera: torso horizontal pointing at the lens, head up, limbs alternating
    const ph = p.phase || 0, rock = Math.sin(ph * 2) * 0.012;
    this.body.position.y = 0; this.body.rotation.z = 0;
    this.torso.position.set(0, 0.34 + rock, -0.06); this.torso.rotation.set(1.22, 0, 0);
    this._ty = 0;
    this.head.position.set(0, 0.6 + rock + Math.sin(ph * 2 + 1) * 0.008, 0.26); this.head.scale.setScalar(1); this.head.rotation.z = Math.sin(ph) * 0.06; this.head.rotation.y = -0.92;
    for (let i = 0; i < 2; i++) {
      const side = i ? 1 : -1, k = Math.sin(ph + (side > 0 ? 0 : Math.PI));
      // arms: shoulder -> hand on the deck in front, reaching alternately
      const sh = new THREE.Vector3(side * 0.15, 0.42 + rock, 0.12);
      const hand = new THREE.Vector3(side * 0.2, 0.025 + Math.max(0, k) * 0.07, 0.3 + k * 0.08);
      const em = sh.clone().lerp(hand, 0.5); em.x += side * 0.06;
      this.arms[i].set(sh, em, hand, 14 * PX * 0.5, 8 * PX * 0.5 + 0.003);
      this.hands[i].position.copy(hand); this.hands[i].rotation.x = -Math.PI / 2;
      // legs: hip -> knee on the deck -> foot trailing behind
      const kk = Math.sin(ph + (side > 0 ? Math.PI : 0));
      const hip = new THREE.Vector3(side * 0.07, 0.3 + rock, -0.3);
      const knee = new THREE.Vector3(side * 0.11, 0.035 + Math.max(0, kk) * 0.05, -0.26 + kk * 0.07);
      const foot = new THREE.Vector3(side * 0.12, 0.05, -0.62 + kk * 0.04);
      // two segments approximated by one bezier through the knee (control point pulled beyond the knee)
      const ctrl = knee.clone().multiplyScalar(2).sub(hip.clone().lerp(foot, 0.5));
      this.legs[i].set(hip, ctrl, foot, 16 * PX * 0.5, 9 * PX * 0.5 + 0.004);
      this.feet[i].position.set(side * 0.12, 0.03, -0.66 + kk * 0.04); this.feet[i].rotation.set(-1.2, 0, 0);
    }
  }
}
