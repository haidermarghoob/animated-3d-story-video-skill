import React from 'react';
import { Composition, registerRoot } from 'remotion';
import { Video } from './Video';
import { CharSheet3D } from './CharSheet3D';
import { FPS, OUT_DURATION_S as DURATION_S } from './timing';

const Root = () => (
  <>
    <Composition id="Story" component={Video} durationInFrames={Math.round(DURATION_S * FPS)} fps={FPS} width={720} height={1280} />
    <Composition id="Chars3D" component={CharSheet3D} durationInFrames={1} fps={FPS} width={1440} height={1280} />
  </>
);
registerRoot(Root);
