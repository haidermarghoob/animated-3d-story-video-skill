import React, { useEffect, useLayoutEffect, useMemo, useState } from 'react';
import { AbsoluteFill, continueRender, delayRender } from 'remotion';
import { ThreeCanvas } from '@remotion/three';
import { useFrame, useThree } from '@react-three/fiber';
import * as THREE from 'three';
import { loadAssets, A } from './assets';
import { Character, CHAR_U, syncCharLight, CHAR_LIGHT } from './chars3d';
const E = (eyes, brows, mouth, x = {}) => ({ eyes, brows, mouth, ...x });
// THE CAST: one entry per character [spec, pose]. Edit per story (Stage 3/4 "look"); render with:
//   npx remotion still src/index.jsx Chars3D out/cast.png --gl=swangle   (or tools/stillrun.sh look chars)
const LIST = [
  [{ hat: 'bowler', hatColor: '#2a2226', outfit: 'suit', top: '#3a2e5a', bottom: '#2a2238', shirt: '#f2ede0', tie: '#c8201e', mustache: '#2a1c14', watchChain: true, seed: 1 }, { armL: 1.2, armR: 1.5, propR: 'cheque', expr: E('half', 'smug', 'smirk') }],
  [{ hat: 'cap', hatColor: '#d03a2a', outfit: 'tee', top: '#e8c84a', bottom: '#2c4a78', seed: 21 }, { armL: 0.7, armR: 2.5, propR: 'pointer', expr: E('half', 'flat', 'smirk') }],
  [{ hat: 'none', hair: '#5a3a22', outfit: 'tee', top: '#4f7a5a', bottom: '#3a3a48', seed: 10 }, { armL: 2.2, armR: 1.0, propL: 'bill', expr: E('happy', 'raised', 'grin') }],
  [{ hat: 'none', hair: '#c8742c', outfit: 'vest', top: '#5a6a9a', bottom: '#3a3a48', glasses: true, seed: 12 }, { armL: 0.8, armR: 0.9, expr: E('wide', 'shock', 'o', { sweat: true }) }],
  [{ hat: 'hardhat', outfit: 'overalls', top: '#2c5a8a', shirt: '#e9e2d0', seed: 30 }, { armL: 1.6, armR: 0.9, propL: 'wrench', expr: E('dot', 'angry', 'grit') }],
  [{ hat: 'chef', outfit: 'chef', top: '#f2f0ea', seed: 31 }, { armL: 2.6, armR: 2.6, expr: E('closed', 'raised', 'shout') }],
];

function Sheet() {
  const { gl, scene, camera, size } = useThree();
  const chars = useMemo(() => {
    const out = [];
    LIST.forEach(([sp, p], i) => { const c = new Character(sp, { pose: () => ({ t: 0.3, bob: 0, ...p }) }); c.root.position.set((i - (LIST.length - 1) / 2) * 1.05, 0, 0); out.push(c); });
    return out;
  }, []);
  useLayoutEffect(() => {
    gl.toneMapping = THREE.NeutralToneMapping; gl.shadowMap.enabled = true; gl.shadowMap.type = THREE.PCFSoftShadowMap;
    const pm = new THREE.PMREMGenerator(gl); scene.environment = ((A.hdr.main || Object.values(A.hdr)[0]) ? pm.fromEquirectangular(A.hdr.main || Object.values(A.hdr)[0]).texture : null); scene.environmentIntensity = 0.7;
    scene.background = new THREE.Color('#2b2f55');
    const hemi = new THREE.HemisphereLight('#6f7fc8', '#2a2236', 0.6); scene.add(hemi);
    const sun = new THREE.DirectionalLight('#ffc27a', 2.6); sun.position.set(5, 7, 4); sun.castShadow = true; sun.shadow.mapSize.set(2048, 2048);
    Object.assign(sun.shadow.camera, { left: -6, right: 6, top: 6, bottom: -6 }); scene.add(sun);
    const ground = new THREE.Mesh(new THREE.PlaneGeometry(30, 30), new THREE.MeshStandardMaterial({ color: '#b8c4a8', roughness: 0.9 })); ground.rotation.x = -Math.PI / 2; ground.receiveShadow = true; scene.add(ground);
    chars.forEach(c => scene.add(c.root));
    camera.position.set(0, 1.05, 1.0 + LIST.length * 1.15); camera.lookAt(0, 0.82, 0); camera.fov = 40; camera.updateProjectionMatrix();
    const s = new THREE.Vector2(); gl.getDrawingBufferSize(s); CHAR_U.uRes.value.set(s.x * 1280 / s.y * 0.5625 / 0.5625, 1280); CHAR_U.uRes.value.copy(s);
  }, []);
  useFrame(() => { CHAR_LIGHT.rim.set('#ffc45a'); CHAR_LIGHT.rimAmt = 0.7; syncCharLight(); chars.forEach(c => c.update(0.3, camera)); gl.render(scene, camera); }, 1);
  return null;
}
export const CharSheet3D = () => {
  const [ready, setReady] = useState(false);
  const [h] = useState(() => delayRender('assets', { timeoutInMilliseconds: 170000 }));
  useEffect(() => { loadAssets().then(() => { setReady(true); continueRender(h); }); }, []);
  return <AbsoluteFill style={{ background: '#8fb6cc' }}>{ready ? <ThreeCanvas width={1440} height={1280} shadows camera={{ fov: 40 }} gl={{ antialias: true, preserveDrawingBuffer: true }}><Sheet /></ThreeCanvas> : null}</AbsoluteFill>;
};
