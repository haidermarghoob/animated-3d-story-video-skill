// Shared 3D kit: ink outlines, toon materials, painted textures, small helpers.
import * as THREE from 'three';

export const INK_HEX = '#141113'; // near-black ink (v3: user asked for black outlines)
export const INK = new THREE.Color(INK_HEX);
// v4: realistic worlds drop the painted ink hulls/edge lines on world objects (characters keep their outlines)
export const STYLE = { worldInk: false };
export const FONT = '"Poppins", "Arial Black", "Arial", sans-serif';

export function rng(seed) {
  let a = seed >>> 0;
  return () => {
    a |= 0; a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
export const clamp = (x, a, b) => Math.max(a, Math.min(b, x));
export const lerp = (a, b, t) => a + (b - a) * t;
export const smooth = (a, b, x) => { const t = clamp((x - a) / (b - a), 0, 1); return t * t * (3 - 2 * t); };
export const ramp = (a, b, x) => clamp((x - a) / (b - a), 0, 1);

// 3-band toon gradient
let _grad = null;
export function gradMap() {
  if (!_grad) {
    const d = new Uint8Array([105, 105, 105, 255, 180, 180, 180, 255, 255, 255, 255, 255]);
    _grad = new THREE.DataTexture(d, 3, 1, THREE.RGBAFormat);
    _grad.minFilter = _grad.magFilter = THREE.NearestFilter;
    _grad.needsUpdate = true;
  }
  return _grad;
}

const _mats = new Map();
// v3: painted PBR-ish material (soft key-light terminator, specular sheen, env reflections) instead of 3-band toon
export function litMat(p = {}) {
  const q = { ...p }; delete q.gradientMap;
  const m = new THREE.MeshStandardMaterial({ roughness: 0.72, metalness: 0.0, envMapIntensity: 0.75, ...q });
  return m;
}
export function toon(color, opts = {}) {
  const key = opts.nocache ? null : JSON.stringify([color, opts.map ? opts.map.uuid : 0, !!opts.vc, opts.emissive || 0, opts.side || 0, opts.rough || 0, opts.metal || 0]);
  if (key && _mats.has(key)) return _mats.get(key);
  const m = litMat({
    color: new THREE.Color(color), map: opts.map || null,
    vertexColors: !!opts.vc, side: opts.side || THREE.FrontSide,
    roughness: opts.rough ?? 0.72, metalness: opts.metal ?? 0,
  });
  if (opts.emissive) { m.emissive = new THREE.Color(opts.emissive); m.emissiveIntensity = opts.ei || 1; }
  if (key) _mats.set(key, m);
  return m;
}
export function basic(color, opts = {}) {
  return new THREE.MeshBasicMaterial({ color: new THREE.Color(color), ...opts });
}

// ink materials
export const inkBack = new THREE.MeshBasicMaterial({ color: INK, side: THREE.BackSide });
export const inkLine = new THREE.LineBasicMaterial({ color: INK });
const _push = new Map();
export function inkPush(th) {
  if (_push.has(th)) return _push.get(th);
  const m = new THREE.ShaderMaterial({
    uniforms: THREE.UniformsUtils.merge([THREE.UniformsLib.fog, { uTh: { value: th }, uCol: { value: INK.clone() } }]),
    vertexShader: `#include <common>
#include <fog_pars_vertex>
uniform float uTh;
void main(){
  vec4 lp = vec4(position + normal*uTh, 1.0);
  #ifdef USE_INSTANCING
  lp = instanceMatrix * lp;
  #endif
  vec4 mvPosition = modelViewMatrix * lp;
  gl_Position = projectionMatrix * mvPosition;
  #include <fog_vertex>
}`,
    fragmentShader: `#include <common>
#include <fog_pars_fragment>
uniform vec3 uCol;
void main(){ gl_FragColor = vec4(uCol,1.0);
#include <fog_fragment>
}`,
    side: THREE.BackSide, fog: true,
  });
  _push.set(th, m);
  return m;
}

// ---------- painted textures ----------
const _tex = new Map();
export function canvasTex(w, h, draw, key, opts = {}) {
  if (key && _tex.has(key)) return _tex.get(key);
  const c = document.createElement('canvas'); c.width = w; c.height = h;
  const ctx = c.getContext('2d'); draw(ctx, w, h);
  const t = new THREE.CanvasTexture(c);
  t.colorSpace = THREE.SRGBColorSpace; t.anisotropy = 4;
  if (opts.repeat) { t.wrapS = t.wrapT = THREE.RepeatWrapping; t.repeat.set(opts.repeat[0], opts.repeat[1]); }
  if (key) _tex.set(key, t);
  return t;
}
export function shade(hex, k) { const c = new THREE.Color(hex); c.multiplyScalar(k); return '#' + c.getHexString(); }

// flat colour with brush grain, stains, chips
export function paintTex(base, o = {}) {
  const key = 'paint' + JSON.stringify([base, o]);
  return canvasTex(o.w || 256, o.h || 256, (g, w, h) => {
    const r = rng(o.seed || 7);
    g.fillStyle = base; g.fillRect(0, 0, w, h);
    for (let i = 0; i < (o.strokes ?? 60); i++) {
      g.strokeStyle = r() < 0.5 ? shade(base, 1.08) : shade(base, 0.93); g.globalAlpha = 0.35;
      g.lineWidth = 2 + r() * 5; g.beginPath(); const x = r() * w, y = r() * h;
      g.moveTo(x, y); g.quadraticCurveTo(x + 20 * r(), y + 6 * r(), x + 25 + 40 * r(), y + (r() - 0.5) * 8); g.stroke();
    }
    for (let i = 0; i < (o.stains ?? 5); i++) {
      g.globalAlpha = 0.09; g.fillStyle = shade(base, 0.7);
      g.beginPath(); g.ellipse(r() * w, r() * h, 8 + r() * 30, 6 + r() * 20, r() * 3, 0, 7); g.fill();
    }
    for (let i = 0; i < (o.chips ?? 14); i++) {
      g.globalAlpha = 0.5; g.fillStyle = shade(base, 1.25);
      g.fillRect(r() * w, r() * h, 1 + r() * 3, 1 + r() * 2);
    }
    // fine brush grain speckle
    for (let i = 0; i < (o.grain ?? 500); i++) { g.globalAlpha = 0.06 + r() * 0.06; g.fillStyle = r() < 0.5 ? '#000' : '#fff'; g.fillRect(r() * w, r() * h, 1 + r() * 2, 1); }
    // dry-brush streaks
    for (let i = 0; i < 10; i++) { g.globalAlpha = 0.07; g.strokeStyle = shade(base, 0.8); g.lineWidth = 1; const y = r() * h; g.beginPath(); g.moveTo(0, y); for (let x = 0; x <= w; x += 16) g.lineTo(x, y + Math.sin(x * 0.05 + i) * 3); g.stroke(); }
    g.globalAlpha = 1;
    const edge = o.edge ?? (!o.repeat || (o.repeat[0] === 1 && o.repeat[1] === 1));
    if (edge) { // painted ink edge + worn highlight just inside it
      g.strokeStyle = INK_HEX; g.globalAlpha = 0.75; g.lineWidth = Math.max(3, w / 60); g.strokeRect(0, 0, w, h);
      g.globalAlpha = 0.25; g.strokeStyle = shade(base, 1.3); g.lineWidth = Math.max(2, w / 110); const m = w / 30; g.beginPath(); g.moveTo(m, h - m); g.lineTo(m, m); g.lineTo(w - m, m); g.stroke();
      g.globalAlpha = 0.18; g.strokeStyle = shade(base, 0.6); g.beginPath(); g.moveTo(w - m, m); g.lineTo(w - m, h - m); g.lineTo(m, h - m); g.stroke();
      g.globalAlpha = 1;
    }
    if (o.planks) { // wooden planks with ink seams
      g.strokeStyle = INK_HEX; g.globalAlpha = 0.55; g.lineWidth = 2;
      for (let y = 0; y < h; y += h / o.planks) { g.beginPath(); g.moveTo(0, y); g.lineTo(w, y); g.stroke(); }
      for (let i = 0; i < o.planks * 2; i++) { const y = Math.floor(r() * o.planks) * h / o.planks; const x = r() * w; g.beginPath(); g.moveTo(x, y); g.lineTo(x, y + h / o.planks); g.stroke(); }
      g.globalAlpha = 1;
    }
    if (o.bricks) {
      g.strokeStyle = shade(base, 0.72); g.lineWidth = 2;
      const bh = h / o.bricks, bw = bh * 2.2;
      for (let row = 0; row < o.bricks; row++) {
        g.beginPath(); g.moveTo(0, row * bh); g.lineTo(w, row * bh); g.stroke();
        for (let x = (row % 2) * bw / 2; x < w; x += bw) { g.beginPath(); g.moveTo(x, row * bh); g.lineTo(x, row * bh + bh); g.stroke(); }
      }
    }
  }, key, { repeat: o.repeat || [1, 1] });
}

// ---------- geometry helpers ----------
// box with scaled back-face hull + edge lines
export function box(w, h, d, mat, o = {}) {
  const g = new THREE.Group();
  const geo = new THREE.BoxGeometry(w, h, d);
  if (o.uvScale) { const uv = geo.attributes.uv; for (let i = 0; i < uv.count; i++) uv.setXY(i, uv.getX(i) * o.uvScale[0], uv.getY(i) * o.uvScale[1]); }
  const m = new THREE.Mesh(geo, typeof mat === 'string' ? toon(mat) : mat);
  g.add(m);
  const ink = STYLE.worldInk ? (o.ink ?? Math.min(0.05, 0.02 + 0.01 * Math.max(w, h, d))) : 0;
  if (ink > 0) g.add(new THREE.Mesh(new THREE.BoxGeometry(w + ink * 2, h + ink * 2, d + ink * 2), inkBack));
  if (o.edges !== false && STYLE.worldInk) g.add(new THREE.LineSegments(new THREE.EdgesGeometry(geo), inkLine));
  g.userData.mesh = m;
  return g;
}
export function withHull(geo, mat, th = 0.03, edges = false) {
  const g = new THREE.Group();
  const m = new THREE.Mesh(geo, typeof mat === 'string' ? toon(mat) : mat);
  g.add(m);
  if (th > 0 && STYLE.worldInk) g.add(new THREE.Mesh(geo, inkPush(th)));
  if (edges && STYLE.worldInk) g.add(new THREE.LineSegments(new THREE.EdgesGeometry(geo, 35), inkLine));
  g.userData.mesh = m;
  return g;
}
export function cyl(rt, rb, h, mat, o = {}) {
  return withHull(new THREE.CylinderGeometry(rt, rb, h, o.seg || 16, 1, !!o.open), mat, o.ink ?? 0.025, o.edges);
}
export function sph(r, mat, o = {}) {
  return withHull(new THREE.SphereGeometry(r, o.seg || 18, o.seg2 || 12), mat, o.ink ?? 0.03);
}
export function at(obj, x, y, z, ry = 0, rx = 0, rz = 0) {
  obj.position.set(x, y, z); obj.rotation.set(rx, ry, rz); return obj;
}
// tube along points with hull
export function tube(points, r, mat, ink = 0.04, seg = 64) {
  const curve = new THREE.CatmullRomCurve3(points.map(p => new THREE.Vector3(...p)));
  return withHull(new THREE.TubeGeometry(curve, seg, r, 8, false), mat, ink);
}

// text panel texture
export function textTex(w, h, draw, key) { return canvasTex(w, h, draw, key); }
export function plane(w, h, tex, o = {}) {
  const m = new THREE.Mesh(new THREE.PlaneGeometry(w, h), o.mat || litMat({ map: tex, transparent: !!o.transparent, side: o.side || THREE.FrontSide, alphaTest: o.alphaTest || 0 }));
  return m;
}
// light beam (god ray) gradient plane, additive
let _beamTex = null;
export function beamMat(color, op = 0.35) {
  if (!_beamTex) _beamTex = canvasTex(64, 256, (g, w, h) => {
    const gr = g.createLinearGradient(0, 0, 0, h); gr.addColorStop(0, 'rgba(255,255,255,1)'); gr.addColorStop(1, 'rgba(255,255,255,0)');
    g.fillStyle = gr; g.fillRect(0, 0, w, h);
    const gx = g.createLinearGradient(0, 0, w, 0); gx.addColorStop(0, 'rgba(0,0,0,1)'); gx.addColorStop(0.3, 'rgba(0,0,0,0)'); gx.addColorStop(0.7, 'rgba(0,0,0,0)'); gx.addColorStop(1, 'rgba(0,0,0,1)');
    g.globalCompositeOperation = 'destination-out'; g.fillStyle = gx; g.fillRect(0, 0, w, h);
  }, 'beam');
  return new THREE.MeshBasicMaterial({ map: _beamTex, color: new THREE.Color(color), transparent: true, opacity: op, blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.DoubleSide, fog: false });
}

export function merge(geos) {
  // simple merge of non-indexed geometries with position/normal/uv
  const list = geos.map(g => g.index ? g.toNonIndexed() : g);
  let n = 0; list.forEach(g => n += g.attributes.position.count);
  const pos = new Float32Array(n * 3), nor = new Float32Array(n * 3), uv = new Float32Array(n * 2);
  let o = 0;
  list.forEach(g => {
    pos.set(g.attributes.position.array, o * 3);
    if (g.attributes.normal) nor.set(g.attributes.normal.array, o * 3);
    if (g.attributes.uv) uv.set(g.attributes.uv.array, o * 2);
    o += g.attributes.position.count;
  });
  const out = new THREE.BufferGeometry();
  out.setAttribute('position', new THREE.BufferAttribute(pos, 3));
  out.setAttribute('normal', new THREE.BufferAttribute(nor, 3));
  out.setAttribute('uv', new THREE.BufferAttribute(uv, 2));
  return out;
}
