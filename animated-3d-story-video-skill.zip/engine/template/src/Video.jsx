// The Story composition: 3D scene (world.js + camera.js) through the post chain (post.js) + word captions.
// Audio is NOT inside the composition: the final mix is muxed by tools/finish.sh (voice + SFX + music, -14 LUFS).
// Base size 720x1280; render with --scale=1.5 for 1080x1920 (captions and ink lines scale with it).
import React, { useEffect, useLayoutEffect, useMemo, useRef, useState } from 'react';
import { AbsoluteFill, continueRender, delayRender, useCurrentFrame, useVideoConfig } from 'remotion';
import { ThreeCanvas } from '@remotion/three';
import { useFrame, useThree } from '@react-three/fiber';
import * as THREE from 'three';
import { loadFont } from '@remotion/google-fonts/Poppins';
import { buildWorld } from './world';
import { makePost } from './post';
import { CAPTIONS, sceneTime } from './timing';
import { shotIndexAt, dissolveAt } from './camera';
import { loadAssets } from './assets';
import { CHAR_U } from './chars3d';

const { fontFamily, waitUntilDone } = loadFont('normal', { weights: ['700', '800', '900'], subsets: ['latin'] });

function Scene() {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const { gl, scene, camera, size } = useThree();
  const world = useMemo(() => buildWorld(), []);
  useLayoutEffect(() => {
    gl.toneMapping = THREE.NeutralToneMapping; gl.toneMappingExposure = 1.15;
    gl.shadowMap.type = THREE.PCFShadowMap;
    world.initGL(gl);
  }, [gl, world]);
  useLayoutEffect(() => { scene.add(world.root); return () => { scene.remove(world.root); }; }, [scene, world]);
  const post = useMemo(() => makePost(gl, scene, camera), [gl, scene, camera]);
  useLayoutEffect(() => { post.setSize(size.width, size.height); const s = new THREE.Vector2(); gl.getDrawingBufferSize(s); CHAR_U.uRes.value.copy(s); }, [size, post, gl]);
  const tRef = useRef(0);
  tRef.current = sceneTime(frame / fps);
  useFrame(() => {
    const t = tRef.current;
    const d = dissolveAt(t);
    if (d) {
      const sa = world.update(t, camera, scene, d.a); post.render(t, sa, 'capture');
      const sb = world.update(t, camera, scene, d.b); post.render(t, { ...sb, mixK: d.k });
    } else {
      const st = world.update(t, camera, scene, shotIndexAt(t)); post.render(t, st);
    }
  }, 1);
  return null;
}

function Captions() {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const t = frame / fps;
  const c = CAPTIONS.find((x) => t >= x.s - 0.02 && t < x.e);
  if (!c) return null;
  const age = t - (c.s - 0.02);
  const k = Math.min(1, age / 0.12);
  const scale = 0.78 + 0.22 * (1 - Math.pow(1 - k, 3)) + 0.06 * Math.sin(Math.min(1, age / 0.2) * Math.PI);
  return (
    <AbsoluteFill style={{ pointerEvents: 'none' }}>
      <div style={{ position: 'absolute', top: '70%', left: 0, right: 0, transform: `translateY(-50%) scale(${scale})`, textAlign: 'center',
        fontFamily, fontWeight: 800, fontSize: 46, lineHeight: 1.1, color: '#ffffff', letterSpacing: -0.3,
        WebkitTextStroke: '5px #0b0a0c', paintOrder: 'stroke fill', textShadow: '0 3px 0 rgba(0,0,0,0.55), 0 6px 14px rgba(0,0,0,0.45)', padding: '0 40px' }}>
        {c.t}
      </div>
    </AbsoluteFill>
  );
}

export const Video = () => {
  const { width, height } = useVideoConfig();
  const [ready, setReady] = useState(false);
  const [handle] = useState(() => delayRender('fonts+assets', { timeoutInMilliseconds: 170000 }));
  useEffect(() => {
    waitUntilDone().then(() => document.fonts.ready).then(() => loadAssets()).then(() => { setReady(true); continueRender(handle); }).catch((e) => { console.error('ASSET LOAD FAILED', e); setReady(true); continueRender(handle); });
  }, [handle]);
  return (
    <AbsoluteFill style={{ backgroundColor: '#111320' }}>
      {ready ? (
        <ThreeCanvas width={width} height={height} flat shadows camera={{ fov: 70, near: 0.05, far: 4000, position: [0, 0, 0] }} gl={{ antialias: false, preserveDrawingBuffer: true }}>
          <Scene />
        </ThreeCanvas>
      ) : null}
      {ready ? <Captions /> : null}
    </AbsoluteFill>
  );
};
