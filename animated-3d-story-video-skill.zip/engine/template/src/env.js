// v4 realism: HDRI sky dome, Gerstner water with normal maps + Fresnel sky reflection + foam, PBR terrain blend,
// baked-impostor forest, rain with splashes, wind spray.
import * as THREE from 'three';
import { A } from './assets';
import { rng, smooth } from './kit';

// shared sky sampling GLSL (photo sky from the Poly Haven HDRI, rotated so its sun matches the key light)
const SKY_GLSL = `
uniform sampler2D uSky; uniform float uRot, uSkyExp, uSkySat; uniform vec3 uSkyTint;
vec3 skyPhoto(vec3 d){
  float az = atan(d.z, d.x) + uRot;
  float u = az * 0.15915494 + 0.5;
  float el = asin(clamp(d.y, -1.0, 1.0)) * 57.29578;
  float v = (el + 11.25) / 101.25;
  vec2 uvS = vec2(u, clamp(v, 0.004, 0.996));
  vec2 uvC = vec2(fract(u + 0.5), uvS.y);   // continuous where atan() jumps -> no mip seam line
  vec2 du = dFdx(uvC), dv = dFdy(uvC);
  vec3 c = textureGrad(uSky, uvS, du, dv).rgb;
  float l = dot(c, vec3(0.2126, 0.7152, 0.0722));
  c = max(mix(vec3(l), c, uSkySat), 0.0);
  return c * uSkyTint * uSkyExp;
}`;
const NOISE_GLSL = `
float hash(vec2 p){ return fract(sin(dot(p,vec2(127.1,311.7)))*43758.5453); }
float noise(vec2 p){ vec2 i=floor(p), f=fract(p); f=f*f*(3.0-2.0*f); return mix(mix(hash(i),hash(i+vec2(1,0)),f.x),mix(hash(i+vec2(0,1)),hash(i+vec2(1,1)),f.x),f.y); }
float fbm(vec2 p){ float a=0.5, s=0.0; for(int i=0;i<4;i++){ s+=a*noise(p); p=p*2.03+vec2(1.7,9.2); a*=0.5; } return s; }`;

export function skyUniforms() {
  return { uSky: { value: null }, uRot: { value: 0 }, uSkyExp: { value: 1 }, uSkySat: { value: 1.3 }, uSkyTint: { value: new THREE.Color(1, 1, 1) } };
}

export function buildSky2(SU) {
  const mat = new THREE.ShaderMaterial({
    uniforms: { ...SU, uStorm: { value: 0 }, uTime: { value: 0 }, uFog: { value: new THREE.Color() }, uHaze: { value: 0.35 }, uSun: { value: new THREE.Vector3(0, 1, 0) }, uSunAmt: { value: 1 } },
    vertexShader: `varying vec3 vD; void main(){ vD = normalize(position); gl_Position = projectionMatrix*modelViewMatrix*vec4(position,1.0); gl_Position.z = gl_Position.w * 0.99999; }`,
    fragmentShader: `${SKY_GLSL}${NOISE_GLSL}
    uniform float uStorm, uTime, uHaze, uSunAmt; uniform vec3 uFog, uSun; varying vec3 vD;
    void main(){
      vec3 d = normalize(vD);
      vec3 c = skyPhoto(d);
      // storm: extra low, fast-moving dark cloud deck over the photo sky (reads as volume because it moves in layers)
      if (uStorm > 0.0 && d.y > -0.05) {
        vec2 uv = d.xz / (d.y + 0.18);
        float n1 = fbm(uv * 1.3 + vec2(uTime * 0.05, uTime * 0.02));
        float n2 = fbm(uv * 2.6 - vec2(uTime * 0.09, 0.0));
        float cov = smoothstep(0.38, 0.75, n1 * 0.7 + n2 * 0.45);
        vec3 cc = mix(vec3(0.16, 0.18, 0.21), vec3(0.42, 0.46, 0.52), smoothstep(0.3, 0.9, n2));
        c = mix(c, cc, cov * uStorm * 0.75 * smoothstep(-0.05, 0.2, d.y));
      }
      c += vec3(1.0, 0.95, 0.85) * pow(max(dot(d, uSun), 0.0), 9.0) * 0.12 * uSunAmt;
      // aerial haze toward the horizon so the sky meets the fogged land and water
      c = mix(c, uFog, uHaze * (1.0 - smoothstep(-0.02, 0.16, d.y)));
      gl_FragColor = vec4(c, 1.0);
      #include <colorspace_fragment>
    }`,
    side: THREE.BackSide, depthWrite: false, depthTest: false, fog: false,
  });
  const m = new THREE.Mesh(new THREE.SphereGeometry(1500, 64, 32), mat); m.renderOrder = -10; m.frustumCulled = false;
  return { m, mat };
}

// ---------------- water ----------------
export function buildWater2(SU) {
  const geo = new THREE.PlaneGeometry(1800, 1800, 200, 200); geo.rotateX(-Math.PI / 2);
  const mat = new THREE.ShaderMaterial({
    uniforms: {
      ...SU, uTime: { value: 0 }, uStorm: { value: 0 }, uNorm: { value: A.tex.water.normal },
      uDeep: { value: new THREE.Color('#0b3d57') }, uScatter: { value: new THREE.Color('#1f8c96') },
      uFog: { value: new THREE.Color('#a9b8cc') }, uFogD: { value: 0.0012 },
      uSun: { value: new THREE.Vector3(-0.5, 0.6, 0.4).normalize() }, uSunCol: { value: new THREE.Color('#fff2d0') }, uSunAmt: { value: 1 }, uFoamAmt: { value: 1 }, uCalm: { value: new THREE.Vector4(0, 0, 0, 0) }, uOil: { value: 0 }, uFlash: { value: 0 },
    },
    vertexShader: `uniform float uTime, uStorm; uniform vec4 uCalm; varying vec3 vW; varying vec3 vN; varying float vFold; varying float vH; varying float vCalm;
    void gw(vec2 D, float L, float A, float Q, vec2 p, inout vec3 P, inout vec3 N, inout float fold){
      float k = 6.2831853 / L; float w = sqrt(9.8 * k); float f = k * dot(D, p) - w * uTime;
      float c = cos(f), s = sin(f);
      P += vec3(Q * A * D.x * c, A * s, Q * A * D.y * c);
      N += vec3(-D.x * k * A * c, -Q * k * A * s, -D.y * k * A * c);
      fold -= Q * k * A * s;
    }
    void main(){
      vec2 p = position.xz; vec3 P = vec3(p.x, 0.0, p.y); vec3 N = vec3(0.0, 1.0, 0.0); float fold = 1.0;
      vec2 wp0 = (modelMatrix * vec4(position, 1.0)).xz;
      float calm = clamp((uCalm.z - length(wp0 - uCalm.xy)) / max(uCalm.z * 0.35, 3.0), 0.0, 1.0) * uCalm.w; vCalm = calm;
      float S = uStorm * (1.0 - 0.8 * calm);
      gw(normalize(vec2(0.2, 1.0)), 61.0, 0.20 + S * 1.5, 0.55 + S * 0.25, p, P, N, fold);
      gw(normalize(vec2(-0.5, 0.9)), 37.0, 0.13 + S * 0.9, 0.55 + S * 0.25, p, P, N, fold);
      gw(normalize(vec2(0.7, 0.7)), 23.0, 0.08 + S * 0.55, 0.5 + S * 0.3, p, P, N, fold);
      gw(normalize(vec2(-0.1, 1.0)), 14.5, 0.05 + S * 0.32, 0.45 + S * 0.3, p, P, N, fold);
      gw(normalize(vec2(0.35, 0.94)), 97.0, S * 2.0, 0.6, p, P, N, fold);
      vH = P.y; vN = N; vFold = fold;
      vec4 w = modelMatrix * vec4(P, 1.0); vW = w.xyz; gl_Position = projectionMatrix * viewMatrix * w;
    }`,
    fragmentShader: `${SKY_GLSL}${NOISE_GLSL}
    uniform float uTime, uStorm, uFogD, uSunAmt, uFoamAmt, uOil, uFlash; varying float vCalm; uniform sampler2D uNorm; uniform vec3 uDeep, uScatter, uFog, uSun, uSunCol;
    varying vec3 vW; varying vec3 vN; varying float vFold; varying float vH;
    vec3 tn(vec2 uv){ vec3 t = texture2D(uNorm, uv).rgb * 2.0 - 1.0; return vec3(t.r, t.b, t.g); }
    void main(){
      vec3 toC = cameraPosition - vW; float d = length(toC); vec3 V = toC / d;
      vec3 N = normalize(vN);
      // detail normals: two scrolling normal maps (mip-mapped, so they average out with distance instead of making blobs)
      float det = (0.42 + uStorm * 0.5) * (1.0 - 0.85 * vCalm);
      vec3 n1 = tn(vW.xz / 23.0 + vec2(uTime * 0.021, uTime * 0.013));
      vec3 n2 = tn(vW.xz / 8.5 + vec2(-uTime * 0.032, uTime * 0.041));
      vec3 n3 = tn(vW.xz / 3.1 + vec2(uTime * 0.06, -uTime * 0.02));
      vec3 dn = (n1 * 0.5 + n2 * 0.35 + n3 * 0.25 * (1.0 / (1.0 + d * 0.05)));
      N = normalize(N + vec3(dn.x, 0.0, dn.z) * det);
      float NdV = max(dot(N, V), 0.0);
      float fres = 0.02 + 0.98 * pow(1.0 - NdV, 5.0);
      vec3 R = reflect(-V, N); R.y = max(R.y, 0.015);
      vec3 refl = skyPhoto(normalize(R));
      // sun glitter (HDR so bloom catches it)
      float sd = max(dot(R, uSun), 0.0);
      vec3 spec = uSunCol * (pow(sd, 900.0) * 30.0 + pow(sd, 90.0) * 1.2) * uSunAmt;
      // body colour: deep + forward scattering through thin crests
      float crest = clamp(vH / (0.35 + uStorm * 2.6) * 0.5 + 0.5, 0.0, 1.0);
      float back = pow(max(dot(-V, uSun) * 0.5 + 0.5, 0.0), 2.0);
      vec3 body = uDeep * (0.7 + 0.3 * max(dot(N, vec3(0.0, 1.0, 0.0)), 0.0)) + uScatter * (crest * crest * (0.25 + 0.6 * back)) * (0.45 + 0.55 * uSunAmt);
      vec3 col = mix(body, refl, clamp(fres, 0.0, 1.0)) + spec * (1.0 - uStorm * 0.85);
      // foam: wave folding (Jacobian) on crests + streaks along the wind; storms get much more
      float nz = fbm(vW.xz * vec2(0.09, 0.35) + vec2(uTime * 0.1, -uTime * 0.45));
      float nz2 = noise(vW.xz * vec2(0.6, 2.2) + uTime * 0.3) * 0.6 + noise(vW.xz * 3.0) * 0.4;
      float foldF = 1.0 - smoothstep(0.05 + uStorm * 0.05, 0.32 + uStorm * 0.18, vFold);
      float streak = smoothstep(0.66 - uStorm * 0.12, 0.8, nz) * (0.25 + uStorm * 0.75);
      float foam = clamp(foldF * smoothstep(0.35, 0.75, nz2) + streak * (0.4 + 0.6 * crest), 0.0, 1.0) * uFoamAmt;
      foam *= 1.0 - smoothstep(250.0, 700.0, d) * 0.7;
      foam *= 1.0 - vCalm * 0.95;
      vec3 foamCol = mix(vec3(0.88, 0.92, 0.95), vec3(0.62, 0.68, 0.72), uStorm) * (0.75 + 0.25 * max(dot(N, uSun), 0.0));
      col = mix(col, foamCol, foam * 0.85);
      // oil film: glassy, slightly amber, thin-film rainbow fringe at the spreading edge
      float oil = vCalm * uOil;
      vec3 irid = 0.5 + 0.5 * cos(6.2831 * (vec3(0.0, 0.33, 0.67) + NdV * 1.6 + fbm(vW.xz * 0.25 + uTime * 0.05) * 1.2));
      float edge = smoothstep(0.0, 0.25, vCalm) * (1.0 - smoothstep(0.35, 0.85, vCalm));
      // oil: dark glossy amber body, mirror-like reflection, rainbow band at the spreading rim
      vec3 oilBody = uDeep * 0.7 + refl * vec3(0.95, 0.92, 0.8) * (0.35 + 0.65 * fres);
      col = mix(col, oilBody, oil * 0.55);
      col += irid * 0.1 * edge * uOil * (0.5 + fres);
      col += vec3(0.9, 0.7, 0.3) * oil * 0.035 * (0.5 + 0.5 * noise(vW.xz * 0.6 + uTime * 0.2));
      col += vec3(0.85, 0.9, 1.0) * uFlash * (0.25 + fres);
      // aerial perspective
      float f = 1.0 - exp(-d * d * uFogD * uFogD);
      gl_FragColor = vec4(mix(col, uFog, f), 1.0);
      #include <colorspace_fragment>
    }`,
  });
  const m = new THREE.Mesh(geo, mat); m.frustumCulled = false;
  return { m, mat };
}

// ---------------- terrain material: grass / rock / sand / forest floor blended by height + slope ----------------
export function terrainMaterial() {
  const t = A.tex;
  const m = new THREE.MeshStandardMaterial({ color: '#ffffff', vertexColors: true, roughness: 1, metalness: 0, envMapIntensity: 0.6 });
  m.normalMap = t.aerial_grass_rock.normal.clone(); m.normalMap.repeat.set(52, 110); m.normalMap.needsUpdate = true; m.normalScale.set(0.8, 0.8);
  m.onBeforeCompile = (sh) => {
    sh.uniforms.tG = { value: t.aerial_grass_rock.map }; sh.uniforms.tR = { value: t.aerial_rocks_02.map };
    sh.uniforms.tS = { value: t.coast_sand_rocks_02.map }; sh.uniforms.tF = { value: t.forest_ground_04.map };
    sh.vertexShader = sh.vertexShader.replace('#include <common>', '#include <common>\nvarying vec3 vWp; varying vec3 vWn;')
      .replace('#include <worldpos_vertex>', '#include <worldpos_vertex>\nvWp = (modelMatrix * vec4(transformed, 1.0)).xyz; vWn = normalize(mat3(modelMatrix) * objectNormal);');
    sh.fragmentShader = sh.fragmentShader.replace('#include <common>', `#include <common>
uniform sampler2D tG, tR, tS, tF; varying vec3 vWp; varying vec3 vWn;`)
      .replace('#include <map_fragment>', `{
        vec2 uv = vWp.xz;
        vec3 g = texture2D(tG, uv / 11.0).rgb * 0.6 + texture2D(tG, uv / 47.0 + 0.37).rgb * 0.4;
        g *= vec3(0.5, 0.78, 0.4) * (0.9 + 0.25 * texture2D(tF, uv / 83.0).g);
        vec3 f = texture2D(tF, uv / 6.0).rgb * vec3(0.7, 0.85, 0.6);
        vec3 s = texture2D(tS, uv / 7.0).rgb;
        vec3 r = texture2D(tR, vec2(vWp.x + vWp.z, vWp.y) / 9.0).rgb * 0.6 + texture2D(tR, uv / 13.0).rgb * 0.4;
        float slope = 1.0 - clamp(vWn.y, 0.0, 1.0);
        float wS = 1.0 - smoothstep(0.6, 2.4, vWp.y);
        float wR = smoothstep(0.18, 0.42, slope) * (1.0 - wS);
        float wF = smoothstep(9.0, 20.0, vWp.y) * (1.0 - wR) * (1.0 - wS) * 0.7;
        vec3 base = mix(g, f, wF); base = mix(base, r, wR); base = mix(base, s, wS);
        // gentle saturation lift toward the painterly references
        float l = dot(base, vec3(0.2126, 0.7152, 0.0722)); base = max(mix(vec3(l), base, 1.0), 0.0);
        diffuseColor.rgb *= base * 1.18;
      }`);
  };
  m.customProgramCacheKey = () => 'terrainv4';
  return m;
}

// ---------------- baked-impostor forest (cylindrical billboards, one draw per species) ----------------
export function buildForest(root, groundH, placements) {
  const groups = {};
  const mats = [];
  for (const pl of placements) (groups[pl.n] = groups[pl.n] || []).push(pl);
  const tint = { value: new THREE.Color(1, 1, 1) };
  for (const [n, list] of Object.entries(groups)) {
    const im = A.imp[n]; if (!im) continue;
    const geo = new THREE.PlaneGeometry(1, 1); geo.translate(0, 0.5, 0);
    const mat = new THREE.ShaderMaterial({
      uniforms: THREE.UniformsUtils.merge([THREE.UniformsLib.fog, { map: { value: im.tex } }]),
      vertexShader: `#include <common>
#include <fog_pars_vertex>
varying vec2 vUv; varying vec3 vCol;
void main(){
  vec3 c = (instanceMatrix * vec4(0.0, 0.0, 0.0, 1.0)).xyz;
  float sx = length(instanceMatrix[0].xyz), sy = length(instanceMatrix[1].xyz);
  vec3 camR = vec3(viewMatrix[0][0], viewMatrix[1][0], viewMatrix[2][0]);
  vec3 right = normalize(vec3(camR.x, 0.0, camR.z));
  vec3 wp = c + right * position.x * sx + vec3(0.0, position.y * sy, 0.0);
  vUv = uv;
  #ifdef USE_INSTANCING_COLOR
  vCol = instanceColor;
  #else
  vCol = vec3(1.0);
  #endif
  vec4 mvPosition = viewMatrix * vec4(wp, 1.0);
  gl_Position = projectionMatrix * mvPosition;
  #include <fog_vertex>
}`,
      fragmentShader: `#include <common>
#include <fog_pars_fragment>
uniform sampler2D map; uniform vec3 uTint; varying vec2 vUv; varying vec3 vCol;
void main(){
  vec4 t = texture2D(map, vUv);
  if (t.a < 0.45) discard;
  gl_FragColor = vec4(t.rgb * vCol * uTint, 1.0);
  #include <fog_fragment>
}`,
      fog: true,
    });
    mat.uniforms.uTint = tint;
    const mesh = new THREE.InstancedMesh(geo, mat, list.length);
    const M = new THREE.Matrix4(), col = new THREE.Color();
    list.forEach((p, i) => {
      M.makeScale(p.h * im.aspect, p.h, 1); M.setPosition(p.x, p.y - 0.15, p.z); mesh.setMatrixAt(i, M);
      col.setRGB(p.c[0], p.c[1], p.c[2]); mesh.setColorAt(i, col);
    });
    mesh.frustumCulled = false; root.add(mesh); mats.push(mat);
  }
  return { tint };
}

// ---------------- rain: streaks + splash rings on the ground around the camera ----------------
export function buildRain(root) {
  const NR = 3200;
  const rgeo = new THREE.BufferGeometry();
  rgeo.setAttribute('position', new THREE.BufferAttribute(new Float32Array(NR * 12), 3));
  rgeo.setAttribute('color', new THREE.BufferAttribute(new Float32Array(NR * 12), 3));
  { const idx = []; for (let i = 0; i < NR; i++) { const b = i * 4; idx.push(b, b + 1, b + 2, b, b + 2, b + 3); } rgeo.setIndex(idx); }
  const rainM = new THREE.Mesh(rgeo, new THREE.MeshBasicMaterial({ color: '#c8d6e4', vertexColors: true, transparent: true, opacity: 0.32, fog: false, depthWrite: false, side: THREE.DoubleSide, blending: THREE.AdditiveBlending }));
  rainM.frustumCulled = false; root.add(rainM);
  const rr = rng(99); const seeds = []; for (let i = 0; i < NR; i++) seeds.push([rr(), rr(), rr(), rr()]);
  // splashes: small expanding rings + a vertical droplet crown
  const NS = 260;
  const ringTex = (() => { const c = document.createElement('canvas'); c.width = c.height = 64; const g = c.getContext('2d');
    const gr = g.createRadialGradient(32, 32, 18, 32, 32, 31); gr.addColorStop(0, 'rgba(255,255,255,0)'); gr.addColorStop(0.6, 'rgba(255,255,255,0.9)'); gr.addColorStop(1, 'rgba(255,255,255,0)');
    g.fillStyle = gr; g.fillRect(0, 0, 64, 64); const t = new THREE.CanvasTexture(c); return t; })();
  const sgeo = new THREE.PlaneGeometry(1, 1); sgeo.rotateX(-Math.PI / 2);
  const splash = new THREE.InstancedMesh(sgeo, new THREE.MeshBasicMaterial({ map: ringTex, color: '#dfe9f2', transparent: true, depthWrite: false, blending: THREE.AdditiveBlending, fog: true }), NS);
  splash.frustumCulled = false; root.add(splash);
  const sseed = []; for (let i = 0; i < NS; i++) sseed.push([rr(), rr(), rr()]);
  const M = new THREE.Matrix4(), C = new THREE.Color();
  function update(t, cam, right, groundAt, on) {
    rainM.visible = splash.visible = on; if (!on) return;
    const a = rgeo.attributes.position.array, ca = rgeo.attributes.color.array; const B = 30;
    for (let i = 0; i < NR; i++) {
      const s = seeds[i];
      let dx = (s[0] - 0.5) * B, dz = (s[1] - 0.5) * B; const dd = Math.hypot(dx, dz);
      if (dd < 2.4) { const k = 2.4 / Math.max(dd, 0.05); dx *= k; dz *= k; }
      const x = cam.position.x + dx, z = cam.position.z + dz;
      const sp = 0.8 + s[3] * 0.4;
      const yb = cam.position.y - B / 2 + ((s[2] * B - t * 34 * sp) % B + B) % B;
      const hw = 0.006 + s[3] * 0.01, L = 0.9 + s[3] * 0.7;
      const o = i * 12;
      a[o] = x - right.x * hw; a[o + 1] = yb; a[o + 2] = z - right.z * hw;
      a[o + 3] = x + right.x * hw; a[o + 4] = yb; a[o + 5] = z + right.z * hw;
      a[o + 6] = x + 0.22 * L + right.x * hw; a[o + 7] = yb + L; a[o + 8] = z - 0.3 * L + right.z * hw;
      a[o + 9] = x + 0.22 * L - right.x * hw; a[o + 10] = yb + L; a[o + 11] = z - 0.3 * L - right.z * hw;
      const br = 0.25 + s[0] * 0.55;
      for (let k = 0; k < 4; k++) { ca[o + k * 3] = br * (k < 2 ? 0.35 : 1); ca[o + k * 3 + 1] = br * (k < 2 ? 0.35 : 1); ca[o + k * 3 + 2] = br * (k < 2 ? 0.4 : 1); }
    }
    rgeo.attributes.position.needsUpdate = true; rgeo.attributes.color.needsUpdate = true;
    for (let i = 0; i < NS; i++) {
      const s = sseed[i]; const per = 0.45 + s[2] * 0.3; const ph = ((t + s[2] * 7.1) / per) % 1; const cyc = Math.floor((t + s[2] * 7.1) / per);
      const r2 = rng(i * 131 + cyc * 7); const ang = r2() * 6.283, rad = 1.5 + r2() * 13;
      const x = cam.position.x + Math.cos(ang) * rad, z = cam.position.z + Math.sin(ang) * rad;
      const y = groundAt(x, z);
      if (y === null) { M.makeScale(0.0001, 1, 0.0001); M.setPosition(x, -50, z); splash.setMatrixAt(i, M); continue; }
      const sz = 0.04 + ph * 0.22;
      M.makeScale(sz, 1, sz); M.setPosition(x, y + 0.03, z); splash.setMatrixAt(i, M);
      const f = (1 - ph) * (1 - ph) * 0.35 * (0.4 + r2()); C.setRGB(f, f, f); splash.setColorAt(i, C);
    }
    splash.instanceMatrix.needsUpdate = true; if (splash.instanceColor) splash.instanceColor.needsUpdate = true;
  }
  return { update };
}

// ---------------- wind-blown spray over the storm water (soft sprites) ----------------
let _soft = null;
export function softTex() {
  if (_soft) return _soft;
  const c = document.createElement('canvas'); c.width = c.height = 64; const g = c.getContext('2d');
  const gr = g.createRadialGradient(32, 32, 0, 32, 32, 32); gr.addColorStop(0, 'rgba(255,255,255,1)'); gr.addColorStop(0.45, 'rgba(255,255,255,0.55)'); gr.addColorStop(1, 'rgba(255,255,255,0)');
  g.fillStyle = gr; g.fillRect(0, 0, 64, 64);
  _soft = new THREE.CanvasTexture(c); return _soft;
}
export function buildSpray(root) {
  const N = 900; const pos = new Float32Array(N * 3); const r = rng(17); const S = [];
  for (let i = 0; i < N; i++) S.push([r() * 260 - 130, r() * 80 - 40, r(), r()]);
  const geo = new THREE.BufferGeometry(); geo.setAttribute('position', new THREE.BufferAttribute(pos, 3));
  const pts = new THREE.Points(geo, new THREE.PointsMaterial({ map: softTex(), color: '#c9d4dc', size: 2.2, sizeAttenuation: true, transparent: true, opacity: 0.28, depthWrite: false, fog: true }));
  pts.frustumCulled = false; root.add(pts);
  function update(t, on, cam) {
    pts.visible = on; if (!on) return;
    for (let i = 0; i < N; i++) {
      const s = S[i]; const life = ((t * 0.5 + s[2]) % 1);
      const x = s[0] + life * 6, z = s[1] + life * 22;
      const far = !cam || Math.hypot(x - cam.position.x, z - cam.position.z) > 30;
      pos[i * 3] = x; pos[i * 3 + 1] = far ? 0.6 + Math.sin(life * Math.PI) * (1.5 + s[3] * 3) : -200; pos[i * 3 + 2] = z;
    }
    geo.attributes.position.needsUpdate = true;
  }
  return { update };
}

// wet surfaces in the storm: darker albedo, much lower roughness (env reflections read as wet asphalt) + puddle sheen
export const WET = { value: 0 };
export function wetify(m, puddles = true) {
  const prev = m.onBeforeCompile;
  m.onBeforeCompile = (sh, r) => {
    if (prev) prev(sh, r);
    sh.uniforms.uWet = WET;
    sh.vertexShader = sh.vertexShader.replace('#include <common>', '#include <common>\nvarying vec3 vWpW;').replace('#include <worldpos_vertex>', '#include <worldpos_vertex>\nvWpW = (modelMatrix * vec4(transformed, 1.0)).xyz;');
    sh.fragmentShader = sh.fragmentShader.replace('#include <common>', `#include <common>
uniform float uWet; varying vec3 vWpW;
float whash(vec2 p){ return fract(sin(dot(p,vec2(127.1,311.7)))*43758.5453); }
float wnoise(vec2 p){ vec2 i=floor(p), f=fract(p); f=f*f*(3.0-2.0*f); return mix(mix(whash(i),whash(i+vec2(1,0)),f.x),mix(whash(i+vec2(0,1)),whash(i+vec2(1,1)),f.x),f.y); }`)
      .replace('#include <roughnessmap_fragment>', `#include <roughnessmap_fragment>
      float pud = ${puddles ? 'smoothstep(0.55, 0.7, wnoise(vWpW.xz * 0.35) * 0.65 + wnoise(vWpW.xz * 1.3) * 0.35)' : '0.0'};
      roughnessFactor = mix(roughnessFactor, mix(0.14, 0.03, pud), uWet);
      diffuseColor.rgb *= mix(1.0, mix(0.55, 0.35, pud), uWet);`);
  };
  const key = m.customProgramCacheKey ? m.customProgramCacheKey() : '';
  m.customProgramCacheKey = () => key + 'wet' + (puddles ? 1 : 0);
  return m;
}
