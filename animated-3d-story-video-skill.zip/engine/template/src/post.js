// Post-processing: depth ink edges + depth of field, bloom, grade (zoom blur for whips, flash, vignette, saturation)
import * as THREE from 'three';
import { EffectComposer } from 'three/examples/jsm/postprocessing/EffectComposer.js';
import { RenderPass } from 'three/examples/jsm/postprocessing/RenderPass.js';
import { UnrealBloomPass } from 'three/examples/jsm/postprocessing/UnrealBloomPass.js';
import { ShaderPass } from 'three/examples/jsm/postprocessing/ShaderPass.js';
import { OutputPass } from 'three/examples/jsm/postprocessing/OutputPass.js';
import { FullScreenQuad } from 'three/examples/jsm/postprocessing/Pass.js';

// Depth-based ink edges (thick silhouettes at any resolution) + gather depth of field.
const DofInk = {
  uniforms: {
    tDiffuse: { value: null }, tDepth: { value: null },
    uNear: { value: 0.05 }, uFar: { value: 4000 }, uFocus: { value: 5 }, uAper: { value: 5 }, uFgMax: { value: 12 },
    uRes: { value: new THREE.Vector2(720, 1280) }, uInk: { value: new THREE.Color('#141113') }, uEdge: { value: 1 }, uEdgeFar: { value: 70 }, uAO: { value: 0.42 },
  },
  vertexShader: `varying vec2 vUv; void main(){ vUv=uv; gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.0); }`,
  fragmentShader: `#include <packing>
  uniform sampler2D tDiffuse; uniform sampler2D tDepth; uniform float uNear, uFar, uFocus, uAper, uFgMax, uEdge, uEdgeFar, uAO; uniform vec2 uRes; uniform vec3 uInk;
  varying vec2 vUv;
  float dist(vec2 uv){ float d = texture2D(tDepth, uv).x; if (d >= 0.99999) return 1e5; return -perspectiveDepthToViewZ(d, uNear, uFar); }
  float coc(float z){
    // pixels at 720 wide; background saturates at uAper, foreground grows toward uFgMax
    float c = z > uFocus ? uAper * clamp((z - uFocus) / z * 1.6, 0.0, 1.0) : min(uFgMax, uAper * (uFocus / z - 1.0) * 1.2);
    return max(c - 0.35, 0.0);
  }
  void main(){
    vec2 px = 1.0 / uRes; float k = uRes.x / 720.0;
    float zc = dist(vUv);
    float cc = coc(zc) * k;
    vec3 col = texture2D(tDiffuse, vUv).rgb;
    if (cc > 0.5) {
      vec3 acc = col; float wsum = 1.0;
      for (int i = 1; i < 20; i++) {
        float fi = float(i);
        float r = sqrt(fi / 20.0) * cc;
        float a = fi * 2.39996;
        vec2 o = vec2(cos(a), sin(a)) * r * px;
        float zs = dist(vUv + o);
        float cs = coc(zs) * k;
        // nearer, sharper samples must not bleed onto a blurred background
        float w = zs >= zc * 0.97 ? 1.0 : smoothstep(r - 1.0, r + 1.0, cs);
        acc += texture2D(tDiffuse, vUv + o).rgb * w; wsum += w;
      }
      col = acc / wsum;
    }
    // cheap screen-space ambient occlusion (crevices, contact under props) - v3
    if (zc < 220.0) {
      float ao = 0.0; float rad = clamp(240.0 / zc, 2.0, 22.0) * k;
      for (int i = 0; i < 10; i++) {
        float fi = float(i); float a = fi * 2.39996 + 0.6;
        vec2 o = vec2(cos(a), sin(a)) * rad * (0.35 + 0.65 * fract(fi * 0.618 + 0.3)) * px;
        float zs = dist(vUv + o); float dz = zc - zs;
        ao += smoothstep(0.015 * zc, 0.07 * zc, dz) * (1.0 - smoothstep(0.22 * zc, 0.4 * zc, dz));
      }
      col *= 1.0 - uAO * clamp(ao / 10.0 * 1.4, 0.0, 1.0);
    }
    // ink edges from the Laplacian of 1/z (zero on flat planes, large at silhouettes)
    if (uEdge > 0.0 && zc < uEdgeFar) {
      float s = 1.25 * k;
      float ic = 1.0 / zc;
      float l = 1.0 / dist(vUv + vec2(-s, 0.0) * px), r = 1.0 / dist(vUv + vec2(s, 0.0) * px);
      float u = 1.0 / dist(vUv + vec2(0.0, s) * px), d = 1.0 / dist(vUv + vec2(0.0, -s) * px);
      float lap = max(abs(2.0 * ic - l - r), abs(2.0 * ic - u - d)) / ic;
      // only mark the near side of a depth step
      float nearSide = 1.0 - step(ic * 1.15, max(max(l, r), max(u, d)));
      float e = smoothstep(0.10, 0.28, lap) * (1.0 - smoothstep(uEdgeFar * 0.6, uEdgeFar, zc));
      float blurFade = 1.0 - smoothstep(1.5, 5.0, cc / k);
      col = mix(col, uInk, e * uEdge * 0.92 * blurFade * max(nearSide, 0.55));
    }
    gl_FragColor = vec4(col, 1.0);
  }`,
};

class DofPass extends ShaderPass {
  render(renderer, writeBuffer, readBuffer, deltaTime, maskActive) {
    this.uniforms.tDepth.value = readBuffer.depthTexture;
    super.render(renderer, writeBuffer, readBuffer, deltaTime, maskActive);
  }
}

const Grade = {
  uniforms: {
    tDiffuse: { value: null }, uBlur: { value: 0 }, uMotion: { value: new THREE.Vector2(0, 0) }, uFlash: { value: 0 }, uDip: { value: 0 },
    uDipCol: { value: new THREE.Color('#f6eedc') }, uScope: { value: 0 }, uFlashCol: { value: new THREE.Color(0.75, 0.85, 1.0) }, uAspect: { value: 0.5625 }, uVig: { value: 0.35 }, uSat: { value: 1.12 }, uTime: { value: 0 }, uCon: { value: 0.22 }, uShTint: { value: new THREE.Color(0.93, 0.97, 1.06) }, uHiTint: { value: new THREE.Color(1.03, 1.0, 0.95) },
  },
  vertexShader: `varying vec2 vUv; void main(){ vUv=uv; gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.0); }`,
  fragmentShader: `uniform sampler2D tDiffuse; uniform vec2 uMotion; uniform float uBlur, uFlash, uDip, uVig, uSat, uTime, uCon, uScope, uAspect; uniform vec3 uDipCol, uShTint, uHiTint, uFlashCol; varying vec2 vUv;
  float hash(vec2 p){ return fract(sin(dot(p,vec2(12.9898,78.233)))*43758.5453); }
  void main(){
    vec3 c = texture2D(tDiffuse, vUv).rgb;
    // v4: camera motion blur along the pan direction (half-frame shutter)
    if (length(uMotion) > 0.0015) {
      vec3 acc = vec3(0.0);
      for (int i = 0; i < 12; i++) { float k = float(i) / 11.0 - 0.5; acc += texture2D(tDiffuse, vUv + uMotion * k).rgb; }
      c = acc / 12.0;
    }
    if (uBlur > 0.002) {
      vec2 d = vUv - vec2(0.5, 0.5);
      vec3 acc = vec3(0.0);
      for (int i = 0; i < 20; i++) { float k = float(i)/19.0; acc += texture2D(tDiffuse, vUv - d*k*uBlur*0.28).rgb; }
      c = acc/20.0;
    }
    float l = dot(c, vec3(0.2126,0.7152,0.0722));
    c = max(mix(vec3(l), c, uSat), 0.0);
    // v3 grade: gentle S-curve, cool shadows / warm highlights
    vec3 cc = clamp(c, 0.0, 1.0); c = mix(c, cc*cc*(3.0-2.0*cc), uCon);
    float l2 = dot(c, vec3(0.2126,0.7152,0.0722));
    c *= mix(uShTint, vec3(1.0), smoothstep(0.0, 0.45, l2));
    c *= mix(vec3(1.0), uHiTint, smoothstep(0.55, 1.0, l2));
    vec2 q = (vUv-0.5)*vec2(1.0,0.75);
    c *= 1.0 - uVig*smoothstep(0.25, 0.75, length(q));
    c += uFlash*uFlashCol;
    if (uScope > 0.5) { vec2 sp = (vUv - 0.5) * vec2(uAspect, 1.0); float r = length(sp); float R0 = 0.27;
      c *= 1.0 - 0.55 * smoothstep(R0 * 0.55, R0, r); c = mix(c, vec3(0.0), smoothstep(R0 - 0.004, R0 + 0.004, r));
      float lw = 0.0016; float cx = step(abs(sp.x), lw) * step(0.03, abs(sp.y)); float cy = step(abs(sp.y), lw) * step(0.03, abs(sp.x)); float thick = step(abs(sp.x), lw * 3.0) * step(0.12, abs(sp.y)) + step(abs(sp.y), lw * 3.0) * step(0.12, abs(sp.x));
      c = mix(c, vec3(0.02), clamp(cx + cy + thick, 0.0, 1.0) * step(r, R0)); }
    c = mix(c, uDipCol, uDip);
    c += (hash(vUv*1000.0+uTime)-0.5)*0.022;
    gl_FragColor = vec4(c, 1.0);
  }`,
};

const MixShader = {
  uniforms: { tDiffuse: { value: null }, tPrev: { value: null }, uK: { value: 1 } },
  vertexShader: `varying vec2 vUv; void main(){ vUv=uv; gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.0); }`,
  fragmentShader: `uniform sampler2D tDiffuse, tPrev; uniform float uK; varying vec2 vUv; void main(){ vec4 a = texture2D(tPrev, vUv); vec4 b = texture2D(tDiffuse, vUv); gl_FragColor = mix(a, b, uK); }`,
};
const CopyShader2 = { uniforms: { tDiffuse: { value: null } }, vertexShader: MixShader.vertexShader, fragmentShader: `uniform sampler2D tDiffuse; varying vec2 vUv; void main(){ gl_FragColor = texture2D(tDiffuse, vUv); }` };
export function makePost(gl, scene, camera) {
  const size = new THREE.Vector2(); gl.getDrawingBufferSize(size);
  const rt = new THREE.WebGLRenderTarget(size.x, size.y, { type: THREE.HalfFloatType, samples: 2 });
  rt.depthTexture = new THREE.DepthTexture(size.x, size.y); rt.depthTexture.type = THREE.UnsignedIntType;
  const composer = new EffectComposer(gl, rt);
  if (!composer.renderTarget2.depthTexture) { composer.renderTarget2.depthTexture = new THREE.DepthTexture(size.x, size.y); composer.renderTarget2.depthTexture.type = THREE.UnsignedIntType; }
  composer.addPass(new RenderPass(scene, camera));
  const dof = new DofPass(DofInk); composer.addPass(dof);
  const bloom = new UnrealBloomPass(new THREE.Vector2(size.x / 2, size.y / 2), 0.55, 0.55, 1.0);
  composer.addPass(bloom);
  const grade = new ShaderPass(Grade); composer.addPass(grade);
  composer.addPass(new OutputPass());
  const mix = new ShaderPass(MixShader); mix.enabled = false; composer.addPass(mix);
  const prevRT = new THREE.WebGLRenderTarget(size.x, size.y, { type: THREE.HalfFloatType });
  const copyQuad = new FullScreenQuad(new THREE.ShaderMaterial(CopyShader2));
  return {
    setSize(w, h) {
      composer.setPixelRatio(gl.getPixelRatio()); composer.setSize(w, h);
      const s = new THREE.Vector2(); gl.getDrawingBufferSize(s); dof.uniforms.uRes.value.copy(s); prevRT.setSize(s.x, s.y); grade.uniforms.uAspect.value = s.x / s.y;
    },
    render(t, st, mode) {
      dof.uniforms.uNear.value = camera.near; dof.uniforms.uFar.value = camera.far;
      dof.uniforms.uFocus.value = st.focus || 5;
      dof.uniforms.uAper.value = st.aper ?? 4;
      dof.uniforms.uFgMax.value = st.fgMax ?? 12;
      dof.uniforms.uEdge.value = st.edge ?? 0.4;
      grade.uniforms.uBlur.value = st.blur || 0;
      if (st.motion) grade.uniforms.uMotion.value.copy(st.motion); else grade.uniforms.uMotion.value.set(0, 0);
      grade.uniforms.uFlash.value = (st.flash || 0) * 0.45;
      grade.uniforms.uDip.value = st.dip || 0; if (st.dipCol) grade.uniforms.uDipCol.value.set(st.dipCol); // cream dip at location changes (0..1), computed in world.update
      grade.uniforms.uTime.value = t;
      // blue-hour grade (user boards): cool blue/purple shadows, golden highlights, rich but muted saturation
      grade.uniforms.uVig.value = 0.42; grade.uniforms.uSat.value = 1.02; grade.uniforms.uCon.value = 0.16;
      grade.uniforms.uShTint.value.setRGB(0.93, 0.96, 1.08); grade.uniforms.uHiTint.value.setRGB(1.06, 1.0, 0.9);
      dof.uniforms.uAO.value = st.ao ?? 0.42;
      bloom.strength = 0.55; bloom.threshold = 1.02; bloom.radius = 0.55;
      grade.uniforms.uScope.value = st.scope || 0; if (st.flashCol) grade.uniforms.uFlashCol.value.set(st.flashCol); else grade.uniforms.uFlashCol.value.setRGB(0.75, 0.85, 1.0);
      if (mode === 'capture') {
        mix.enabled = false; composer.renderToScreen = false; composer.render();
        copyQuad.material.uniforms.tDiffuse.value = composer.readBuffer.texture; const old = gl.getRenderTarget(); gl.setRenderTarget(prevRT); copyQuad.render(gl); gl.setRenderTarget(old);
        composer.renderToScreen = true; return;
      }
      if (st.mixK !== undefined && st.mixK !== null) { mix.enabled = true; mix.uniforms.tPrev.value = prevRT.texture; mix.uniforms.uK.value = st.mixK; } else mix.enabled = false;
      composer.render();
    },
  };
}
