// DEMO WORLD (template). Replace per story, keeping the contract:
//   buildWorld() -> { root, update(t, cam, scene, shotIdx) -> postState, initGL(gl) }
// One THREE.Group holds every location ("set") at different offsets; camera.js picks the set per shot.
// House style: true-3D white round-head characters (chars3d.js) inside realistic HDRI-lit PBR worlds (CC0 Poly Haven).
// Demo set "street": a cobbled street, a brick shop front with an in-world sign gag, crates, a lamp, a schemer, a crowd, a kid.
// The full WW1 world (examples/ww1_sniper/world.js) is the worked example of a finished 71 s Short.
import * as THREE from 'three';
import { rng, smooth, clamp, lerp, ramp, at, FONT } from './kit';
import { CHAR_LIGHT } from './chars';
import { Character, syncCharLight } from './chars3d';
import { A, placeModel, pbr } from './assets';
import { cameraFor, w } from './camera';

const E = (eyes, brows, mouth, extra = {}) => ({ eyes, brows, mouth, ...extra });

function canvasTex(wd, ht, draw) {
  const c = document.createElement('canvas'); c.width = wd; c.height = ht; draw(c.getContext('2d'), wd, ht);
  const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; t.anisotropy = 4; return t;
}

export function buildWorld() {
  const root = new THREE.Group();
  const R = rng(7);
  const std = (c, rough = 0.8, metal = 0, o = {}) => new THREE.MeshStandardMaterial({ color: c, roughness: rough, metalness: metal, ...o });
  // box with world-scaled UVs (ts metres per texture repeat) so PBR textures keep real-world scale
  const boxGeo = (wd, ht, dp, ts = 2) => {
    const g = new THREE.BoxGeometry(wd, ht, dp); const uv = g.attributes.uv;
    const dims = [[dp, ht], [dp, ht], [wd, dp], [wd, dp], [wd, ht], [wd, ht]];
    for (let f = 0; f < 6; f++) for (let k = 0; k < 4; k++) { const i = f * 4 + k; uv.setXY(i, uv.getX(i) * dims[f][0] / ts, uv.getY(i) * dims[f][1] / ts); }
    return g;
  };
  const box = (wd, ht, dp, m, x, y, z, parent = root, o = {}) => { const b = new THREE.Mesh(boxGeo(wd, ht, dp, o.ts || 2), m); b.position.set(x, y, z); if (o.ry) b.rotation.y = o.ry; b.castShadow = o.cast ?? true; b.receiveShadow = true; parent.add(b); return b; };
  const plane = (wd, dp, m, x, y, z, parent = root, uvs = 1) => { const g = new THREE.PlaneGeometry(wd, dp).rotateX(-Math.PI / 2); const uv = g.attributes.uv; for (let i = 0; i < uv.count; i++) uv.setXY(i, uv.getX(i) * wd / uvs, uv.getY(i) * dp / uvs); const p = new THREE.Mesh(g, m); p.position.set(x, y, z); p.receiveShadow = true; parent.add(p); return p; };

  // ---------------- materials (CC0 PBR sets listed in assets.json) ----------------
  const M = {
    cobble: pbr('cobblestone_02', { color: '#8a8478', rough: 0.95 }),
    brick: pbr('red_brick_plaster_patch_02', { color: '#a89888', rough: 0.95 }),
    planks: pbr('weathered_planks', { color: '#8a7a68', rough: 0.9 }),
    dark: std('#15110f', 1), wood: std('#4a3626', 0.85), glass: std('#0c131c', 0.04, 0.7, { envMapIntensity: 2.2 }),
    awning: std('#8a2a24', 0.7), gold: std('#e8b84a', 0.25, 1.0),
  };

  // ---------------- sky dome (photo sky from a *_puresky HDRI, graded cool/blue-hour) ----------------
  const skyMat = new THREE.ShaderMaterial({
    uniforms: { uSky: { value: A.sky.main || null }, uHas: { value: A.sky.main ? 1 : 0 }, uTint: { value: new THREE.Color(0.78, 0.84, 1.0) }, uExp: { value: 0.95 }, uRot: { value: 1.2 } },
    vertexShader: `varying vec3 vD; void main(){ vD = normalize(position); vec4 p = projectionMatrix * modelViewMatrix * vec4(position, 1.0); gl_Position = p.xyww; }`,
    fragmentShader: `uniform sampler2D uSky; uniform float uHas; uniform vec3 uTint; uniform float uExp, uRot; varying vec3 vD;
      void main(){ vec3 d = normalize(vD); float az = atan(d.z, d.x) + uRot; float u = az * 0.15915494 + 0.5; float el = asin(clamp(d.y, -1.0, 1.0)) * 57.29578;
        float v = clamp((el + 11.25) / 101.25, 0.004, 0.996);
        vec3 c = uHas > 0.5 ? texture2D(uSky, vec2(u, v)).rgb : mix(vec3(0.55, 0.6, 0.75), vec3(0.18, 0.24, 0.45), clamp(el / 60.0, 0.0, 1.0));
        float l = dot(c, vec3(0.2126, 0.7152, 0.0722));
        c = mix(vec3(l), c, 0.6) * uTint * uExp; c = mix(c, vec3(0.42, 0.45, 0.52), smoothstep(8.0, -6.0, el) * 0.7); gl_FragColor = vec4(c, 1.0); }`,
    side: THREE.BackSide, depthWrite: false, fog: false,
  });
  const sky = new THREE.Mesh(new THREE.SphereGeometry(900, 48, 24), skyMat); sky.renderOrder = -10; sky.frustumCulled = false; root.add(sky);

  // =====================================================================================================
  // SET "street" (around the origin): ground, shop front at z = -1.2, props layered fg/mg/bg
  // =====================================================================================================
  plane(60, 40, M.cobble, 0, 0, 0, root, 1.6);
  // shop front: brick wall with a window and a door (boxes around the openings)
  const WZ = -1.4;
  box(2.6, 4.2, 0.3, M.brick, -3.3, 2.1, WZ); box(2.6, 4.2, 0.3, M.brick, 3.3, 2.1, WZ);
  box(4.0, 1.4, 0.3, M.brick, 0, 3.5, WZ); box(4.0, 0.7, 0.3, M.brick, 0, 0.35, WZ);
  box(2.4, 1.9, 0.06, M.glass, -0.7, 1.65, WZ + 0.02, root, { cast: false }); box(1.1, 2.6, 0.08, M.wood, 1.35, 1.3, WZ + 0.05);
  box(12, 0.25, 0.5, M.dark, 0, 4.3, WZ + 0.1); // cornice
  // awning
  const aw = box(4.2, 0.08, 1.2, M.awning, 0, 2.95, WZ + 0.6); aw.rotation.x = 0.28;
  // in-world sign gag (labels live in the world; the only floating text is the captions)
  const sign = new THREE.Mesh(new THREE.PlaneGeometry(2.6, 0.62), new THREE.MeshStandardMaterial({ roughness: 0.55, map: canvasTex(1024, 244, (g, W, H) => {
    g.fillStyle = '#1d2a3a'; g.fillRect(0, 0, W, H); g.strokeStyle = '#e8b84a'; g.lineWidth = 14; g.strokeRect(10, 10, W - 20, H - 20);
    g.fillStyle = '#f3d27a'; g.font = `900 104px ${FONT}`; g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillText('REAL GOLD*', W / 2, H / 2 - 14);
    g.font = `700 34px ${FONT}`; g.fillStyle = '#d8d0c0'; g.fillText('*probably', W / 2 + 300, H - 38);
  }) }));
  sign.position.set(-0.2, 3.55, WZ + 0.17); root.add(sign);
  // background buildings so the frame never shows empty sky behind the set
  for (let i = 0; i < 6; i++) { const h = 6 + R() * 5; box(4 + R() * 2, h, 3, M.brick, -12 + i * 4.6, h / 2, -7 - R() * 3); }
  // props from Poly Haven (fg / mg / bg layers)
  const crate = placeModel('wooden_crate_01', { h: 0.55 }); at(crate, -2.2, 0, -0.4, 0.3); root.add(crate);
  const crate2 = placeModel('wooden_crate_01', { h: 0.45 }); at(crate2, -2.0, 0.55, -0.5, -0.2); root.add(crate2);
  const barrel = placeModel('barrel_03', { h: 0.8 }); at(barrel, 2.6, 0, -0.6, 0.4); root.add(barrel);
  const lamp = placeModel('street_lamp_01', { h: 3.6 }); at(lamp, 3.4, 0, 0.6); root.add(lamp);
  // the schemer's table with gold bars
  box(1.4, 0.06, 0.7, M.planks, -0.2, 0.78, 0.35); for (const x of [-0.8, 0.4]) for (const z of [0.1, 0.6]) box(0.06, 0.78, 0.06, M.wood, x, 0.39, z);
  const bars = []; for (let i = 0; i < 5; i++) { const b = box(0.22, 0.07, 0.1, M.gold, -0.55 + i * 0.17, 0.85, 0.4 + (i % 2) * 0.1); bars.push(b); }
  // warm practical light at the lamp (golden highlights against the cool sky)
  const lampL = new THREE.PointLight('#ffb766', 8, 9, 2); lampL.position.set(3.4, 3.3, 0.6); root.add(lampL);

  // =====================================================================================================
  // CHARACTERS (house design: white sphere head, line-art face decal, stick limbs, detailed torso outfit)
  // spec: { hat, outfit, top, bottom, shirt, tie, hair, mustache, glasses, seed, ... }   (see SKILL.md "Characters")
  // pose(t) -> { armL, armR (0 down .. 3 up), propL/propR/propC, crouch, lean, tilt, jump, walk, yawAbs, hatOff, headScale,
  //              expr: E(eyes, brows, mouth, { sweat, lines, blush, look, lookY }) }
  // =====================================================================================================
  const T = { every: w('everyone', 0, 1.9), but: w('but', 0, 3.2), magnet: w('magnet', 0, 4.4), gone: w('gone', 0, 5.2) };
  const chars = [];
  const add = (spec, o, pos) => { const c = new Character(spec, o); chars.push(c); root.add(c.root); if (pos) at(c.root, ...pos); return c; };
  const schemer = add({ hat: 'bowler', hatColor: '#2a2226', outfit: 'suit', top: '#3a2e5a', bottom: '#2a2238', shirt: '#f2ede0', tie: '#c8201e', mustache: '#2a1c14', watchChain: true, seed: 1 }, {
    pose: (t) => {
      if (t < T.but) return { armL: 1.2 + Math.sin(t * 5) * 0.15, armR: 2.4, propR: 'cheque', tilt: 0.05, expr: E('half', 'smug', 'smirk', { look: 0.4 }) };
      if (t < T.gone) return { armL: 0.8, armR: 1.1, expr: E('dot', 'worried', 'line', { look: 0.8, sweat: true, sweatY: (t * 30) % 60 }) };
      return { armL: 2.6, armR: 2.7, jump: Math.sin(clamp((t - T.gone) / 0.4, 0, 1) * Math.PI) * 20, expr: E('wide', 'shock', 'shout', { lines: true, sweat: true }) };
    },
  }, [-0.2, 0, -0.2]);
  const crowdCols = ['#4f7a5a', '#a0603a', '#5a6a9a'];
  const crowd = crowdCols.map((c, i) => add({ hat: i === 1 ? 'cap' : 'none', hair: i === 1 ? null : ['#5a3a22', '#c8742c', '#2a2420'][i], outfit: i === 2 ? 'vest' : 'tee', top: c, bottom: '#3a3a48', seed: 10 + i }, {
    pose: (t) => (t < T.magnet ? { armL: 2.2 + Math.sin(t * 6 + i) * 0.2, armR: 1.0, propL: 'bill', expr: E('happy', 'raised', 'grin', { look: -0.5 }) }
      : { armL: 0.8, armR: 0.9, expr: E('wide', 'raised', 'o', { look: -0.6 }) }),
  }, [-2.4 + i * 0.7, 0, 1.4 + (i % 2) * 0.35]));
  const kid = add({ hat: 'cap', hatColor: '#d03a2a', outfit: 'tee', top: '#e8c84a', bottom: '#2c4a78', seed: 21 }, {
    scale: 0.82,
    pose: (t) => (t < T.magnet ? { armL: 0.7, armR: 0.8, expr: E('dot', 'flat', 'line') } : { armL: 0.7, armR: 2.5, propR: 'pointer', expr: E('half', 'flat', 'smirk') }),
  }, [1.4, 0, 0.3]);
  kid.root.visible = true;

  // =====================================================================================================
  // LIGHTS: cool blue ambient + warm key from top right + gold rim on characters (house look)
  // =====================================================================================================
  const hemi = new THREE.HemisphereLight('#8f9fc0', '#3a3228', 0.9); root.add(hemi);
  const key = new THREE.DirectionalLight('#ffd2a0', 2.4); root.add(key); root.add(key.target);
  key.castShadow = true; key.shadow.mapSize.set(2048, 2048); key.shadow.bias = -0.0004; key.shadow.normalBias = 0.03;
  const envMaps = {};
  function initGL(gl) { const pm = new THREE.PMREMGenerator(gl); if (A.hdr.main) envMaps.main = pm.fromEquirectangular(A.hdr.main).texture; pm.dispose(); }
  const fog = new THREE.FogExp2('#6a7286', 0.02);

  function update(t, cam, scene, shotIdx) {
    const cs = cameraFor(shotIdx, t, cam);
    const shot = cs.shot;
    // story events on words: the magnet pulls the "gold" bars off the table on "gone"
    bars.forEach((b, i) => { const u = smooth(T.gone + i * 0.04, T.gone + 0.35 + i * 0.04, t); b.position.x = lerp(-0.55 + i * 0.17, 1.35, u); b.position.y = 0.85 + Math.sin(u * Math.PI) * 0.5 + u * 0.3; b.rotation.z = u * 4; });
    kid.root.position.x = lerp(2.4, 1.4, smooth(T.but - 0.1, T.but + 0.5, t));
    // characters (frustum-culled by the renderer; update every frame for pose + face)
    chars.forEach((c) => c.update(t, cam));
    // lighting
    scene.environment = envMaps.main || null; scene.environmentIntensity = 0.55; scene.environmentRotation.set(0, 1.0, 0);
    scene.fog = fog; scene.background = null;
    CHAR_LIGHT.rim.set('#ffc45a'); CHAR_LIGHT.rimAmt = 0.5; syncCharLight();
    const fwd = new THREE.Vector3().subVectors(cs.look, cam.position).setY(0).normalize(); const rgt = new THREE.Vector3(-fwd.z, 0, fwd.x);
    const kd = new THREE.Vector3().addScaledVector(rgt, 0.75).addScaledVector(fwd, 0.35).add(new THREE.Vector3(0, 0.75, 0)).normalize();
    CHAR_LIGHT.keyDir.copy(kd);
    const L = cs.look; const sz = clamp(cs.focus * 0.9, 3.5, 14);
    key.position.copy(L).addScaledVector(kd, 25); key.target.position.copy(L);
    const sc = key.shadow.camera; sc.left = -sz; sc.right = sz; sc.top = sz; sc.bottom = -sz; sc.near = 0.5; sc.far = 60; sc.updateProjectionMatrix();
    key.target.updateMatrixWorld(); key.updateMatrixWorld();
    cameraFor(shotIdx, t, cam);
    const hit = shot.kind === 'hard' ? Math.max(0, 1 - (t - shot.t) / 0.15) * 0.25 : 0; // tiny flash on jolt cuts
    return { blur: 0, flash: hit, flashCol: '#ffe2b0', focus: cs.focus, aper: cs.aper, fgMax: 8, motion: null, ao: 0.4, edge: 0.32, scope: shot.scope ? 1 : 0 };
  }
  return { root, update, initGL };
}
