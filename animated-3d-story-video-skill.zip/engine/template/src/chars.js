// 2D cartoon characters drawn on canvas, shown as camera-facing cards in the 3D world.
import * as THREE from 'three';
import { INK_HEX, rng, shade } from './kit';

const INKC = INK_HEX;
const SKIN = '#ffffff';

function wobCircle(g, cx, cy, r, seed = 1) {
  g.beginPath();
  for (let i = 0; i <= 64; i++) {
    const a = (i / 64) * Math.PI * 2;
    const rr = r * (1 + 0.007 * Math.sin(a * 5 + seed) + 0.005 * Math.sin(a * 9 + seed * 2));
    const x = cx + Math.cos(a) * rr, y = cy + Math.sin(a) * rr;
    i ? g.lineTo(x, y) : g.moveTo(x, y);
  }
  g.closePath();
}
function limb(g, x0, y0, x1, y1, w0, w1, bend = 0) {
  // tapered line with slight bend
  const mx = (x0 + x1) / 2 + bend * (y1 - y0) * 0.12, my = (y0 + y1) / 2 - bend * (x1 - x0) * 0.12;
  g.strokeStyle = INKC; g.lineCap = 'round';
  const N = 10; let px = x0, py = y0;
  for (let i = 1; i <= N; i++) {
    const t = i / N, a = 1 - t;
    const x = a * a * x0 + 2 * a * t * mx + t * t * x1, y = a * a * y0 + 2 * a * t * my + t * t * y1;
    g.lineWidth = w0 + (w1 - w0) * t; g.beginPath(); g.moveTo(px, py); g.lineTo(x, y); g.stroke(); px = x; py = y;
  }
}
function ink(g, w) { g.strokeStyle = INKC; g.lineWidth = w; g.lineJoin = 'round'; g.lineCap = 'round'; g.stroke(); }

// ---------------- face ----------------
// pure black line-art faces (reference Shorts): short thick angled brows carry the emotion
export function drawFace(g, cx, cy, s, e, sp) {
  const ex = 50 * s, ey = cy + 16 * s;
  const look = (e.look || 0) * 7 * s;
  const lookY = (e.lookY || 0) * 6 * s;
  for (const side of [-1, 1]) {
    const x = cx + side * ex;
    const type = e.eyes || 'dot';
    if (type === 'dot') { g.fillStyle = INKC; g.beginPath(); g.ellipse(x + look, ey + lookY, 12 * s, 18 * s, 0, 0, 7); g.fill(); }
    else if (type === 'half') {
      g.save(); g.beginPath(); g.rect(x - 30 * s, ey - 1 * s, 60 * s, 40 * s); g.clip();
      g.fillStyle = INKC; g.beginPath(); g.ellipse(x + look, ey + 2 * s, 13 * s, 16 * s, 0, 0, 7); g.fill(); g.restore();
      g.beginPath(); g.moveTo(x - 22 * s, ey - 2 * s); g.lineTo(x + 22 * s, ey - 2 * s); ink(g, 8 * s);
    } else if (type === 'happy') {
      g.beginPath(); g.arc(x, ey + 8 * s, 17 * s, Math.PI * 1.12, Math.PI * 1.88); ink(g, 9 * s);
    } else if (type === 'wide') {
      g.fillStyle = '#fff'; g.beginPath(); g.ellipse(x, ey - 6 * s, 27 * s, 31 * s, 0, 0, 7); g.fill(); ink(g, 7 * s);
      g.fillStyle = INKC; g.beginPath(); g.arc(x + look * 1.4, ey - 4 * s + lookY, 8 * s, 0, 7); g.fill();
    } else if (type === 'closed') {
      g.beginPath(); g.moveTo(x - 17 * s, ey); g.quadraticCurveTo(x, ey + 7 * s, x + 17 * s, ey); ink(g, 8 * s);
    } else if (type === 'squint') {
      g.beginPath(); g.moveTo(x - side * 16 * s, ey - 10 * s); g.lineTo(x + side * 14 * s, ey); g.lineTo(x - side * 16 * s, ey + 10 * s); ink(g, 8 * s);
    }
  }
  // brows
  const by = cy - 40 * s;
  const b = e.brows || 'flat';
  if (b !== 'none') for (const side of [-1, 1]) {
    const xi = cx + side * 26 * s, xo = cx + side * 70 * s;
    let yi = by, yo = by;
    if (b === 'angry') { yi += 18 * s; yo -= 8 * s; }
    if (b === 'worried') { yi -= 16 * s; yo += 10 * s; }
    if (b === 'raised') { yi -= 18 * s; yo -= 14 * s; }
    if (b === 'smug') { if (side > 0) { yi -= 16 * s; yo -= 22 * s; } else { yi += 6 * s; yo += 2 * s; } }
    if (b === 'shock') { yi -= 30 * s; yo -= 22 * s; }
    if (b === 'proud') { yi -= 6 * s; yo -= 20 * s; }
    // tapered thick brow
    const nx = -(yo - yi), ny = (xo - xi); const nl = Math.hypot(nx, ny) || 1;
    const w0 = 9 * s, w1 = 6 * s;
    g.fillStyle = INKC; g.beginPath();
    g.moveTo(xi + nx / nl * w0, yi + ny / nl * w0); g.lineTo(xo + nx / nl * w1, yo + ny / nl * w1);
    g.lineTo(xo - nx / nl * w1, yo - ny / nl * w1); g.lineTo(xi - nx / nl * w0, yi - ny / nl * w0); g.closePath(); g.fill();
    g.beginPath(); g.arc(xi, yi, w0, 0, 7); g.fill(); g.beginPath(); g.arc(xo, yo, w1, 0, 7); g.fill();
  }
  // glasses
  if (sp.glasses) {
    for (const side of [-1, 1]) { g.fillStyle = 'rgba(190,230,255,0.25)'; g.beginPath(); g.arc(cx + side * ex, ey - 2 * s, 32 * s, 0, 7); g.fill(); ink(g, 7 * s); }
    g.beginPath(); g.moveTo(cx - 18 * s, ey - 6 * s); g.quadraticCurveTo(cx, ey - 15 * s, cx + 18 * s, ey - 6 * s); ink(g, 6 * s);
    g.strokeStyle = 'rgba(255,255,255,0.8)'; g.lineWidth = 4 * s; for (const side of [-1, 1]) { g.beginPath(); g.arc(cx + side * ex, ey - 2 * s, 22 * s, Math.PI * 1.15, Math.PI * 1.4); g.stroke(); }
  }
  // mouth
  const my = cy + 84 * s; const m = e.mouth || 'line';
  if (m === 'line') { g.beginPath(); g.moveTo(cx - 20 * s, my); g.lineTo(cx + 20 * s, my); ink(g, 8 * s); }
  else if (m === 'smile') { g.beginPath(); g.arc(cx, my - 24 * s, 32 * s, Math.PI * 0.22, Math.PI * 0.78); ink(g, 8 * s); }
  else if (m === 'frown') { g.beginPath(); g.arc(cx, my + 22 * s, 26 * s, Math.PI * 1.25, Math.PI * 1.75); ink(g, 8 * s); }
  else if (m === 'smirk') { g.beginPath(); g.moveTo(cx - 28 * s, my + 2 * s); g.quadraticCurveTo(cx + 10 * s, my + 10 * s, cx + 34 * s, my - 14 * s); ink(g, 8 * s); }
  else if (m === 'grin' || m === 'grit') {
    const w = (m === 'grin' ? 60 : 64) * s, h = (m === 'grin' ? 44 : 30) * s, y0 = my - (m === 'grin' ? 18 : 10) * s;
    g.beginPath();
    if (m === 'grin') { g.moveTo(cx - w, y0); g.lineTo(cx + w, y0); g.quadraticCurveTo(cx + w * 0.92, y0 + h * 1.25, cx, y0 + h); g.quadraticCurveTo(cx - w * 0.92, y0 + h * 1.25, cx - w, y0); g.closePath(); }
    else g.roundRect(cx - w, y0, w * 2, h, 9 * s);
    g.fillStyle = '#fff'; g.fill();
    g.save(); g.clip();
    g.strokeStyle = INKC; g.lineWidth = 4.5 * s;
    for (let x = -w + w / 3; x < w - 2; x += w / 3) { g.beginPath(); g.moveTo(cx + x, y0); g.lineTo(cx + x, y0 + h * 1.3); g.stroke(); }
    if (m === 'grit') { g.beginPath(); g.moveTo(cx - w, y0 + h / 2); g.lineTo(cx + w, y0 + h / 2); g.stroke(); }
    g.restore();
    if (m === 'grin') { g.beginPath(); g.moveTo(cx - w, y0); g.lineTo(cx + w, y0); g.quadraticCurveTo(cx + w * 0.92, y0 + h * 1.25, cx, y0 + h); g.quadraticCurveTo(cx - w * 0.92, y0 + h * 1.25, cx - w, y0); g.closePath(); }
    else { g.beginPath(); g.roundRect(cx - w, y0, w * 2, h, 9 * s); }
    ink(g, 8 * s);
  } else if (m === 'open' || m === 'shout') {
    const big = m === 'shout' ? 1.25 : 1;
    g.fillStyle = INKC; g.beginPath();
    g.moveTo(cx - 38 * s * big, my - 14 * s); g.quadraticCurveTo(cx, my - 22 * s, cx + 38 * s * big, my - 14 * s);
    g.quadraticCurveTo(cx + 30 * s * big, my + 46 * s * big, cx, my + 50 * s * big); g.quadraticCurveTo(cx - 30 * s * big, my + 46 * s * big, cx - 38 * s * big, my - 14 * s); g.fill();
    g.save(); g.clip();
    g.fillStyle = '#fff'; g.fillRect(cx - 40 * s * big, my - 24 * s, 80 * s * big, 20 * s); // top teeth
    g.fillStyle = '#e0505a'; g.beginPath(); g.ellipse(cx, my + 44 * s * big, 24 * s, 14 * s, 0, 0, 7); g.fill();
    g.restore();
  } else if (m === 'o') { g.fillStyle = INKC; g.beginPath(); g.ellipse(cx, my, 14 * s, 19 * s, 0, 0, 7); g.fill(); }
  if (sp.mustache) {
    // bushy handlebar mustache
    const yy = my - 30 * s, mc = sp.mustache;
    g.fillStyle = mc; g.beginPath();
    g.moveTo(cx, yy - 12 * s);
    g.bezierCurveTo(cx + 26 * s, yy - 30 * s, cx + 58 * s, yy - 14 * s, cx + 76 * s, yy - 30 * s);
    g.bezierCurveTo(cx + 96 * s, yy - 40 * s, cx + 100 * s, yy - 12 * s, cx + 84 * s, yy - 4 * s);
    g.bezierCurveTo(cx + 74 * s, yy + 18 * s, cx + 34 * s, yy + 22 * s, cx + 14 * s, yy + 12 * s);
    g.quadraticCurveTo(cx, yy + 6 * s, cx - 14 * s, yy + 12 * s);
    g.bezierCurveTo(cx - 34 * s, yy + 22 * s, cx - 74 * s, yy + 18 * s, cx - 84 * s, yy - 4 * s);
    g.bezierCurveTo(cx - 100 * s, yy - 12 * s, cx - 96 * s, yy - 40 * s, cx - 76 * s, yy - 30 * s);
    g.bezierCurveTo(cx - 58 * s, yy - 14 * s, cx - 26 * s, yy - 30 * s, cx, yy - 12 * s);
    g.fill(); ink(g, 6 * s);
    g.strokeStyle = 'rgba(53,31,34,0.45)'; g.lineWidth = 3 * s;
    for (const side of [-1, 1]) for (let k = 0; k < 4; k++) { g.beginPath(); g.moveTo(cx + side * (12 + k * 15) * s, yy - 8 * s); g.lineTo(cx + side * (18 + k * 15) * s, yy + 8 * s); g.stroke(); }
  }
  if (e.sweat) {
    for (const [dx, dy, k] of [[134, -64, 1], [-140, -20, 0.7]]) {
      if (k < 1 && !e.sweat2) continue;
      const sx = cx + dx * s, sy = cy + dy * s + ((e.sweatY || 0) * k) * s;
      g.fillStyle = '#9fe0ff'; g.beginPath(); g.moveTo(sx, sy - 30 * s * k);
      g.quadraticCurveTo(sx + 19 * s * k, sy, sx, sy + 14 * s * k); g.quadraticCurveTo(sx - 19 * s * k, sy, sx, sy - 30 * s * k); g.fill(); ink(g, 5 * s);
      g.fillStyle = '#fff'; g.beginPath(); g.arc(sx - 5 * s * k, sy, 4 * s * k, 0, 7); g.fill();
    }
  }
  if (e.blush) { g.fillStyle = 'rgba(255,120,140,0.45)'; for (const side of [-1, 1]) { g.beginPath(); g.ellipse(cx + side * 84 * s, ey + 42 * s, 22 * s, 12 * s, 0, 0, 7); g.fill(); } }
  if (e.lines) { // panic / shock marks around the head
    g.strokeStyle = INKC; g.lineWidth = 6 * s; g.lineCap = 'round';
    for (const [a, l] of [[-2.5, 26], [-2.0, 32], [-1.1, 32], [-0.6, 26]]) { const r0 = 178 * s; g.beginPath(); g.moveTo(cx + Math.cos(a) * r0, cy + Math.sin(a) * r0); g.lineTo(cx + Math.cos(a) * (r0 + l * s), cy + Math.sin(a) * (r0 + l * s)); g.stroke(); }
  }
}

export function hairCap(g, cx, cy, r, s, sp) {
  // flat cap of colour: fringe across the top, tufts peeking at the sides
  g.fillStyle = sp.hair; g.beginPath();
  g.moveTo(cx - r * 1.05, cy - r * 0.2);
  const n = sp.curls ? 9 : 7;
  for (let i = 0; i <= n; i++) {
    const x0 = cx - r * 1.02 + i * (2.04 * r / n), x1 = x0 + 2.04 * r / n;
    const yb = cy - r * (sp.hat === 'none' || !sp.hat ? 0.5 : 0.42) + (i % 2) * 10 * s;
    g.quadraticCurveTo((x0 + x1) / 2, yb + (sp.curls ? 26 : 16) * s, x1, yb - 4 * s);
  }
  g.lineTo(cx + r * 1.1, cy - r * 1.3); g.lineTo(cx - r * 1.1, cy - r * 1.3); g.closePath(); g.fill();
  // side tufts / sideburns
  for (const side of [-1, 1]) { g.beginPath(); g.ellipse(cx + side * r * 0.9, cy - r * 0.3, r * 0.2, r * 0.34, side * 0.25, 0, 7); g.fill(); }
}

// --------------- head with hat ---------------
export function drawHead(g, cx, cy, s, sp, e, rim) {
  const r = 150 * s;
  wobCircle(g, cx, cy, r, sp.seed || 1);
  g.fillStyle = SKIN; g.fill();
  g.save(); wobCircle(g, cx, cy, r, sp.seed || 1); g.clip();
  // key light from upper left: soft crescent shade on the lower right
  
  if (sp.hair) hairCap(g, cx, cy, r, s, sp);
  if (rim) { g.strokeStyle = rim; g.lineWidth = 22 * s; g.beginPath(); g.arc(cx, cy, r - 4 * s, -1.1, 0.9); g.stroke(); }
  g.restore();
  wobCircle(g, cx, cy, r, sp.seed || 1); ink(g, 22 * s);
  drawFace(g, cx, cy, s, e, sp);
  // hats
  const hc = sp.hatColor || '#f2c230';
  if (sp.hat === 'hardhat') {
    g.beginPath(); g.ellipse(cx, cy - r * 0.5, r * 1.0, r * 0.8, 0, Math.PI, 0); g.closePath();
    g.fillStyle = hc; g.fill(); ink(g, 13 * s);
    g.save(); g.clip(); g.fillStyle = 'rgba(0,0,0,0.12)'; g.beginPath(); g.ellipse(cx + r * 0.5, cy - r * 0.5, r * 0.7, r * 0.9, 0, 0, 7); g.fill(); g.restore();
    g.beginPath(); g.moveTo(cx - 16 * s, cy - r * 1.27); g.lineTo(cx - 16 * s, cy - r * 0.52); g.moveTo(cx + 16 * s, cy - r * 1.27); g.lineTo(cx + 16 * s, cy - r * 0.52); ink(g, 7 * s);
    g.beginPath(); g.roundRect(cx - r * 1.2, cy - r * 0.6, r * 2.4, 30 * s, 14 * s); g.fillStyle = hc; g.fill(); ink(g, 12 * s);
    g.fillStyle = 'rgba(255,255,255,0.5)'; g.beginPath(); g.ellipse(cx - r * 0.45, cy - r * 0.98, 26 * s, 12 * s, -0.5, 0, 7); g.fill();
  } else if (sp.hat === 'bowler') {
    g.beginPath(); g.ellipse(cx, cy - r * 0.64, r * 0.84, r * 0.8, 0, Math.PI, 0); g.closePath(); g.fillStyle = hc; g.fill(); ink(g, 13 * s);
    g.fillStyle = sp.band || '#6a3a42'; g.fillRect(cx - r * 0.82, cy - r * 0.84, r * 1.64, 24 * s);
    g.beginPath(); g.ellipse(cx, cy - r * 0.62, r * 1.18, 28 * s, 0, 0, 7); g.fillStyle = hc; g.fill(); ink(g, 12 * s);
    g.fillStyle = 'rgba(255,255,255,0.3)'; g.beginPath(); g.ellipse(cx - r * 0.38, cy - r * 1.12, 30 * s, 11 * s, -0.4, 0, 7); g.fill();
  } else if (sp.hat === 'fedora') {
    g.beginPath(); g.moveTo(cx - r * 0.84, cy - r * 0.64); g.lineTo(cx - r * 0.72, cy - r * 1.32); g.quadraticCurveTo(cx, cy - r * 1.12, cx + r * 0.72, cy - r * 1.32); g.lineTo(cx + r * 0.84, cy - r * 0.64); g.closePath();
    g.fillStyle = hc; g.fill(); ink(g, 13 * s);
    g.fillStyle = sp.band || '#3a2a2a'; g.beginPath(); g.moveTo(cx - r * 0.82, cy - r * 0.68); g.lineTo(cx + r * 0.82, cy - r * 0.68); g.lineTo(cx + r * 0.8, cy - r * 0.88); g.lineTo(cx - r * 0.8, cy - r * 0.88); g.fill();
    g.beginPath(); g.ellipse(cx, cy - r * 0.62, r * 1.32, 32 * s, 0, 0, 7); g.fillStyle = hc; g.fill(); ink(g, 12 * s);
    g.beginPath(); g.moveTo(cx, cy - r * 1.2); g.lineTo(cx, cy - r * 0.92); ink(g, 6 * s);
  } else if (sp.hat === 'cap') {
    g.beginPath(); g.ellipse(cx, cy - r * 0.52, r * 1.0, r * 0.68, 0, Math.PI, 0); g.closePath(); g.fillStyle = hc; g.fill(); ink(g, 13 * s);
    if (sp.capStripes) { g.save(); g.clip(); g.strokeStyle = sp.capStripes; g.lineWidth = 9 * s; for (let x = -r; x < r; x += 26 * s) { g.beginPath(); g.moveTo(cx + x, cy - r * 1.2); g.lineTo(cx + x, cy - r * 0.4); g.stroke(); } g.restore(); g.beginPath(); g.ellipse(cx, cy - r * 0.52, r * 1.0, r * 0.68, 0, Math.PI, 0); g.closePath(); ink(g, 13 * s); }
    if (sp.capBadge) { g.fillStyle = '#ffd23a'; g.beginPath(); for (let k = 0; k < 10; k++) { const a = -Math.PI / 2 + k * Math.PI / 5, rr = (k % 2 ? 9 : 22) * s; g.lineTo(cx + Math.cos(a) * rr, cy - r * 0.86 + Math.sin(a) * rr); } g.closePath(); g.fill(); ink(g, 4 * s); }
    g.beginPath(); g.ellipse(cx + r * 0.6, cy - r * 0.52, r * 0.66, 22 * s, 0.08, 0, 7); g.fillStyle = hc; g.fill(); ink(g, 11 * s);
    g.fillStyle = INKC; g.beginPath(); g.arc(cx, cy - r * 1.18, 10 * s, 0, 7); g.fill();
  } else if (sp.hat === 'goggles') {
    g.strokeStyle = '#4b3b40'; g.lineWidth = 18 * s; g.beginPath(); g.moveTo(cx - r * 0.98, cy - r * 0.55); g.quadraticCurveTo(cx, cy - r * 0.8, cx + r * 0.98, cy - r * 0.55); g.stroke();
    for (const side of [-1, 1]) { g.beginPath(); g.ellipse(cx + side * 48 * s, cy - r * 0.68, 32 * s, 24 * s, 0, 0, 7); g.fillStyle = '#9ad8e8'; g.fill(); ink(g, 9 * s); g.fillStyle = 'rgba(255,255,255,0.7)'; g.beginPath(); g.ellipse(cx + side * 48 * s - 10 * s, cy - r * 0.72, 9 * s, 6 * s, -0.5, 0, 7); g.fill(); }
  } else if (sp.hat === 'rainhat') {
    g.beginPath(); g.ellipse(cx, cy - r * 0.55, r * 0.92, r * 0.72, 0, Math.PI, 0); g.closePath(); g.fillStyle = hc; g.fill(); ink(g, 13 * s);
    g.beginPath(); g.moveTo(cx - r * 1.3, cy - r * 0.38); g.quadraticCurveTo(cx, cy - r * 0.8, cx + r * 1.3, cy - r * 0.38); g.quadraticCurveTo(cx, cy - r * 0.6, cx - r * 1.3, cy - r * 0.38); g.fillStyle = hc; g.fill(); ink(g, 11 * s);
  }
}

// --------------- props ---------------
// texts painted on 2D props - set per story, e.g. PROP_TEXT.cheque = ['$440,000,000', 'PAY TO: THE BANK']
export const PROP_TEXT = { cheque: ['$1,000,000', 'PAY TO: THE BEARER'] };
export function drawProp(g, type, x, y, s, side, t) {
  g.save(); g.translate(x, y);
  if (type === 'wrench') {
    g.rotate(-0.6 * side); g.fillStyle = '#b8c2cc'; g.beginPath(); g.roundRect(-8, -95, 16, 100, 6); g.fill(); ink(g, 6);
    g.beginPath(); g.arc(0, -105, 24, 0.9, Math.PI * 2.1); g.lineTo(0, -105); g.fill(); ink(g, 6);
  } else if (type === 'brush') {
    g.rotate(-0.9 * side); g.fillStyle = '#c78a4a'; g.beginPath(); g.roundRect(-7, -80, 14, 85, 5); g.fill(); ink(g, 5);
    g.fillStyle = '#d33a2c'; g.beginPath(); g.roundRect(-16, -122, 32, 44, 6); g.fill(); ink(g, 6);
  } else if (type === 'pointer') {
    g.rotate(side * -1.0); g.strokeStyle = '#8a5a34'; g.lineWidth = 9; g.beginPath(); g.moveTo(0, 0); g.lineTo(0, -200); g.stroke();
    g.beginPath(); g.moveTo(0, 0); g.lineTo(0, -200); g.lineWidth = 12; g.strokeStyle = INKC; g.globalCompositeOperation = 'destination-over'; g.stroke();
  } else if (type === 'chalk') { g.fillStyle = '#fff'; g.fillRect(-6, -24, 12, 26); ink(g, 4); }
  else if (type === 'clipboard') {
    g.rotate(-0.15 * side); g.fillStyle = '#b07a44'; g.beginPath(); g.roundRect(-55, -80, 110, 140, 8); g.fill(); ink(g, 7);
    g.fillStyle = '#fff'; g.fillRect(-42, -62, 84, 112); g.fillStyle = '#9aa'; for (let i = 0; i < 6; i++) g.fillRect(-34, -48 + i * 17, 60 - (i % 2) * 18, 5);
    g.fillStyle = '#ccc'; g.fillRect(-22, -88, 44, 18); g.strokeRect(-22, -88, 44, 18);
  } else if (type === 'slimModel') {
    g.rotate(-0.04); g.translate(0, -40); g.fillStyle = '#4caf7d'; g.beginPath(); g.roundRect(-200, -22, 400, 22, 5); g.fill(); ink(g, 7);
    for (const xx of [-95, 95]) { g.fillStyle = '#3e8b6b'; g.beginPath(); g.rect(xx - 9, -120, 18, 110); g.fill(); ink(g, 6); }
    g.beginPath(); g.moveTo(-200, -22); g.quadraticCurveTo(-130, -110, -95, -120); g.quadraticCurveTo(0, -20, 95, -120); g.quadraticCurveTo(130, -110, 200, -22); ink(g, 5);
  } else if (type === 'flag') {
    g.strokeStyle = INKC; g.lineWidth = 6; g.beginPath(); g.moveTo(0, 0); g.lineTo(0, -150); g.stroke();
    const wv = Math.sin(t * 9) * 8;
    g.fillStyle = '#d8323c'; g.beginPath(); g.moveTo(0, -150); g.lineTo(90, -150 + wv); g.lineTo(90, -95 + wv); g.lineTo(0, -95); g.closePath(); g.fill();
    g.fillStyle = '#fff'; for (let i = 0; i < 3; i++) g.fillRect(2, -140 + i * 18, 86, 6);
    g.fillStyle = '#2b4c9b'; g.fillRect(0, -150, 36, 30); g.beginPath(); g.moveTo(0, -150); g.lineTo(90, -150 + wv); g.lineTo(90, -95 + wv); g.lineTo(0, -95); g.closePath(); ink(g, 5);
  } else if (type === 'stopwatch') {
    g.fillStyle = '#e8e8ea'; g.beginPath(); g.arc(0, -30, 34, 0, 7); g.fill(); ink(g, 7);
    g.beginPath(); g.moveTo(0, -30); g.lineTo(Math.sin(t * 6) * 24, -30 - Math.cos(t * 6) * 24); ink(g, 5);
    g.fillStyle = '#e8e8ea'; g.fillRect(-7, -76, 14, 12);
  } else if (type === 'balloon') {
    const sw = Math.sin(t * 2.3) * 10;
    g.strokeStyle = INKC; g.lineWidth = 3; g.beginPath(); g.moveTo(0, 0); g.quadraticCurveTo(14 + sw, -110, sw, -230); g.stroke();
    g.fillStyle = '#e8322e'; g.beginPath(); g.ellipse(sw, -290, 50, 62, 0.1, 0, 7); g.fill(); ink(g, 7);
    g.fillStyle = 'rgba(255,255,255,0.6)'; g.beginPath(); g.ellipse(sw - 18, -312, 12, 18, 0.4, 0, 7); g.fill();
  } else if (type === 'laptop') {
    g.rotate(-0.05 * side); g.fillStyle = '#2a2d34'; g.beginPath(); g.roundRect(-78, -112, 156, 104, 8); g.fill(); ink(g, 6);
    const lg = g.createLinearGradient(0, -104, 0, -16); lg.addColorStop(0, '#5ce08a'); lg.addColorStop(1, '#1f8a55'); g.fillStyle = lg; g.fillRect(-68, -102, 136, 84);
    g.fillStyle = '#0d2a1a'; for (let i = 0; i < 5; i++) g.fillRect(-58, -92 + i * 15, 40 + ((i * 37) % 70), 6);
    g.fillStyle = '#9aa0aa'; g.beginPath(); g.moveTo(-88, -8); g.lineTo(88, -8); g.lineTo(98, 10); g.lineTo(-98, 10); g.closePath(); g.fill(); ink(g, 6);
  } else if (type === 'mug') {
    g.fillStyle = '#e8e2d4'; g.beginPath(); g.roundRect(-26, -62, 52, 62, 8); g.fill(); ink(g, 6);
    g.beginPath(); g.arc(30, -32, 14, -1.3, 1.3); ink(g, 7); g.fillStyle = '#c8202a'; g.fillRect(-18, -44, 36, 10);
    g.strokeStyle = 'rgba(255,255,255,0.7)'; g.lineWidth = 4; const w = Math.sin(t * 4) * 5; g.beginPath(); g.moveTo(-6, -72); g.quadraticCurveTo(-14 + w, -92, -4, -110); g.moveTo(10, -72); g.quadraticCurveTo(2 - w, -94, 12, -112); g.stroke();
  } else if (type === 'cheque') {
    g.rotate(-0.06 * side); g.translate(side * -150, 40); g.fillStyle = '#f3ecd6'; g.beginPath(); g.roundRect(-190, -120, 380, 170, 10); g.fill(); ink(g, 8);
    g.fillStyle = '#2f7a4a'; g.fillRect(-190, -120, 380, 26); g.fillStyle = '#1a1a1a'; g.font = '900 54px Poppins, Arial Black, sans-serif'; g.textAlign = 'center'; g.textBaseline = 'middle';
    g.fillText(PROP_TEXT.cheque[0], 0, -30); g.font = '700 22px Poppins, Arial, sans-serif'; g.fillText(PROP_TEXT.cheque[1], 0, 20);
  } else if (type === 'phone') {
    g.rotate(-0.25 * side); g.fillStyle = '#1b1c20'; g.beginPath(); g.roundRect(-30, -96, 60, 112, 10); g.fill(); ink(g, 6);
    const gr = g.createLinearGradient(0, -88, 0, 8); gr.addColorStop(0, '#7fd6ff'); gr.addColorStop(1, '#2f6bd8'); g.fillStyle = gr; g.fillRect(-23, -86, 46, 92);
    g.fillStyle = '#fff'; g.fillRect(-17, -76, 34, 6); g.fillRect(-17, -64, 26, 6); g.fillStyle = '#ffd23a'; g.fillRect(-17, -48, 34, 30);
  } else if (type === 'noodles') {
    // bowl held low, chopsticks lifting a few noodles that keep slipping off
    const sl = (t * 1.6) % 1;
    g.fillStyle = '#c8322c'; g.beginPath(); g.moveTo(-62, -30); g.lineTo(62, -30); g.quadraticCurveTo(56, 34, 0, 36); g.quadraticCurveTo(-56, 34, -62, -30); g.closePath(); g.fill(); ink(g, 6);
    g.fillStyle = '#f4c430'; g.fillRect(-60, -20, 120, 8);
    g.fillStyle = '#f1dca0'; g.beginPath(); g.ellipse(0, -30, 60, 12, 0, 0, 7); g.fill(); ink(g, 5);
    g.save(); g.rotate(-0.35 * side);
    g.strokeStyle = '#8a5a34'; g.lineWidth = 7; g.lineCap = 'round'; for (const dx of [-8, 8]) { g.beginPath(); g.moveTo(dx, -20); g.lineTo(dx * 1.6 + 40 * side, -190); g.stroke(); }
    g.strokeStyle = '#f6e3a8'; g.lineWidth = 5; for (let k = 0; k < 4; k++) { const yy = -130 + sl * 100 + k * 6; g.beginPath(); g.moveTo(-4 + 24 * side, yy - 30); g.quadraticCurveTo(10 + 24 * side + k * 4, yy + 20, 6 + k * 5, yy + 50); g.stroke(); }
    g.restore();
  } else if (type === 'dripstick') {
    // long measuring stick with cm marks, held upright
    g.rotate(-0.08 * side); g.fillStyle = '#d8d2c0'; g.beginPath(); g.roundRect(-9, -330, 18, 360, 5); g.fill(); ink(g, 6);
    g.fillStyle = INKC; for (let i = 0; i < 16; i++) g.fillRect(-9, -320 + i * 20, i % 5 ? 8 : 14, 3);
    g.fillStyle = '#d8352a'; g.fillRect(-9, -330, 18, 26);
  } else if (type === 'card177') {
    g.rotate(-0.1 * side); g.scale(1.35, 1.35); g.fillStyle = '#fff6dc'; g.beginPath(); g.roundRect(-92, -150, 184, 120, 10); g.fill(); ink(g, 7);
    g.fillStyle = '#c8232c'; g.font = '900 64px Poppins, Arial Black, sans-serif'; g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillText('1.77', 0, -104);
    g.fillStyle = INKC; g.font = '800 30px Poppins, Arial Black, sans-serif'; g.fillText('LB / L', 0, -55);
  } else if (type === 'map') {
    g.rotate(0.12 * side); g.fillStyle = '#efe6c8'; g.beginPath(); g.rect(-120, -170, 240, 160); g.fill(); ink(g, 7);
    g.fillStyle = '#8fc0e0'; g.beginPath(); g.ellipse(50, -110, 46, 70, 0.3, 0, 7); g.fill();
    g.strokeStyle = '#7a8a6a'; g.lineWidth = 3; for (let i = 0; i < 4; i++) { g.beginPath(); g.moveTo(-110, -150 + i * 35); g.lineTo(110, -140 + i * 33); g.stroke(); }
    g.strokeStyle = '#d8352a'; g.lineWidth = 7; g.beginPath(); g.arc(4, -86, 20, 0, 7); g.stroke();
    g.fillStyle = INKC; g.font = '900 34px Poppins, Arial Black, sans-serif'; g.textAlign = 'center'; g.fillText('GIMLI', -40, -30);
  } else if (type === 'checklist') {
    g.rotate(-0.1 * side); g.fillStyle = '#c8232c'; g.beginPath(); g.roundRect(-110, -160, 220, 150, 8); g.fill(); ink(g, 7);
    g.fillStyle = '#fbf8ee'; g.fillRect(-100, -150, 96, 130); g.fillRect(4, -150, 96, 130);
    g.fillStyle = '#9aa'; for (let i = 0; i < 6; i++) g.fillRect(-90, -136 + i * 18, 70 - (i % 2) * 20, 5);
    g.fillStyle = '#c8232c'; g.font = '900 40px Poppins, Arial Black, sans-serif'; g.textAlign = 'center'; g.fillText('?', 52, -70);
  } else if (type === 'jerrycan') {
    g.rotate(0.05 * side); g.fillStyle = '#c8322c'; g.beginPath(); g.roundRect(-50, 0, 100, 130, 10); g.fill(); ink(g, 7);
    g.strokeStyle = INKC; g.lineWidth = 5; g.beginPath(); g.moveTo(-40, 20); g.lineTo(40, 110); g.moveTo(40, 20); g.lineTo(-40, 110); g.stroke();
    g.fillStyle = '#c8322c'; g.fillRect(-20, -14, 40, 16); ink(g, 5);
  } else if (type === 'bomb') {
    // round black cartoon bomb with a stubby fuse cap and a fizzing spark
    g.fillStyle = '#1c1c22'; g.beginPath(); g.arc(0, -46, 44, 0, 7); g.fill(); ink(g, 6);
    g.fillStyle = 'rgba(255,255,255,0.35)'; g.beginPath(); g.ellipse(-16, -64, 12, 8, -0.6, 0, 7); g.fill();
    g.fillStyle = '#5a5a62'; g.fillRect(-12, -100, 24, 16); g.strokeStyle = INKC; g.lineWidth = 4; g.strokeRect(-12, -100, 24, 16);
    g.strokeStyle = '#c8a878'; g.lineWidth = 5; g.beginPath(); g.moveTo(0, -100); g.quadraticCurveTo(14, -120, 6, -136); g.stroke();
    const fz = 0.7 + 0.3 * Math.sin(t * 40); g.fillStyle = '#ffd23a'; for (let k = 0; k < 6; k++) { const a = k * 1.05 + t * 9; g.beginPath(); g.arc(6 + Math.cos(a) * 12 * fz, -138 + Math.sin(a) * 12 * fz, 4, 0, 7); g.fill(); }
    g.fillStyle = '#fff6c8'; g.beginPath(); g.arc(6, -138, 7, 0, 7); g.fill();
  } else if (type === 'binoculars') {
    g.translate(0, -30); g.fillStyle = '#2a2a24'; for (const dx of [-26, 26]) { g.beginPath(); g.roundRect(dx - 20, -46, 40, 70, 10); g.fill(); ink(g, 6); g.fillStyle = '#6a8a9a'; g.beginPath(); g.ellipse(dx, -46, 16, 7, 0, 0, 7); g.fill(); g.fillStyle = '#2a2a24'; }
    g.fillStyle = '#4a4a3a'; g.fillRect(-8, -26, 16, 22); ink(g, 4);
  } else if (type === 'fieldphone') {
    // WWI field telephone: leather box with a crank, handset held up
    g.rotate(-0.1 * side); g.fillStyle = '#5a3e22'; g.beginPath(); g.roundRect(-60, -40, 120, 90, 10); g.fill(); ink(g, 6);
    g.fillStyle = '#3a2a16'; g.fillRect(-50, -30, 100, 10); g.strokeStyle = '#c8c8c0'; g.lineWidth = 6; g.beginPath(); g.moveTo(60, 0); g.lineTo(84, 0); g.lineTo(84, 24); g.stroke();
    g.fillStyle = '#1c1c20'; g.beginPath(); g.roundRect(-46, -112, 92, 26, 12); g.fill(); ink(g, 5);
    g.strokeStyle = '#1c1c20'; g.lineWidth = 4; g.beginPath(); g.moveTo(-40, -86); g.quadraticCurveTo(-70, -40, -50, -10); g.stroke();
  } else if (type === 'watch') {
    g.translate(0, -24); g.fillStyle = '#d8b04a'; g.beginPath(); g.arc(0, 0, 30, 0, 7); g.fill(); ink(g, 6);
    g.fillStyle = '#f6f0dc'; g.beginPath(); g.arc(0, 0, 23, 0, 7); g.fill();
    g.strokeStyle = INKC; g.lineWidth = 4; g.beginPath(); g.moveTo(0, 0); g.lineTo(Math.sin(t * 6) * 18, -Math.cos(t * 6) * 18); g.moveTo(0, 0); g.lineTo(10, -6); g.stroke();
    g.strokeStyle = '#d8b04a'; g.lineWidth = 5; g.beginPath(); g.arc(0, -38, 8, 0, 7); g.stroke();
  } else if (type === 'bill') {
    g.rotate(-0.2 * side); g.fillStyle = '#9ac890'; g.beginPath(); g.rect(-70, -110, 140, 66); g.fill(); ink(g, 5);
    g.strokeStyle = '#4a7a4a'; g.lineWidth = 3; g.strokeRect(-62, -102, 124, 50); g.fillStyle = '#2f5a2f'; g.font = '900 40px Poppins, Arial Black, sans-serif'; g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillText('$', 0, -77);
  } else if (type === 'blueprint') {
    g.rotate(0.3 * side); g.fillStyle = '#2f6fc0'; g.beginPath(); g.roundRect(-16, -110, 32, 130, 14); g.fill(); ink(g, 6);
  }
  g.restore();
}

// --------------- full standing figure ---------------
// canvas 512 x 1024, feet at y ~ 1000
export function torsoPath(g, cx, ty) {
  g.beginPath(); g.moveTo(cx, 486 + ty);
  g.bezierCurveTo(cx + 70, 486 + ty, cx + 94, 560 + ty, cx + 100, 624 + ty);
  g.bezierCurveTo(cx + 106, 698 + ty, cx + 68, 734 + ty, cx, 734 + ty);
  g.bezierCurveTo(cx - 68, 734 + ty, cx - 106, 698 + ty, cx - 100, 624 + ty);
  g.bezierCurveTo(cx - 94, 560 + ty, cx - 70, 486 + ty, cx, 486 + ty); g.closePath();
}
function button(g, x, y, r, col) { g.fillStyle = col; g.beginPath(); g.arc(x, y, r, 0, 7); g.fill(); g.strokeStyle = INKC; g.lineWidth = 3; g.stroke(); }

export function drawTorsoFill(g, sp, cx, ty, p = {}) {
  const o = sp.outfit;
  const pantsY = 660 + ty;
  if (o === 'overalls') {
    g.fillStyle = sp.shirt || '#e9e2d0'; g.fillRect(0, 0, 512, 1024);
    // sleeves hint
    g.fillStyle = sp.top; g.fillRect(cx - 60, 566 + ty, 120, 220); g.fillRect(0, 668 + ty, 512, 200);
    g.strokeStyle = sp.top; g.lineWidth = 20; g.beginPath(); g.moveTo(cx - 48, 570 + ty); g.lineTo(cx - 62, 482 + ty); g.moveTo(cx + 48, 570 + ty); g.lineTo(cx + 62, 482 + ty); g.stroke();
    g.strokeStyle = INKC; g.lineWidth = 3; g.beginPath(); g.moveTo(cx - 38, 570 + ty); g.lineTo(cx - 50, 482 + ty); g.moveTo(cx + 38, 570 + ty); g.lineTo(cx + 50, 482 + ty); g.stroke();
    for (const sx of [-46, 46]) button(g, cx + sx, 578 + ty, 8, '#e7c34a');
    // bib pocket with stitching
    g.strokeStyle = INKC; g.lineWidth = 4; g.strokeRect(cx - 30, 598 + ty, 60, 46);
    g.setLineDash([6, 6]); g.lineWidth = 2; g.strokeRect(cx - 24, 604 + ty, 48, 34); g.setLineDash([]);
    if (sp.pen) { g.fillStyle = sp.pen; g.fillRect(cx + 10, 584 + ty, 9, 22); }
    if (sp.bandana) { g.fillStyle = sp.bandana; g.beginPath(); g.moveTo(cx - 54, 488 + ty); g.lineTo(cx + 54, 488 + ty); g.lineTo(cx, 548 + ty); g.closePath(); g.fill(); g.strokeStyle = INKC; g.lineWidth = 4; g.stroke(); g.fillStyle = '#fff'; for (const [dx, dy] of [[-22, 500], [16, 504], [-2, 524]]) { g.beginPath(); g.arc(cx + dx, dy + ty, 4, 0, 7); g.fill(); } }
  } else if (o === 'suit' || o === 'labcoat' || o === 'vest') {
    g.fillStyle = sp.top; g.fillRect(0, 0, 512, 1024);
    g.fillStyle = sp.bottom || sp.top; g.fillRect(0, pantsY + (o === 'labcoat' ? 50 : 0), 512, 200);
    if (o === 'vest') { g.fillStyle = sp.shirt || '#fff'; g.fillRect(0, 0, 512, 540 + ty); }
    // shirt V and collar
    g.fillStyle = sp.shirt || '#fff'; g.beginPath(); g.moveTo(cx - 44, 486 + ty); g.lineTo(cx, 590 + ty); g.lineTo(cx + 44, 486 + ty); g.fill();
    g.fillStyle = '#ffffff'; for (const side of [-1, 1]) { g.beginPath(); g.moveTo(cx, 500 + ty); g.lineTo(cx + side * 40, 486 + ty); g.lineTo(cx + side * 30, 522 + ty); g.closePath(); g.fill(); g.strokeStyle = INKC; g.lineWidth = 3; g.stroke(); }
    if (sp.tie) { g.fillStyle = sp.tie; g.beginPath(); g.moveTo(cx - 10, 502 + ty); g.lineTo(cx + 10, 502 + ty); g.lineTo(cx + 15, 574 + ty); g.lineTo(cx, 592 + ty); g.lineTo(cx - 15, 574 + ty); g.closePath(); g.fill(); g.strokeStyle = INKC; g.lineWidth = 3; g.stroke(); g.beginPath(); g.moveTo(cx - 9, 512 + ty); g.lineTo(cx + 9, 512 + ty); g.stroke(); }
    // lapels
    g.strokeStyle = INKC; g.lineWidth = 5; g.beginPath(); g.moveTo(cx - 54, 486 + ty); g.lineTo(cx - 2, 626 + ty); g.moveTo(cx + 54, 486 + ty); g.lineTo(cx + 2, 626 + ty); g.stroke();
    for (let i = 0; i < 2; i++) button(g, cx + 12, 632 + i * 28 + ty, 7, o === 'labcoat' ? '#dfe3ea' : '#e7c34a');
    if (sp.watchChain) { g.strokeStyle = '#f0c840'; g.lineWidth = 5; g.beginPath(); g.moveTo(cx + 14, 642 + ty); g.quadraticCurveTo(cx + 44, 674 + ty, cx + 74, 640 + ty); g.stroke(); button(g, cx + 76, 640 + ty, 7, '#f0c840'); }
    // breast pocket + hanky
    g.strokeStyle = INKC; g.lineWidth = 4; g.strokeRect(cx - 80, 598 + ty, 36, 9);
    if (sp.hanky) { g.fillStyle = sp.hanky; g.beginPath(); g.moveTo(cx - 78, 598 + ty); g.lineTo(cx - 70, 584 + ty); g.lineTo(cx - 62, 596 + ty); g.lineTo(cx - 54, 586 + ty); g.lineTo(cx - 46, 598 + ty); g.fill(); }
    if (o === 'labcoat') { g.fillStyle = '#2b4c9b'; g.fillRect(cx - 74, 590 + ty, 6, 22); g.fillStyle = '#d8433a'; g.fillRect(cx - 62, 588 + ty, 6, 24); }
  } else if (o === 'polo' || o === 'hoodie') {
    g.fillStyle = sp.top; g.fillRect(0, 0, 512, 1024); g.fillStyle = sp.bottom || '#2a2f3a'; g.fillRect(0, pantsY, 512, 200);
    if (o === 'polo') {
      g.fillStyle = sp.top; for (const side of [-1, 1]) { g.beginPath(); g.moveTo(cx, 504 + ty); g.lineTo(cx + side * 46, 484 + ty); g.lineTo(cx + side * 36, 528 + ty); g.closePath(); g.fill(); g.strokeStyle = INKC; g.lineWidth = 3; g.stroke(); }
      g.strokeStyle = INKC; g.lineWidth = 3; g.strokeRect(cx - 9, 504 + ty, 18, 70); for (let i = 0; i < 3; i++) button(g, cx, 518 + i * 20 + ty, 4, '#e8e8ee');
    } else {
      g.strokeStyle = 'rgba(0,0,0,0.45)'; g.lineWidth = 16; g.beginPath(); g.ellipse(cx, 492 + ty, 70, 22, 0, 0, Math.PI); g.stroke();
      g.strokeStyle = '#e8e8ee'; g.lineWidth = 4; for (const sx of [-18, 18]) { g.beginPath(); g.moveTo(cx + sx, 506 + ty); g.lineTo(cx + sx * 1.1, 566 + ty); g.stroke(); }
      g.strokeStyle = INKC; g.lineWidth = 3; g.beginPath(); g.moveTo(cx - 60, 690 + ty); g.lineTo(cx - 44, 636 + ty); g.lineTo(cx + 44, 636 + ty); g.lineTo(cx + 60, 690 + ty); g.stroke();
    }
    // mission patch logo: white X swoosh
    const lx = cx - 56, ly = 566 + ty; g.strokeStyle = '#ffffff'; g.lineCap = 'round'; g.lineWidth = 6;
    g.beginPath(); g.moveTo(lx - 14, ly - 12); g.lineTo(lx + 14, ly + 12); g.stroke(); g.beginPath(); g.moveTo(lx - 14, ly + 12); g.quadraticCurveTo(lx + 4, ly - 2, lx + 22, ly - 20); g.stroke();
    if (sp.badgeCol) { g.fillStyle = sp.badgeCol; g.fillRect(cx + 30, 560 + ty, 40, 54); g.strokeStyle = INKC; g.lineWidth = 3; g.strokeRect(cx + 30, 560 + ty, 40, 54); g.fillStyle = '#fff'; g.fillRect(cx + 36, 568 + ty, 28, 16); }
  } else if (o === 'tee') {
    // dark blazer over a black t-shirt (boss)
    g.fillStyle = sp.top; g.fillRect(0, 0, 512, 1024); g.fillStyle = sp.bottom || sp.top; g.fillRect(0, pantsY, 512, 200);
    g.fillStyle = sp.shirt || '#121214'; g.beginPath(); g.moveTo(cx - 52, 486 + ty); g.lineTo(cx - 10, 650 + ty); g.lineTo(cx + 10, 650 + ty); g.lineTo(cx + 52, 486 + ty); g.fill();
    g.strokeStyle = 'rgba(255,255,255,0.18)'; g.lineWidth = 4; g.beginPath(); g.arc(cx, 470 + ty, 46, 0.35, Math.PI - 0.35); g.stroke();
    g.strokeStyle = INKC; g.lineWidth = 5; g.beginPath(); g.moveTo(cx - 56, 486 + ty); g.lineTo(cx - 10, 650 + ty); g.moveTo(cx + 56, 486 + ty); g.lineTo(cx + 10, 650 + ty); g.stroke();
    g.strokeStyle = 'rgba(255,255,255,0.22)'; g.lineWidth = 3; g.beginPath(); g.moveTo(cx - 62, 490 + ty); g.lineTo(cx - 18, 640 + ty); g.moveTo(cx + 62, 490 + ty); g.lineTo(cx + 18, 640 + ty); g.stroke();
    button(g, cx + 16, 664 + ty, 7, '#2a2a2e');
    g.strokeStyle = INKC; g.lineWidth = 4; g.strokeRect(cx - 82, 600 + ty, 36, 9); g.strokeRect(cx + 40, 680 + ty, 50, 9); g.strokeRect(cx - 90, 680 + ty, 50, 9);
  } else if (o === 'tommy' || o === 'german') {
    // WWI service tunic: high collar, four patch pockets with flaps, brass buttons, leather/webbing belt + ammo pouches
    const brit = o === 'tommy';
    g.fillStyle = sp.top; g.fillRect(0, 0, 512, 1024);
    // fabric weave
    g.globalAlpha = 0.07; g.fillStyle = '#000'; for (let y = 0; y < 1024; y += 4) g.fillRect(0, y, 512, 1); for (let x = 0; x < 512; x += 5) g.fillRect(x, 0, 1, 1024); g.globalAlpha = 1;
    g.fillStyle = sp.bottom || sp.top; g.fillRect(0, pantsY + 20, 512, 200);
    // collar
    g.fillStyle = brit ? shade(sp.top, 0.88) : '#3a4a3a'; g.beginPath(); g.moveTo(cx - 52, 484 + ty); g.lineTo(cx + 52, 484 + ty); g.lineTo(cx + 40, 514 + ty); g.lineTo(cx, 526 + ty); g.lineTo(cx - 40, 514 + ty); g.closePath(); g.fill(); g.strokeStyle = INKC; g.lineWidth = 3; g.stroke();
    if (!brit) { g.fillStyle = '#c8c8b8'; g.fillRect(cx - 44, 494 + ty, 12, 14); g.fillRect(cx + 32, 494 + ty, 12, 14); }
    // placket + buttons
    g.strokeStyle = INKC; g.lineWidth = 3; g.beginPath(); g.moveTo(cx, 526 + ty); g.lineTo(cx, pantsY + 10); g.stroke();
    for (let i = 0; i < 4; i++) button(g, cx + 8, 548 + i * 34 + ty, 6, brit ? '#d8b04a' : '#b8b8a8');
    // breast pockets with flaps
    for (const side of [-1, 1]) {
      const px = cx + side * 52; g.fillStyle = shade(sp.top, 0.93); g.fillRect(px - 26, 556 + ty, 52, 46); g.strokeStyle = INKC; g.lineWidth = 3; g.strokeRect(px - 26, 556 + ty, 52, 46);
      g.fillStyle = shade(sp.top, 0.85); g.beginPath(); g.moveTo(px - 28, 552 + ty); g.lineTo(px + 28, 552 + ty); g.lineTo(px + 28, 568 + ty); g.lineTo(px, 576 + ty); g.lineTo(px - 28, 568 + ty); g.closePath(); g.fill(); g.stroke();
      button(g, px, 568 + ty, 4, brit ? '#d8b04a' : '#b8b8a8');
    }
    // cross strap (webbing) over the right shoulder
    g.strokeStyle = sp.webbing || (brit ? '#a89868' : '#3a2a1e'); g.lineWidth = 16; g.beginPath(); g.moveTo(cx + 70, 486 + ty); g.lineTo(cx - 60, pantsY - 4); g.stroke();
    g.strokeStyle = INKC; g.lineWidth = 2; g.beginPath(); g.moveTo(cx + 78, 486 + ty); g.lineTo(cx - 52, pantsY - 4); g.moveTo(cx + 62, 486 + ty); g.lineTo(cx - 68, pantsY - 4); g.stroke();
    // belt with ammo pouches
    g.fillStyle = sp.webbing || (brit ? '#a89868' : '#3a2a1e'); g.fillRect(0, pantsY - 8, 512, 22); g.strokeStyle = INKC; g.lineWidth = 3; g.strokeRect(-2, pantsY - 8, 516, 22);
    for (const px of [cx - 86, cx - 58, cx + 58, cx + 86]) { g.fillStyle = sp.webbing ? shade(sp.webbing, 0.9) : (brit ? '#988858' : '#2e2218'); g.fillRect(px - 12, pantsY - 18, 24, 32); g.strokeRect(px - 12, pantsY - 18, 24, 32); }
    g.fillStyle = brit ? '#d8b04a' : '#9a9a8a'; g.fillRect(cx - 12, pantsY - 10, 24, 26); g.strokeRect(cx - 12, pantsY - 10, 24, 26);
    if (sp.chevrons) { g.strokeStyle = '#e8d8a8'; g.lineWidth = 5; for (let i = 0; i < sp.chevrons; i++) { const yy = 618 + i * 12 + ty; g.beginPath(); g.moveTo(cx - 100, yy); g.lineTo(cx - 88, yy + 10); g.lineTo(cx - 76, yy); g.stroke(); } }
    if (sp.armband) { g.fillStyle = sp.armband; g.fillRect(cx + 78, 600 + ty, 26, 24); }
  } else if (o === 'captain') {
    // navy naval coat: red front panel with gold trim, gold buttons, gold belt line
    g.fillStyle = sp.top || '#2f55c8'; g.fillRect(0, 0, 512, 1024);
    g.fillStyle = '#d8352a'; g.fillRect(cx - 34, 470 + ty, 68, 300);
    g.fillStyle = '#f4c430'; g.fillRect(cx - 40, 470 + ty, 8, 300); g.fillRect(cx + 32, 470 + ty, 8, 300);
    g.strokeStyle = INKC; g.lineWidth = 3; for (const x of [cx - 40, cx - 32, cx + 32, cx + 40]) { g.beginPath(); g.moveTo(x, 470 + ty); g.lineTo(x, 770 + ty); g.stroke(); }
    for (let i = 0; i < 4; i++) button(g, cx, 520 + i * 42 + ty, 8, '#f4c430');
    g.fillStyle = '#f4c430'; g.fillRect(0, 690 + ty, 512, 12); g.strokeStyle = INKC; g.strokeRect(-2, 690 + ty, 516, 12);
    g.fillStyle = '#ffffff'; for (const side of [-1, 1]) { g.beginPath(); g.moveTo(cx, 498 + ty); g.lineTo(cx + side * 40, 484 + ty); g.lineTo(cx + side * 30, 520 + ty); g.closePath(); g.fill(); g.stroke(); }
  } else if (o === 'pilot') {
    // airline uniform: navy jacket, white shirt + black tie, gold wings, gold buttons, name badge
    g.fillStyle = sp.top || '#1d2846'; g.fillRect(0, 0, 512, 1024); g.fillStyle = sp.bottom || '#1a2238'; g.fillRect(0, pantsY, 512, 200);
    g.fillStyle = '#ffffff'; g.beginPath(); g.moveTo(cx - 46, 486 + ty); g.lineTo(cx, 600 + ty); g.lineTo(cx + 46, 486 + ty); g.fill();
    g.fillStyle = '#16161a'; g.beginPath(); g.moveTo(cx - 9, 500 + ty); g.lineTo(cx + 9, 500 + ty); g.lineTo(cx + 13, 580 + ty); g.lineTo(cx, 598 + ty); g.lineTo(cx - 13, 580 + ty); g.closePath(); g.fill();
    g.strokeStyle = INKC; g.lineWidth = 5; g.beginPath(); g.moveTo(cx - 56, 486 + ty); g.lineTo(cx - 4, 630 + ty); g.moveTo(cx + 56, 486 + ty); g.lineTo(cx + 4, 630 + ty); g.stroke();
    for (let i = 0; i < 3; i++) { button(g, cx - 22, 640 + i * 26 + ty, 7, '#f0c040'); button(g, cx + 22, 640 + i * 26 + ty, 7, '#f0c040'); }
    // gold wings over the left breast
    const wx = cx - 62, wy = 560 + ty; g.fillStyle = '#f2c23a'; g.strokeStyle = INKC; g.lineWidth = 3;
    g.beginPath(); g.moveTo(wx, wy); g.quadraticCurveTo(wx - 30, wy - 16, wx - 44, wy - 4); g.quadraticCurveTo(wx - 24, wy + 2, wx, wy + 8); g.quadraticCurveTo(wx + 24, wy + 2, wx + 44, wy - 4); g.quadraticCurveTo(wx + 30, wy - 16, wx, wy); g.fill(); g.stroke();
    g.fillStyle = '#d8352a'; g.beginPath(); g.arc(wx, wy + 2, 7, 0, 7); g.fill(); g.stroke();
    g.fillStyle = '#e8e8ee'; g.fillRect(cx + 34, 566 + ty, 46, 14); g.strokeRect(cx + 34, 566 + ty, 46, 14);
    if (sp.stripes) { g.fillStyle = '#f2c23a'; for (let i = 0; i < sp.stripes; i++) g.fillRect(0, 724 + ty - i * 14, 512, 7); }
  } else if (o === 'chef') {
    g.fillStyle = '#ffffff'; g.fillRect(0, 0, 512, 1024);
    // double-breasted buttons, apron line, small red neckerchief
    for (let i = 0; i < 3; i++) { button(g, cx - 26, 548 + i * 34 + ty, 6, '#e8e8ee'); button(g, cx + 26, 548 + i * 34 + ty, 6, '#e8e8ee'); }
    g.strokeStyle = INKC; g.lineWidth = 4; g.beginPath(); g.moveTo(0, 650 + ty); g.quadraticCurveTo(cx, 664 + ty, 512, 650 + ty); g.stroke();
    g.fillStyle = '#d8352a'; g.beginPath(); g.moveTo(cx - 40, 486 + ty); g.lineTo(cx + 40, 486 + ty); g.lineTo(cx, 530 + ty); g.closePath(); g.fill(); g.lineWidth = 3; g.stroke();
  } else if (o === 'raincoat') {
    g.fillStyle = sp.top; g.fillRect(0, 0, 512, 1024);
    g.strokeStyle = INKC; g.lineWidth = 4; g.beginPath(); g.moveTo(cx, 486 + ty); g.lineTo(cx, 734 + ty); g.stroke();
    for (let i = 0; i < 3; i++) button(g, cx - 12, 560 + i * 44 + ty, 7, '#2b2630');
    g.strokeRect(cx + 26, 640 + ty, 44, 30);
  } else { // shirt + pants with belt
    g.fillStyle = sp.top; g.fillRect(0, 0, 512, 1024); g.fillStyle = sp.bottom || '#4a5a7a'; g.fillRect(0, pantsY, 512, 200);
    g.fillStyle = '#ffffff'; for (const side of [-1, 1]) { g.beginPath(); g.moveTo(cx, 500 + ty); g.lineTo(cx + side * 42, 486 + ty); g.lineTo(cx + side * 32, 524 + ty); g.closePath(); g.fill(); g.strokeStyle = INKC; g.lineWidth = 3; g.stroke(); }
    for (let i = 0; i < 3; i++) button(g, cx, 540 + i * 36 + ty, 6, '#fff');
    g.strokeStyle = INKC; g.lineWidth = 3; g.beginPath(); g.moveTo(cx, 500 + ty); g.lineTo(cx, 660 + ty); g.stroke();
  }
  // belt with buckle (not on long coats)
  if (o !== 'tommy' && o !== 'german' && o !== 'raincoat' && o !== 'labcoat' && o !== 'captain' && o !== 'chef' && o !== 'tee' && o !== 'hoodie') {
    g.fillStyle = sp.belt || '#3a2a26'; g.fillRect(0, pantsY - 4, 512, 16);
    g.strokeStyle = '#f0c840'; g.lineWidth = 4; g.strokeRect(cx - 12, pantsY - 6, 24, 20);
  }
  if (sp.badge) { // star badge
    g.fillStyle = '#ffd23a'; g.beginPath(); for (let k = 0; k < 10; k++) { const a = -Math.PI / 2 + k * Math.PI / 5, rr = k % 2 ? 9 : 20; g.lineTo(cx - 58 + Math.cos(a) * rr, 580 + ty + Math.sin(a) * rr); } g.closePath(); g.fill(); g.strokeStyle = INKC; g.lineWidth = 3; g.stroke();
  }
  if (sp.patch) { g.fillStyle = '#fff'; g.fillRect(cx + 22, 560 + ty, 56, 26); g.strokeStyle = INKC; g.lineWidth = 3; g.strokeRect(cx + 22, 560 + ty, 56, 26); g.fillStyle = INKC; g.font = 'bold 20px sans-serif'; g.fillText(sp.patch, cx + 25, 580 + ty); }
  // shade (key light upper left) + rim
  
  if (p.rim) { g.strokeStyle = p.rim; g.lineWidth = 18; g.beginPath(); g.moveTo(cx + 60, 500 + ty); g.bezierCurveTo(cx + 94, 560 + ty, cx + 104, 640 + ty, cx + 90, 710 + ty); g.stroke(); }
}

export function drawStanding(g, sp, p) {
  g.clearRect(0, 0, 768, 1024);
  g.save(); g.translate(128, 0); // figure drawn in a 512-wide frame centred in a 768-wide canvas (room for props)
  const t = p.t || 0;
  const bob = p.bob ?? Math.sin(t * 3.1 + (sp.seed || 0)) * 6;
  const lean = p.lean || 0;
  g.save(); g.translate(256, 1000); g.rotate(lean); g.translate(-256, -1000);
  const cx = 256, hipY = 712 + bob * 0.4;
  // legs: thin tapered ink lines, long, dark oval feet
  const step = p.walk ? Math.sin(p.walk) * 40 : 0;
  const kneel = p.squat || 0;
  const jump = p.jump || 0;
  for (const side of [-1, 1]) {
    const fx = cx + side * 40 + side * step * 0.6 * side, fy = 990 - jump - (p.walk ? Math.max(0, Math.sin(p.walk * side)) * 20 : 0);
    limb(g, cx + side * 30, hipY - jump, fx, fy, 16, 9, side * kneel);
    g.fillStyle = INKC; g.beginPath(); g.ellipse(fx + side * 12, fy + 4, 34, 15, side * 0.08, 0, 7); g.fill();
    g.fillStyle = 'rgba(255,255,255,0.18)'; g.beginPath(); g.ellipse(fx + side * 6, fy - 3, 14, 4, 0, 0, 7); g.fill();
  }
  const ty = bob - jump;
  torsoPath(g, cx, ty); g.fillStyle = sp.top; g.fill();
  g.save(); torsoPath(g, cx, ty); g.clip();
  drawTorsoFill(g, sp, cx, ty, p);
  g.restore();
  torsoPath(g, cx, ty); ink(g, 17);
  // arms: thin tapered black lines, black disc hands holding props
  const shoulderY = 534 + ty;
  for (const side of [-1, 1]) {
    const arm = side < 0 ? (p.armL ?? 0.25) : (p.armR ?? 0.25);
    const len = 180;
    const sx = cx + side * 82, sy = shoulderY;
    const hx = sx + side * Math.sin(arm) * len, hy = sy + Math.cos(arm) * len;
    limb(g, sx, sy, hx, hy, 14, 8, side * 0.6);
    const prop = side < 0 ? p.propL : p.propR;
    if (prop) drawProp(g, prop, hx, hy, 1, side, t);
    g.fillStyle = INKC; g.beginPath(); g.arc(hx, hy, 21, 0, 7); g.fill();
  }
  if (p.propC) drawProp(g, p.propC, cx, 650 + ty, 1, 1, t);
  // head
  const hs = p.headScale || 1;
  const hy = 330 + bob - jump + (p.headY || 0) + (1 - hs) * 140;
  g.save(); g.translate(cx, hy); g.rotate(p.tilt || 0); g.translate(-cx, -hy);
  drawHead(g, cx, hy, hs, sp, p.expr || {}, p.rim);
  g.restore();
  g.restore();
  g.restore();
}

// --------------- crawling figure (canvas 1024 x 768) ---------------
export function drawCrawl(g, sp, p) {
  g.clearRect(0, 0, 1024, 768);
  const t = p.t || 0, ph = p.phase || 0;
  const base = 740;
  const tx = 600, ty = 430 + Math.sin(ph * 2) * 6;
  for (const side of [-1, 1]) {
    const k = Math.sin(ph + (side > 0 ? Math.PI : 0));
    const hipX = tx + 120, hipY = ty + 40;
    const kx = hipX - 20 + k * 30, ky = base - 12;
    limb(g, hipX, hipY, kx, ky, 17, 13, 0);
    limb(g, kx, ky, kx + 150, base - 18, 13, 9, 0);
    g.fillStyle = INKC; g.beginPath(); g.ellipse(kx + 166, base - 22, 30, 14, 0.3, 0, 7); g.fill();
  }
  g.save(); g.translate(tx, ty); g.rotate(-0.12);
  g.beginPath(); g.ellipse(-10, 0, 140, 84, 0, 0, 7); g.fillStyle = sp.top; g.fill();
  g.save(); g.clip(); g.fillStyle = sp.bottom || sp.top; g.fillRect(70, -120, 200, 240);
  g.fillStyle = '#ffffff'; g.beginPath(); g.moveTo(-150, -40); g.lineTo(-110, -10); g.lineTo(-150, 30); g.closePath(); g.fill(); g.fillStyle = sp.tie || '#a8323a'; g.beginPath(); g.moveTo(-148, -6); g.lineTo(-96, 4); g.lineTo(-148, 14); g.closePath(); g.fill();
  g.fillStyle = sp.belt || '#3a2a26'; g.fillRect(62, -120, 14, 240);
  g.strokeStyle = INKC; g.lineWidth = 5; g.beginPath(); g.moveTo(-60, -96); g.quadraticCurveTo(-20, 0, -70, 96); g.stroke(); // coat tail seam
  g.fillStyle = 'rgba(40,20,40,0.16)'; g.beginPath(); g.ellipse(30, 50, 170, 60, 0, 0, 7); g.fill();
  if (p.rim) { g.strokeStyle = p.rim; g.lineWidth = 16; g.beginPath(); g.ellipse(0, -6, 168, 88, 0, Math.PI * 1.15, Math.PI * 1.85); g.stroke(); }
  g.restore();
  g.beginPath(); g.ellipse(-10, 0, 140, 84, 0, 0, 7); ink(g, 16);
  g.restore();
  for (const side of [-1, 1]) {
    const k = Math.sin(ph + (side > 0 ? 0 : Math.PI));
    const sx = 470 + side * 30, sy = 440;
    const hx = 330 + side * 100 - k * 40, hy = base - 20 - Math.max(0, k) * 40;
    limb(g, sx, sy, hx, hy, 15, 9, side * 0.4);
    g.fillStyle = INKC; g.beginPath(); g.arc(hx, hy, 22, 0, 7); g.fill();
  }
  const hx = 330, hy = 410 + Math.sin(ph * 2 + 1) * 5;
  drawHead(g, hx, hy, 1.0, sp, p.expr || {}, p.rim);
}

// --------------- normal layer (v3): makes the flat drawing read as 3D under the scene light ---------------
let _sphN = null;
function sphereNormalCanvas() {
  if (_sphN) return _sphN;
  const N = 128, c = document.createElement('canvas'); c.width = c.height = N;
  const g = c.getContext('2d'), im = g.createImageData(N, N);
  for (let y = 0; y < N; y++) for (let x = 0; x < N; x++) {
    let nx = (x + 0.5) / N * 2 - 1, ny = -((y + 0.5) / N * 2 - 1);
    let l = Math.hypot(nx, ny); if (l > 0.999) { nx /= l / 0.999; ny /= l / 0.999; l = 0.999; }
    const nz = Math.sqrt(1 - l * l);
    const i = (y * N + x) * 4;
    im.data[i] = (nx * 0.5 + 0.5) * 255; im.data[i + 1] = (ny * 0.5 + 0.5) * 255; im.data[i + 2] = (nz * 0.5 + 0.5) * 255; im.data[i + 3] = 255;
  }
  g.putImageData(im, 0, 0); _sphN = c; return c;
}
function nBlob(n, x0, y0, w, h, clipPath) {
  n.save(); if (clipPath) { clipPath(); n.clip(); }
  n.drawImage(sphereNormalCanvas(), x0, y0, w, h); n.restore();
}
function drawStandingN(n, sp, p) {
  n.fillStyle = 'rgb(128,128,255)'; n.fillRect(0, 0, 768, 1024);
  n.save(); n.translate(128, 0);
  const t = p.t || 0; const bob = p.bob ?? Math.sin(t * 3.1 + (sp.seed || 0)) * 6; const lean = p.lean || 0; const jump = p.jump || 0;
  n.save(); n.translate(256, 1000); n.rotate(lean); n.translate(-256, -1000);
  const cx = 256, ty = bob - jump;
  nBlob(n, cx - 112, 480 + ty, 224, 262, () => torsoPath(n, cx, ty));
  const hs = p.headScale || 1; const hy = 330 + bob - jump + (p.headY || 0) + (1 - hs) * 140; const r = 150 * hs;
  n.save(); n.translate(cx, hy); n.rotate(p.tilt || 0); n.translate(-cx, -hy);
  if (sp.hat && sp.hat !== 'none' && sp.hat !== 'goggles') nBlob(n, cx - r * 1.35, hy - r * 1.45, r * 2.7, r * 1.15);
  nBlob(n, cx - r * 1.03, hy - r * 1.03, r * 2.06, r * 2.06, () => { n.beginPath(); n.arc(cx, hy, r * 1.03, 0, 7); });
  n.restore(); n.restore(); n.restore();
}
function drawCrawlN(n, sp, p) {
  n.fillStyle = 'rgb(128,128,255)'; n.fillRect(0, 0, 1024, 768);
  const ph = p.phase || 0; const tx = 600, ty = 430 + Math.sin(ph * 2) * 6;
  n.save(); n.translate(tx, ty); n.rotate(-0.12); nBlob(n, -182, -102, 364, 204); n.restore();
  const hx = 330, hy = 410 + Math.sin(ph * 2 + 1) * 5, r = 150;
  nBlob(n, hx - r * 1.35, hy - r * 1.45, r * 2.7, r * 1.15);
  nBlob(n, hx - r * 1.03, hy - r * 1.03, r * 2.06, r * 2.06, () => { n.beginPath(); n.arc(hx, hy, r * 1.03, 0, 7); });
}
// per-location character light rig (set from world.update)
export const CHAR_LIGHT = {
  keyDir: new THREE.Vector3(-0.5, 0.7, 0.5).normalize(),
  lit: new THREE.Color(1.0, 0.98, 0.94), shade: new THREE.Color(0.70, 0.72, 0.84),
  spec: new THREE.Color(1, 0.97, 0.9), rim: new THREE.Color(0.55, 0.62, 0.75), rimAmt: 0.35, specAmt: 0.45,
};

// --------------- 3D card ---------------
export class Character {
  constructor(spec, o = {}) {
    this.spec = spec; this.crawl = !!o.crawl;
    const W = this.crawl ? 1024 : 768, H = this.crawl ? 768 : 1024;
    this.canvas = document.createElement('canvas'); this.canvas.width = W; this.canvas.height = H;
    this.ctx = this.canvas.getContext('2d');
    this.tex = new THREE.CanvasTexture(this.canvas); this.tex.colorSpace = THREE.SRGBColorSpace; this.tex.anisotropy = 8;
    const scale = o.scale || 1; this.scale = scale;
    const uw = W / 512 * scale, uh = H / 512 * scale;
    const geo = new THREE.PlaneGeometry(uw, uh);
    geo.translate(0, uh / 2 - (this.crawl ? 0.04 : 0.05) * scale, 0);
    this.ncanvas = document.createElement('canvas'); this.ncanvas.width = W; this.ncanvas.height = H;
    this.nctx = this.ncanvas.getContext('2d');
    this.ntex = new THREE.CanvasTexture(this.ncanvas); this.ntex.colorSpace = THREE.NoColorSpace;
    this.mat = new THREE.MeshBasicMaterial({ map: this.tex, transparent: true, alphaTest: 0.04, side: THREE.DoubleSide, depthWrite: true, fog: true });
    const U = this.U = {
      uNrm: { value: this.ntex }, uCardM: { value: new THREE.Matrix3() }, uKeyDir: { value: new THREE.Vector3() }, uView: { value: new THREE.Vector3(0, 0, 1) },
      uLit: { value: new THREE.Color() }, uShade: { value: new THREE.Color() }, uSpec: { value: new THREE.Color() }, uRim: { value: new THREE.Color() }, uRimAmt: { value: 0.3 }, uSpecAmt: { value: 0.4 },
    };
    this.mat.onBeforeCompile = (sh) => {
      Object.assign(sh.uniforms, U);
      sh.fragmentShader = sh.fragmentShader.replace('#include <common>', `#include <common>
uniform sampler2D uNrm; uniform mat3 uCardM; uniform vec3 uKeyDir, uView, uLit, uShade, uSpec, uRim; uniform float uRimAmt, uSpecAmt;`)
      .replace('#include <map_fragment>', `#include <map_fragment>
      {
        vec3 nT = texture2D(uNrm, vMapUv).xyz * 2.0 - 1.0;
        vec3 nW = normalize(uCardM * nT);
        float ndl = dot(nW, uKeyDir);
        float lit = smoothstep(-0.25, 0.45, ndl);              // soft terminator
        vec3 light = mix(uShade, uLit, lit);
        float lum = dot(diffuseColor.rgb, vec3(0.299, 0.587, 0.114));
        float inkM = 1.0 - smoothstep(0.07, 0.18, lum);         // keep the black ink lines black
        vec3 H = normalize(uKeyDir + uView);
        float sp = pow(max(dot(nW, H), 0.0), 48.0) * lit;
        float rim = pow(1.0 - clamp(dot(nW, uView), 0.0, 1.0), 2.6) * (0.35 + 0.65 * (1.0 - lit));
        vec3 shaded = diffuseColor.rgb * light + uSpec * sp * uSpecAmt + uRim * rim * uRimAmt;
        diffuseColor.rgb = mix(min(shaded, vec3(1.0)), diffuseColor.rgb, inkM);
      }`);
    };
    this.mesh = new THREE.Mesh(geo, this.mat);
    this.mesh.renderOrder = 2;
    this.mesh.castShadow = true;
    this.mesh.customDepthMaterial = new THREE.MeshDepthMaterial({ depthPacking: THREE.RGBADepthPacking, map: this.tex, alphaTest: 0.5, side: THREE.DoubleSide });
    this.root = new THREE.Group();
    this.pivot = new THREE.Group(); this.root.add(this.pivot); this.pivot.add(this.mesh);
    // soft contact blob under the feet (real shadow comes from the key light)
    const sh = new THREE.Mesh(new THREE.CircleGeometry(0.36 * scale * (this.crawl ? 1.8 : 1), 24), new THREE.MeshBasicMaterial({ color: 0x0c0a10, transparent: true, opacity: 0.38, depthWrite: false }));
    sh.rotation.x = -Math.PI / 2; sh.position.y = 0.012; sh.scale.set(1, 0.5, 1); sh.renderOrder = 1;
    this.root.add(sh); this.shadow = sh;
    this.poseFn = o.pose || (() => ({}));
    this.yawBias = o.yawBias || 0;
  }
  update(t, cam, tint, rim) {
    if (!this.root.visible) return;
    const p = this.poseFn(t) || {};
    p.t = t;
    if (rim && p.rim === undefined) p.rim = rim;
    if (this.crawl) { drawCrawl(this.ctx, this.spec, p); drawCrawlN(this.nctx, this.spec, p); }
    else { drawStanding(this.ctx, this.spec, p); drawStandingN(this.nctx, this.spec, p); }
    this.tex.needsUpdate = true; this.ntex.needsUpdate = true;
    if (tint) this.mat.color.copy(tint);
    // face the camera (yaw only, in parent space)
    this.root.updateWorldMatrix(true, false);
    const inv = new THREE.Matrix4().copy(this.root.matrixWorld).invert();
    const lc = cam.position.clone().applyMatrix4(inv);
    this.pivot.rotation.y = Math.atan2(lc.x, lc.z) + this.yawBias;
    this.mesh.updateWorldMatrix(true, false);
    const U = this.U, L = CHAR_LIGHT;
    U.uCardM.value.setFromMatrix4(this.mesh.matrixWorld);
    const e = U.uCardM.value.elements; // normalise columns (cards are scaled)
    for (let c = 0; c < 3; c++) { const l = Math.hypot(e[c * 3], e[c * 3 + 1], e[c * 3 + 2]) || 1; e[c * 3] /= l; e[c * 3 + 1] /= l; e[c * 3 + 2] /= l; }
    U.uKeyDir.value.copy(L.keyDir);
    const wp = new THREE.Vector3().setFromMatrixPosition(this.mesh.matrixWorld);
    U.uView.value.copy(cam.position).sub(wp).normalize();
    U.uLit.value.copy(L.lit); U.uShade.value.copy(L.shade); U.uSpec.value.copy(L.spec); U.uRim.value.copy(L.rim);
    U.uRimAmt.value = L.rimAmt; U.uSpecAmt.value = L.specAmt;
  }
}
