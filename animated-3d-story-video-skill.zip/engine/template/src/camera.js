// SHOT LIST + camera engine (WW1-Short editing style: many camera setups, every shot moves, hard cuts on jolts,
// short dissolves for time/place jumps). Edit only the block marked "THE SHOT LIST" for a new story.
//
// add(t, kind, set, p0, p1, l0, l1, opts)
//   t     : start time in seconds. Key it on a voice word: w('word', n, approxTime) = start of that word nearest approxTime.
//   kind  : 'cut'  clean straight cut (most shots)
//           'hard' jolt / punchline cut (gunshot, "Wrong.", a crash) - pair it with an SFX hit and a camera shake
//           'diss' short dissolve (opts.df frames, 8-10) for a jump in time or place
//   set   : which location in world.js the shot looks at (world.update switches lights/fog per set)
//   p0->p1: camera position at shot start -> end (ALWAYS different: every shot moves: push-in, pull-back, orbit, track, crane)
//   l0->l1: look-at point start -> end
//   opts  : fov / fov1 (lens, 38-62; small = tele close-up), aper (depth-of-field 0..2), roll (dutch, 0.02-0.06 rad),
//           focusD (fixed focus distance), shake (0.02-0.09 on impacts), shakeDecay (s), handheld (0.01 constant jitter),
//           scope (1 = scope/binocular vignette view), name (free label used by world.js for per-shot tweaks)
import * as THREE from 'three';
import { WORDS, DURATION_S } from './timing';
import { clamp, lerp } from './kit';

// word start nearest to the approximate time fb (n kept for readability only)
export const w = (word, n = 0, fb = 0) => { let best = null; for (const x of WORDS) if (x.t === word && (best === null || Math.abs(x.s - fb) < Math.abs(best - fb))) best = x.s; if (best === null) console.log('WORD MISSING', word); return best ?? fb; };
const V = (x, y, z) => new THREE.Vector3(x, y, z);

let _shots = null;
export function shots() {
  if (_shots) return _shots;
  const S = [];
  const add = (t, kind, set, p0, p1, l0, l1, o = {}) => S.push({ t, kind, set, p0: V(...p0), p1: V(...p1), l0: V(...l0), l1: V(...l1), fov: o.fov || 50, fov1: o.fov1 || o.fov || 50, aper: o.aper ?? 1.0, roll: o.roll || 0, df: o.df || 8, name: o.name || '', ...o });

  // ===================== THE SHOT LIST (demo story; replace per video) =====================
  // Demo voice: "A schemer sells fake gold on Main Street. Everyone buys it. But one quiet kid brings a magnet. Gone."
  // 1 hook: the strongest image first (schemer with the gold bars, low angle, slow push-in)
  add(0, 'cut', 'street', [0.9, 0.95, 3.4], [0.75, 0.98, 2.9], [-0.2, 1.15, 0], [-0.2, 1.18, 0], { fov: 50, aper: 1.0, roll: 0.03, name: 'hook' });
  // 2 "Everyone buys it." wide over the crowd, track right
  add(w('everyone', 0, 1.9), 'cut', 'street', [-3.2, 1.7, 5.2], [-2.4, 1.65, 5.0], [0.2, 0.9, 0], [0.5, 0.9, 0], { fov: 54, aper: 0.6, name: 'wide' });
  // 3 HARD "But" - the quiet kid steps in (jolt cut + small shake)
  add(w('but', 0, 3.2), 'hard', 'street', [2.4, 1.05, 2.4], [2.15, 1.02, 2.0], [1.4, 0.9, 0.2], [1.4, 0.92, 0.2], { fov: 46, aper: 1.4, shake: 0.03, shakeDecay: 0.3, name: 'kid' });
  // 4 DISS "Gone." - orbit on the schemer's shocked face
  add(w('gone', 0, 5.2), 'diss', 'street', [-0.9, 1.25, 1.9], [-0.3, 1.28, 2.1], [-0.2, 1.2, 0], [-0.2, 1.2, 0], { fov: 44, aper: 1.6, df: 8, name: 'shock' });
  // ==========================================================================================

  for (let i = 0; i < S.length; i++) S[i].t1 = i + 1 < S.length ? S[i + 1].t : DURATION_S;
  _shots = S;
  return S;
}

export function shotIndexAt(t) { const S = shots(); let i = 0; while (i + 1 < S.length && t >= S[i + 1].t) i++; return i; }
// dissolve state at t: { a, b, k } with k = 0..1 mix of b over a, or null
export function dissolveAt(t) {
  const S = shots();
  for (let i = 1; i < S.length; i++) {
    const s = S[i]; if (s.kind !== 'diss') continue;
    const half = s.df / 30 / 2; if (t >= s.t - half && t < s.t + half) { const u = (t - (s.t - half)) / (2 * half); const k = u * u * (3 - 2 * u); return { a: i - 1, b: i, k }; }
  }
  return null;
}

const ease = (u) => { const c = clamp(u, -0.2, 1.2); const s = 0.5 - 0.5 * Math.cos(Math.PI * clamp(c, 0, 1)); return 0.35 * c + 0.65 * s; };
export function cameraFor(i, t, cam) {
  const s = shots()[i];
  const u = ease((t - s.t) / Math.max(0.3, s.t1 - s.t));
  const p = s.p0.clone().lerp(s.p1, u), l = s.l0.clone().lerp(s.l1, u);
  let shake = 0;
  if (s.shake) shake = Math.max(0, 1 - (t - s.t) / (s.shakeDecay || 0.4)) * s.shake;
  if (s.handheld) shake = Math.max(shake, s.handheld);
  if (s.scope) { l.x += Math.sin(t * 1.7) * 0.012; l.y += Math.sin(t * 2.3) * 0.008; } // breathing drift
  if (shake) { p.x += Math.sin(t * 61) * shake; p.y += Math.sin(t * 47 + 1) * shake; l.x += Math.sin(t * 53 + 2) * shake * 0.5; }
  // tiny handheld drift so no frame is ever static
  p.x += Math.sin(t * 0.9) * 0.008; p.y += Math.sin(t * 1.3 + 1) * 0.006;
  cam.fov = lerp(s.fov, s.fov1, clamp((t - s.t) / Math.max(0.3, s.t1 - s.t), 0, 1)); cam.updateProjectionMatrix();
  cam.position.copy(p); cam.up.set(0, 1, 0); cam.lookAt(l); if (s.roll) cam.rotateZ(s.roll); cam.updateMatrixWorld(true);
  return { focus: s.focusD || p.distanceTo(l) * (s.focusK || 1), look: l, aper: s.aper, shot: s };
}
