# Third-party notices

## Bundled code
- `engine/template/audio/dsp.py` - copied unchanged from the *claude-animated-shorts* repository, MIT License,
  Copyright (c) 2026 Mr omi. The full licence text:

  > Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated
  > documentation files (the "Software"), to deal in the Software without restriction, including without limitation the
  > rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit
  > persons to whom the Software is furnished to do so, subject to the following conditions: The above copyright notice and
  > this permission notice shall be included in all copies or substantial portions of the Software.
  > THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
  > WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
  > COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
  > OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

Everything else in this package (engine source, tools, sound generators, examples, docs) is original and MIT-licensed
(see LICENSE). The editing rhythm (many moving camera setups, hard cuts on jolts, short dissolves, word captions) follows
the publicly described "3D Video Studio" workflow; no code from it is included.

## Installed at setup time (not bundled)
- Remotion 4.0.542 (`remotion`, `@remotion/*`) - Remotion License: free for individuals and small companies (up to 3
  employees) and non-profits; larger companies need a company licence. See https://www.remotion.dev/license
- three.js 0.170.0 - MIT. @react-three/fiber - MIT. React - MIT.
- Chrome Headless Shell (downloaded by Remotion) - BSD-style Chromium licence.
- numpy, scipy, pillow (BSD/HPND), edge-tts (LGPL-3.0, used as a separate tool), faster-whisper (MIT) + Whisper model
  weights (MIT, downloaded from Hugging Face).

## Downloaded per video (not bundled)
- HDRIs, PBR textures and glTF models from Poly Haven - CC0 1.0 (public domain), https://polyhaven.com/license
- `waternormals.jpg` from the three.js repository - MIT.
- Poppins font via Google Fonts - SIL Open Font License 1.1.

## Voices
- Google AI Studio / Gemini TTS, ElevenLabs, Cartesia or Microsoft Edge voices are used under the user's own account and
  those services' terms. Check each service's terms for commercial use of generated audio.
