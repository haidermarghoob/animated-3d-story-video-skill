#!/usr/bin/env bash
# One-time setup for the animated-3d-story-video skill. Safe to run again (skips what is already there).
#   bash setup.sh                 full setup (~3-6 min, ~700 MB): Remotion + three.js, headless Chrome, Python venv, whisper model
#   bash setup.sh --no-whisper    skip the word-timing model (estimated timings only)
# Installs into this folder only: engine/template/node_modules, .runtime/venv. Needs Node 18+, Python 3.9+, ffmpeg.
# Never uses Blender: everything is three.js + Remotion + headless Chrome.
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"; RT="$ROOT/.runtime"; TPL="$ROOT/engine/template"
WHISPER=1; for a in "$@"; do [ "$a" = "--no-whisper" ] && WHISPER=0; done
say() { printf '\n== %s\n' "$*"; }
SUDO=""; command -v sudo >/dev/null 2>&1 && sudo -n true 2>/dev/null && SUDO="sudo -n"
apt_install() { command -v apt-get >/dev/null 2>&1 || return 1; [ -n "$SUDO" ] || [ "$(id -u)" = 0 ] || return 1
  $SUDO apt-get install -y -q "$@" >/dev/null 2>&1 || { $SUDO apt-get update -q >/dev/null 2>&1; $SUDO apt-get install -y -q "$@" >/dev/null 2>&1; }; }

say "0/4 checking ffmpeg, node, python"
command -v ffmpeg >/dev/null || apt_install ffmpeg || { echo "ffmpeg missing: install it (apt install ffmpeg / brew install ffmpeg / winget install Gyan.FFmpeg)"; exit 1; }
command -v node >/dev/null || apt_install nodejs npm || { echo "Node.js 18+ missing: https://nodejs.org"; exit 1; }
NODE_MAJOR=$(node -p 'process.versions.node.split(".")[0]'); [ "$NODE_MAJOR" -ge 18 ] || { echo "Node $NODE_MAJOR is too old (need 18+)"; exit 1; }
PY=""; for c in python3 python; do command -v $c >/dev/null 2>&1 && $c -c 'import sys; sys.exit(0 if sys.version_info >= (3, 9) else 1)' 2>/dev/null && { PY=$c; break; }; done
[ -n "$PY" ] || { echo "Python 3.9+ missing"; exit 1; }
$PY -c 'import venv, ensurepip' 2>/dev/null || apt_install python3-venv python3-full || true
echo "ffmpeg $(ffmpeg -version | head -1 | cut -d' ' -f3) | node $(node -v) | $($PY --version)"

say "1/4 Remotion + three.js (npm ci, pinned versions)"
cd "$TPL"
if [ ! -d node_modules/remotion ]; then npm ci --no-audit --no-fund --loglevel=error || npm install --no-audit --no-fund --loglevel=error; fi

say "2/4 headless Chrome for rendering"
npx remotion browser ensure >/dev/null 2>&1 || npx remotion browser ensure
SHELL_BIN=$(find node_modules/.remotion -type f -name 'chrome-headless-shell' 2>/dev/null | head -1 || true)
if [ -n "$SHELL_BIN" ] && ldd "$SHELL_BIN" 2>/dev/null | grep -q "not found"; then
  echo "Chrome needs system libraries - installing them"
  apt_install libnss3 libatk1.0-0 libatk-bridge2.0-0 libcups2 libxcomposite1 libxdamage1 libxrandr2 libgbm1 libxkbcommon0 libpango-1.0-0 libcairo2 libasound2 libatspi2.0-0 libxfixes3 libdrm2 \
  || apt_install libnss3 libatk1.0-0t64 libatk-bridge2.0-0t64 libcups2t64 libxcomposite1 libxdamage1 libxrandr2 libgbm1 libxkbcommon0 libpango-1.0-0 libcairo2 libasound2t64 libatspi2.0-0t64 libxfixes3 libdrm2 \
  || echo "WARNING: could not install Chrome libraries automatically; missing: $(ldd "$SHELL_BIN" | grep 'not found' | awk '{print $1}' | tr '\n' ' ')"
fi

say "3/4 Python venv (numpy, scipy, pillow, edge-tts$( [ $WHISPER = 1 ] && echo ', faster-whisper'))"
[ -x "$RT/venv/bin/python" ] || $PY -m venv "$RT/venv"
VPY="$RT/venv/bin/python"; "$VPY" -m pip install -q --upgrade pip
"$VPY" -m pip install -q numpy scipy pillow edge-tts
[ $WHISPER = 1 ] && "$VPY" -m pip install -q faster-whisper

say "4/4 word-timing model"
if [ $WHISPER = 1 ]; then "$VPY" -c "from faster_whisper import WhisperModel; WhisperModel('base.en', device='cpu', compute_type='int8'); print('whisper base.en ready')"; else echo "skipped (--no-whisper)"; fi

echo "$(date -u +%FT%TZ)" > "$RT/setup.done"
say "READY. New video project:  bash $ROOT/new_project.sh <folder>"
