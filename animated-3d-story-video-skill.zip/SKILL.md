---
name: animated-3d-story-video
description: Makes a ~60 s vertical (9:16, 1080x1920) 3D animated story Short in one fixed style, entirely in code (three.js + Remotion + headless Chrome, never Blender) - white round-head stick-limb cartoon characters with ink outlines and line-art faces inside realistic HDRI-lit PBR worlds, many moving camera setups with hard cuts on jolts and short dissolves, word-by-word captions, procedural SFX and music that stops dead at the twist, -14 LUFS. Works step by step and asks "Theek hai? Aage chalun?" after every stage. Use when the user says "3d video skill", "3D video banao", "3d video skill ka use karke", "is video ko study karo aur isi andaaz me nayi video banao", "mujhe 3 topic ideas do", "make a 3D Short / 3D story video / animated short like this", or asks to save/install this skill.
---

# animated-3d-story-video

Makes a 45-75 s vertical 3D cartoon story Short: a **chalaak aadmi** (schemer) games the system, a **seedha saada insaan**
(simple person) beats him with something new. Style reference: the Short "How Soldiers Beat Snipers in World War 1"
(`reference/ww1_contact_sheet.jpg`, full code in `examples/ww1_sniper/`). Everything is code - no Blender, no After Effects,
no stock footage. All heavy work runs on Hark's computer; the user only reads, answers and (optionally) records the voice.

## 0. Install / find the package (do this first, silently)

The skill comes as a folder (zip) with this SKILL.md plus `engine/`, `examples/`, `reference/`, `setup.sh`, `new_project.sh`.
- **When the user uploads the zip and says "Is skill ko save kar lo" / "save this skill":** unzip it to
  `/workspace/skills/animated-3d-story-video/` (that folder is `PKG`), save THIS file's content as the user's custom skill
  named `animated-3d-story-video`, then start `bash $PKG/setup.sh` detached (it takes 3-6 min; see Ops) and reply short:
  saved, and the three ways to start (link, own topic, "mujhe 3 topic ideas do").
- **Every later run:** `PKG=/workspace/skills/animated-3d-story-video`. If it is missing, look for it:
  `find / -path '*animated-3d-story-video/engine/template/package.json' -not -path '*/node_modules/*' 2>/dev/null | head -1`
  (PKG = three levels up). If it is nowhere, ask the user to upload the skill zip again (from the video description / GitHub).
- `[ -f $PKG/.runtime/setup.done ] || bash $PKG/setup.sh` (installs Remotion 4.0.542 + three 0.170 + headless Chrome +
  Python venv with numpy/scipy/pillow/edge-tts/faster-whisper; needs Node 18+, Python 3.9+, ffmpeg; tries apt for missing libs).
- New project per video (never reuse one): `bash $PKG/new_project.sh /workspace/videos/<slug>` -> `P`. All commands below run
  in `P`. Python = `.venv/bin/python` (linked to the shared venv), node_modules is linked too.

## 1. How to talk

- Reply in the user's language and script: Roman Urdu -> Roman Urdu, Hinglish -> Hinglish, English -> English. Short,
  friendly, plain words; explain a term once ("storyboard, matlab har seen ka naksha").
- The video's narration is English by default (the style's audience); use Urdu/Hindi narration only if the user asks.
- **One stage at a time. After every stage show the result and ask exactly: "Theek hai? Aage chalun?"**
  (English user: "Okay? Shall I go on?"). Yes -> next stage. Changes -> apply, show again, ask again.
  Only if the user says to skip approvals ("seedha bana do", "mujhse mat poocho") run straight through to the end.
- Show images and videos with display_file (never paths). Keep text replies short; put long tables in a few lines each.
- Approved things stay fixed (script wording, facts, character looks) unless the user changes them.
- Never say you can listen. You can measure audio (pace, loudness, pauses) and read it with whisper; say that when relevant.

## 2. Three ways to start

**A. Reference link ("Is video ko study karo aur isi andaaz me kisi doosri cheez pe nayi video banao")**
1. `.venv/bin/python tools/study_ref.py "<link or uploaded file>" ref/` -> `ref/report.md`, `ref/contact.jpg`, `ref/hook.jpg`,
   transcript + words/s, cuts per minute, average shot length, loudness. If the download is blocked, ask the user to
   download the Short on the phone and upload the file in chat, then run it on the file.
2. Look at the contact sheet and hook frames yourself and fill the "andaaz" part of the report: hook, story shape,
   characters, world, light, camera, captions, sound.
3. Tell the user in 4-6 lines what you will copy (the andaaz: pace, cuts, camera, captions, sound, story shape) and that
   the story will be new ("dukaan ka design same, saaman tumhara"). Then offer 3 new topics in the same andaaz (mode C)
   unless they already gave one. Never copy the reference's script, characters' names or jokes.
4. Keep the reference numbers as targets (cuts/min, words/s, length) for the stages below, and show reference frames
   next to ours at the look stage.

**B. Own topic ("Restaurants ne pager kyun use karne shuru kiye, is pe video banao")** -> Stage 1 with that topic.

**C. "Mujhe 3 topic ideas do"** -> 3 ideas, each 3 lines: title (curiosity: "Why restaurants started giving you a pager",
"How soldiers beat snipers in WW1"), the schemer vs the simple person and the twist object/idea, the first-frame hook
image. Search the web to check every fact (drop single-source claims). End with: "Kaunsa chalega? Ya apna topic batao."

## 3. The stages (each ends with "Theek hai? Aage chalun?")

### Stage 1 - Idea chalega? (story check)
Test the topic in 4 questions and say the weakest one honestly:
1. Is there a **chalaak aadmi** (schemer, cheater, bully, sniper, scammer) with an unfair advantage?
2. Is there a **seedha saada insaan** who wins with something new or clever (an invention, a trick, a rule)?
3. Is there a **first-frame image** strong enough to stop the swipe (danger, money flying, a crash, a weird object)?
4. Can every beat be **shown** with simple 3D actions (walk, point, duck, grab, fall, explode, money rain)?
   Characters can't do fine finger work, read small text, swim, ride complex machines; stage those as props/cuts.
Facts: web-search the key claims; keep 2-4 hard numbers/names. Like Tom and Jerry: the fight between the two keeps people watching.

### Stage 2 - Kahani likhna (title + script)
- Title first: curiosity question about a behaviour, not the answer ("Why restaurants started handing out pagers").
- Script ~60 s: **190-290 words at ~4.2-4.4 words/s** (WW1 reference: 299 words / 71 s). 45-75 s total.
- Beats: **Hook (0-3 s)** first word at t=0, the problem/danger on screen in frame 0, "Imagine this..." / a sharp question ->
  **Setup** the schemer's advantage ("Easy task. Just run across, right? Wrong.") -> **Escalation** the simple person fails
  or suffers (2 attempts) -> **Turn** "But..." / "So, ..." the new idea -> **Reveal** step by step how it works ->
  **Payoff** the schemer loses, visually -> **Punchline** a dry joke ("but that's a lot of taxpayer money") that can loop
  back to the opening. No intro, no "subscribe", no outro.
- Short sentences, one idea each, spoken words (contractions), concrete numbers. Comic deadpan lines. Mark 1 twist moment
  (the biggest turn: music stops there).
- Show: title, the script one sentence per line with beat labels, word count, estimated length (words / 4.3).
  Tell the user to read it carefully ("ghar ki buniyad kamzor to ghar kamzor"): where it is boring or a joke isn't funny,
  change it now. Save as `script.json`: `[{"beat":"hook","emotion":"excited","text":"..."}, ...]` (one entry per sentence).

### Stage 3 - Characters ka huliya (visual bible)
Write `visual_bible.md` and show a short version: for every character: role, height (scale 0.8-1.1), hat, hair colour,
outfit + colours (hex), face default + the 3-4 expressions the story needs, props. For every place: what it is, surfaces
(which CC0 textures), light (cool sky + warm practicals), 4-8 dressing props, and **in-world text gags** (shop signs,
crate stencils, posters: e.g. "REAL GOLD* *probably") - small jokes people rewatch for. Same outfit in every scene.
Pick assets now: edit `assets.json` (Poly Haven ids, see section 6) and run `.venv/bin/python tools/fetch_assets.py`.

### Stage 4 - Pehli jhalak (look sheet in real 3D)
- Edit the cast in `src/CharSheet3D.jsx` (LIST = [spec, pose] per character) and build the busiest set in `src/world.js`
  with 2-3 shots in `src/camera.js` (estimated timing is fine: `python3 tools/est_timing.py script.json words.json 4.3 &&
  python3 tools/write_timing.py words.json src/timing.js`).
- Render (detached): `setsid nohup bash tools/stillrun.sh look chars <f1> <f2> <f3> > /dev/null 2>&1 &`, poll
  `cat out/stills.done`. Frames: `python3 tools/frames.py 6`. Show `out/chars3d.png` + `out/sheet_look.jpg`
  (and `ref/contact.jpg` next to it if there is a reference). Ask "haan, yehi look chahiye?" + "Theek hai? Aage chalun?"
- Check: faces readable, outlines visible, no blown white heads, gold rim light, cool background, nothing crossing faces,
  text inside its sign.

### Stage 5 - Har seen ka naksha + awaaz ki script (storyboard + voice script)
1. **Storyboard** (`storyboard.md`, show it as a compact list): one line per shot: time/word, camera (where it looks from,
   lens, move), who does what, face expression, SFX. Aim for the reference rhythm: **a new camera setup every ~2 s
   (25-30 cuts per minute), every shot moving**. The user only reads and says haan.
2. **Voice script** (`voice_blocks.json`): the script split into 4-8 blocks with an emotion each:
   `[["excited", "Imagine this. ..."], ["suspense", "..."], ["sarcastic", "..."]]`. Show it to the user as
   "[excited] Imagine this. ..." lines.
3. **Voice options** - ask which they want:
   - **Google AI Studio (free, best quality, user does it):** "aistudio.google.com kholo -> Generate speech / Speech
     (text-to-speech) -> Single speaker -> voice choose karo (Puck ya Fenrir energetic hain) -> style box me likho: *Read
     like an energetic YouTube Shorts storyteller, fast pace, punchy* -> meri script paste karo (har block ka jazba
     brackets me hai) -> Run -> download -> file yahan chat me bhej do, jaise WhatsApp pe voice note." One file for the
     whole script is fine; several files (one per block) also fine.
   - **Their own recording / ElevenLabs / Cartesia file:** same - upload it.
   - **Built-in (Hark makes it):** if the user has a Gemini API key (free at aistudio.google.com/apikey), save it with
     request_secret / vault as GEMINI_API_KEY and run `GEMINI_API_KEY=... .venv/bin/python tools/tts_gemini.py
     voice_blocks.json audio/vo --voice Puck` (same voices as AI Studio). Without a key: `tools/tts_edge.py` (free
     Microsoft neural voice; tell them honestly it sounds less human). Never ask for a key in chat text.
   While waiting for the voice, continue with Stage 6 on estimated timing.

### Stage 6 - 5 second ka trailer
Build the first 5 s for real (hook shot(s), captions, the look), render `setsid nohup bash tools/preview.sh > /dev/null 2>&1 &`,
poll `out/preview.done` (5-10 min), show `out/preview_5s.mp4`. "Kapda silne se pehle naap": characters, colours, camera,
captions OK? Changes are cheap now.

### Stage 7 - Awaaz aur video ko milana (sync)
When the voice file arrives (`/workspace/files/uploads/...` or `audio/vo/`):
```bash
.venv/bin/python tools/voice_prep.py <file1> [file2 ...] --script script.json      # join, trim, shorten pauses > 0.2 s, speed up if < 3.9 words/s
.venv/bin/python tools/words.py public/voiceover.wav words.json --script script.json  # every word's time (whisper), snapped to the script
.venv/bin/python tools/write_timing.py words.json src/timing.js                     # captions, WORDS, DURATION_S
```
Report: length, words/s, any words whisper missed. A slow read is sped up (pitch-safe, max x1.25) because a slow video
gets swiped; never stretch the video to a slow voice. Camera keys, events and SFX are all keyed to words with
`w('word', n, approxTime)`, so they follow the new timing automatically - re-check shots whose word moved a lot.

### Stage 8 - Video banna, hissa hissa (acts)
1. Finish `world.js` (all sets, all characters, all events on their words) and the full `camera.js` shot list. Stills
   check every shot: `python3 tools/frames.py` -> `tools/stillrun.sh all <frames...>` (detached), fix, repeat.
2. Sound: write `audio/make_audio.py` (template in the project; worked example `examples/ww1_sniper/make_audio_ww1.py`):
   an SFX on every visible action, a whoosh into each dissolve, a hit on each hard cut, one low ambience for the place,
   and the score in mood sections that **stops dead at the twist: music off, ~1 s silence, then a bass hit** (that
   silence is the jolt). Then mix:
   `.venv/bin/python audio/make_audio.py && .venv/bin/python audio/mix.py --voice public/voiceover.wav --bed audio/sfx_bed.wav --music audio/music_raw.wav --dur <DURATION_S> --out audio/final_mix`
3. Render act by act (3-4 acts of 15-25 s, aligned to 150-frame chunks):
   `SCALE=1.5 setsid nohup bash tools/render.sh <fromFrame> <toFrame> > /dev/null 2>&1 &` -> poll `tail -2 out/chunks/render.log`
   -> `bash tools/act.sh <from> <to>` -> show `out/act_<from>_<to>.mp4` -> "Theek hai? Aage chalun?" -> next act.
   Chunks are resumable and reused by the final; a code change re-renders only what you re-run (render.sh rebundles and
   clears stale chunks when src/ changed - so finish code changes before moving on, or re-render the affected acts).
   Tell the user the time honestly (CPU: about 4-8 s per frame at 1080x1920 -> roughly 30-60 min per 10 s; use SCALE=1 +
   upscale for drafts).

### Stage 9 - Aakhri check + delivery
`bash tools/finish.sh "<Video Title>"` -> `out/<Title>.mp4` (1080x1920, 30 fps, AAC), `out/<Title> (voice + SFX only).mp4`,
`out/contact_sheet.jpg`, `out/qa.txt`. QA checks: size, fps, duration = audio, loudness -14 LUFS (+-1) and no clipping,
no black frames, no frozen picture > 0.6 s, cuts per minute, captions inside the frame, first caption at frame 0.
Also look at the contact sheet yourself (characters cut at the edge? text off a sign? camera inside a wall?).
Deliver: the mp4 with display_file, one line on what was checked and anything still imperfect, then offer one next
step (a title + description + tags for YouTube, a thumbnail frame, or the next video). Upload anywhere only if asked.

## 4. The look (house style) - keep exactly

**Format:** 9:16, compositions 720x1280 rendered with `--scale=1.5` -> 1080x1920, 30 fps. `finish.sh` upscales
(lanczos) if chunks were rendered at SCALE=1.

**Characters** (`src/chars3d.js`, true 3D meshes): big pure-white sphere head (crisp black line-art face decal: brows, eyes,
mouth, mustache, glasses, blush, sweat drops, panic lines), bean/pear torso with a detailed painted outfit, thin black
tapered stick limbs, black round hands, big black oval feet, bold ink outline (screen-space hull, #141113), hats as meshes,
gold Fresnel rim light, soft contact shadow. Never realistic humans, never tiny "cute" bodies. Lots of acting.
- `new Character(spec, { scale, pose: (t) => ({...}) })`, call `c.update(t, camera)` each frame (world.js does it).
- spec: `hat` (none, bowler, tophat, fedora, cap, hardhat, helmet, pilotcap, headset, chef, bicorne, rainhat, goggles,
  brodie, stahlhelm, officercap), `hatColor`, `hair`, `outfit` (suit, vest, tee, polo, hoodie, overalls, labcoat, chef,
  captain, pilot, raincoat, tommy, german), `top`, `bottom`, `shirt`, `tie`, `mustache`, `glasses`, `watchChain`, `badge`,
  `belt`, `bandana`, `armband`, `chevrons`, `puttees`, `stripes`, `patch`, `seed`.
- pose: `armL/armR` (0 down ... 3 straight up), `propL/propR/propC` (pointer, clipboard, cheque, bill, phone, laptop, mug,
  map, blueprint, flag, balloon, stopwatch, watch, wrench, brush, chalk, checklist, jerrycan, noodles, binoculars, bomb,
  fieldphone, dripstick), `crouch` 0..1, `lean`, `tilt`, `jump` (px), `walk` (phase), `yawAbs`, `hatOff`, `headScale`,
  `expr: E(eyes, brows, mouth, {sweat, sweatY, lines, blush, look, lookY})` with eyes dot/half/happy/wide/closed/squint,
  brows flat/angry/proud/raised/shock/smug/worried/none, mouth line/smile/smirk/grin/grit/frown/o/open/shout.
  Expressions change ON the words. 3-5 face close-ups per video. Prop text: `PROP_TEXT.cheque = ['$440,000,000', 'PAY TO: ...']`.
- Crawl variant `{ crawl: true }`. Check every design in `Chars3D` before the storyboard.

**Worlds** (`src/world.js`): realistic, HDRI-lit, PBR-textured (CC0 Poly Haven), several sets in one scene at different
offsets (WW1: street at the origin, trench at x=100). Photo sky dome from a `*_puresky` HDRI, `scene.environment` = PMREM of
the 1k HDR, FogExp2 per set, glTF props layered foreground / midground / background, signs and labels painted in the world
(the only floating text is the captions). Helpers: `pbr(id, {color, rough, metal, repeat})`, `placeModel(id, {h})`,
`box/plane` with world-scaled UVs, `canvasTex` for signs; `src/env.js` has Gerstner water, rain, spray, forest impostors,
terrain, `wetify()` for wet streets.
**Light:** cool blue/purple ambient + sky, warm key light from top right of the camera view (re-aimed per shot, shadow
frustum fitted to the look point), warm practicals (lamps, fires), gold rim on characters, long soft shadows, reflections on
metal/glass/wet ground. Grade (post.js): cool shadows, golden highlights, saturation ~1.0, vignette 0.42, bloom threshold
1.02 (white heads never bloom), NeutralToneMapping, depth of field per shot (`aper`), SSAO, light ink edges, film grain,
motion blur on fast pans, flash on muzzle/explosions (never on a key frame), scope vignette mode.

**Camera + editing** (`src/camera.js` - the 3d-video-studio rhythm): one camera **setup per shot, ~25-30 shots per minute**
(WW1: 36 setups in 71 s, 32 detected cuts). Every shot moves (push-in, pull-back, orbit, track, crane; p0 != p1) with a tiny
handheld drift so no frame is static. Shot kinds: `cut` (most), `hard` (jolt/punchline: gunshot, "Wrong.", crash -> pair
with an SFX hit + `shake: 0.03-0.09`), `diss` (8-10 frame dissolve for a time/place jump + whoosh). Mix over-the-shoulder,
low wide, face close-ups (fov 38-46), POV/scope (`scope: true`, fov ~3), high wide establishing, dutch roll 0.02-0.06.
Frame maths (vertical fov 50 at 9:16): frame height ~0.93 x distance. Keep heads inside the frame, nothing across faces,
camera never inside walls. First frame = the most striking image (the hook); the last shot can loop into the first.

**Captions** (Video.jsx): 1-2 spoken words (<= 13 chars), Poppins 800, 46 px @720 (69 px @1080), white, 5 px near-black
stroke + drop shadow, centred at 70 % height, pop-in 0.78 -> 1 over 0.12 s, first caption at frame 0.

**Sound:** voice is the master. SFX bed ~17.5 LU under the voice and ducked under speech; music ~19 LU under, ducked 4 dB
more; master -14 LUFS, true peak under -1 dBTP; video length = audio length. `audio/sfx.py` generators: ambience (wind,
rain, room_tone, city, crowd_murmur, fire_crackle, sea), whoosh/whoosh_soft/swish/riser, impact/thud/punch/bass_hit,
boom_far/explosion/rifle/ricochet/ping/dirt, glass_break/splash, pop/click/beep/ding/cash_register/coins/paper_flutter/
phone_ring/footsteps/boing/whistle_fall/engine_pass/typing. `audio/music.py` moods: sly, tense, day, night, action,
triumph, calm; `stops=[twist]` -> silence + bass hit; `loop=True` crossfades the end into the start.

## 5. Story timing in code

`src/timing.js` (generated) exports `WORDS`, `CAPTIONS`, `DURATION_S`, `WT(word, n)`. In camera.js/world.js use
`w('word', 0, approxSeconds)` = start of that word nearest the approx time (robust when a word repeats). Build a `T = {...}`
table of word times at the top of world.js and drive every event from it (`smooth(a, b, t)`, `ramp`, `lerp`); all animation
is a function of `t` (never wall-clock). make_audio.py uses the same words (`wt('word', approx)`) so picture and sound hit together.

## 6. CC0 assets

`assets.json` -> `tools/fetch_assets.py` -> `public/assets/` + `manifest.json` (missing ids are skipped; the render never
dies on an asset). Poly Haven (polyhaven.com, all CC0; id = last part of the asset URL; API needs a User-Agent).
HDRIs: wasteland_clouds_puresky, kloofendal_48d_partly_cloudy_puresky, overcast_soil_puresky (storm), roofless_ruins,
artist_workshop (interiors). Textures: cobblestone_02, red_brick_plaster_patch_02, broken_brick_wall, damaged_plaster,
weathered_planks, brown_planks_05, wood_floor_worn, asphalt_02, concrete_floor_02, brown_mud_02, rubble, rusty_metal_02,
green_metal_rust, hessian_230, painted_plaster_wall. Models: wooden_crate_01, barrel_03, wooden_barrels_01, street_lamp_01,
wooden_lantern_01, old_military_crate, ammo_box, cement_bag, wooden_ladder, barrel_stove, bolt_action_rifle_7_62,
hanging_industrial_lamp, wooden_bookshelf_worn, desk_lamp_arm_01, potted_plant_01, plastic_monobloc_chair_01,
outdoor_table_chair_set_01, portable_generator, concrete_road_barrier, metal_jerrycan. Search more:
`curl -s -A Mozilla/5.0 "https://api.polyhaven.com/assets?type=models" | python3 -c "import json,sys;print(list(json.load(sys.stdin))[:400])"`.
Trees are 4-17 M triangles: never load them in the video; bake impostor PNGs (see env.js `buildForest`) or use simple shapes.
Use only 1k files; keep big sources in `assets_src/` (public/ is copied into every bundle).

## 7. Ops (Hark sandbox)

- The shell tool times out at 120 s: run setup, stills, preview and renders **detached**
  (`setsid nohup <cmd> > /dev/null 2>&1 &`) and poll their log/done files; never wait in one command.
- Render speed on CPU (swangle), measured: a simple set ~4.5 s/frame at 1080x1920 (incl. chunk start-up); the busy WW1
  world ~3-4 s/frame at 720x1280 and roughly 1.5-2x that at 1080x1920. A 60 s Short (1800 frames) at 1080x1920 is
  ~2-4 hours; SCALE=1 (+ upscale in finish.sh) about half. Say this once at Stage 8; offer SCALE=1 if they're in a hurry.
- Before starting a render check nothing else renders: `ps aux | grep [r]emotion`. Never `pkill -f remotion` from the shell
  tool (it kills the tool's own command); kill by pid.
- If the sandbox restarts mid-render: delete the half-written chunk (no `.done`) and run render.sh again - finished chunks
  are skipped. Re-run `bash $PKG/setup.sh` if the venv or Chrome libs vanished.
- ffmpeg `+faststart` fails on some network filesystems: the scripts write in /tmp, then copy.
- GPU machine: `GL=angle` (much faster). Windows/Mac users can run the same project locally with Node + ffmpeg.
- Never use Blender or any 3D app; never download paid/unclear-licence assets, music or fonts (Poppins is OFL via Google Fonts).

## 8. Known pitfalls

- White heads turning grey: keep NeutralToneMapping, character shading cap 1.0, bloom threshold 1.02.
- Window glass as a flat blue rectangle: dark, low roughness, high envMapIntensity, little emissive.
- Foreground objects near the lens become blurry blobs across faces - move them out of the line of sight.
- Characters right next to a camera path become half-faces at the frame edge - move them or frame them fully.
- A flash/explosion on a key word frame reads as haze - offset it 2-3 frames.
- `smoothstep(a, b, x)` with a > b is undefined in GLSL - write `1.0 - smoothstep(b, a, x)`.
- Text on canvas signs: measure the widest line; keep it inside the sign.
- edge-tts fails behind proxies (unset HTTP(S)_PROXY) and with parallel requests (run sequentially).
- whisper misses a word -> words.py interpolates it from its neighbours; check captions around it.
- Camera keys keyed to a word that appears often (a, the, and): give the approx time so `w()` picks the right one.

## 9. Files

- `engine/template/` - the project template: `src/` (index.jsx, Video.jsx, CharSheet3D.jsx, world.js [demo], camera.js
  [demo shot list + engine], chars.js, chars3d.js, kit.js, env.js, post.js, assets.js, timing.js), `tools/` (fetch_assets,
  est_timing, words, write_timing, voice_prep, tts_gemini, tts_edge, study_ref, frames, stills.mjs, stillrun.sh,
  preview.sh, render.sh, act.sh, finish.sh, qa.py, sheet.py), `audio/` (dsp.py, sfx.py, music.py, mix.py, make_audio.py),
  `assets.json`, `script.json`, `voice_blocks.json`, package.json + lock (pinned).
- `examples/ww1_sniper/` - the reference Short's real world.js (2 sets, a dozen characters plus a trench crowd, sniper/helmet/mirror/biplanes/
  explosion/money-rain events), camera.js (36 shots), CharSheet3D.jsx, make_audio_ww1.py, script, voice blocks, word
  timings, assets.json. To study or rebuild it: copy those files into a new project (`src/`, root, `audio/make_audio.py`).
- `reference/` - `ww1_style_frames.jpg` + `ww1_contact_sheet.jpg` (the reference Short), `demo_cast_sheet.jpg` (the template cast, as a fresh setup renders it).
- `setup.sh`, `new_project.sh`, `smoke_test.sh` (proves the whole pipeline on a new machine, ~15 min, run detached).
