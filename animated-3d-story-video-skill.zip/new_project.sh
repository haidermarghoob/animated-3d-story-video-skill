#!/usr/bin/env bash
# Create a new video project from the engine template (one folder per video).
#   bash new_project.sh /path/to/videos/my-video
# The project shares node_modules and the Python venv with this package (no reinstall per video).
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"; DEST="${1:?usage: new_project.sh <folder>}"
[ -f "$ROOT/.runtime/setup.done" ] || bash "$ROOT/setup.sh"
[ -e "$DEST" ] && { echo "$DEST already exists - pick a new folder (one project per video)"; exit 1; }
mkdir -p "$DEST"
(cd "$ROOT/engine/template" && tar --exclude=node_modules --exclude=out --exclude=build --exclude=build_final --exclude='public/assets/*' -cf - .) | (cd "$DEST" && tar -xf -)
ln -s "$ROOT/engine/template/node_modules" "$DEST/node_modules"
ln -s "$ROOT/.runtime/venv" "$DEST/.venv"
mkdir -p "$DEST/out" "$DEST/public/assets" "$DEST/ref"
chmod +x "$DEST"/tools/*.sh
echo "project ready: $DEST"
echo "next: cd $DEST && .venv/bin/python tools/fetch_assets.py   (after editing assets.json)"
