import React, { useEffect, useLayoutEffect, useMemo, useState } from 'react';
import { AbsoluteFill, continueRender, delayRender } from 'remotion';
import { ThreeCanvas } from '@remotion/three';
import { useFrame, useThree } from '@react-three/fiber';
import * as THREE from 'three';
import { loadAssets, A } from './assets';
import { Character, CHAR_U, syncCharLight, CHAR_LIGHT } from './chars3d';
const E = (eyes, brows, mouth, x = {}) => ({ eyes, brows, mouth, ...x });
const LIST = [
  [{ hat: 'brodie', outfit: 'tommy', top: '#8a7a4e', bottom: '#7e7048', puttees: '#6e6444', seed: 1 }, { armL: 0.9, armR: 1.05, propL: 'bomb', expr: E('wide', 'worried', 'grit', { sweat: true }) }],
  [{ hat: 'brodie', outfit: 'tommy', top: '#7e7048', bottom: '#94845a', puttees: '#6e6444', mustache: '#3a2418', seed: 2 }, { armL: 2.3, armR: 2.3, propL: 'binoculars', expr: E('squint', 'angry', 'line') }],
  [{ hat: 'officercap', outfit: 'tommy', top: '#7a6a42', puttees: '#6e6444', mustache: '#d8d0c0', chevrons: 3, seed: 3 }, { armR: 2.7, expr: E('dot', 'raised', 'shout') }],
  [{ hat: 'stahlhelm', outfit: 'german', top: '#6e7466', bottom: '#5a5e54', puttees: '#4a4a40', webbing: '#2e2218', mustache: '#2a2420', seed: 4 }, { armL: 1.5, armR: 1.4, expr: E('squint', 'smug', 'smirk') }],
  [{ hat: 'brodie', outfit: 'tommy', top: '#857650', puttees: '#6e6444', armband: '#c8201e', seed: 5 }, { crouch: 0.6, armL: 2.7, armR: 1.3, propL: 'fieldphone', expr: E('happy', 'raised', 'shout') }],
  [{ hat: 'brodie', outfit: 'tommy', top: '#94845a', puttees: '#6e6444', seed: 6 }, { crouch: 0.86, armL: 2.6, armR: 2.2, propR: 'bill', expr: E('wide', 'shock', 'o') }],
];

function Sheet() {
  const { gl, scene, camera, size } = useThree();
  const chars = useMemo(() => {
    const out = [];
    LIST.forEach(([sp, p], i) => { const c = new Character(sp, { pose: () => ({ t: 0.3, bob: 0, ...p }) }); c.root.position.set((i - (LIST.length - 1) / 2) * 1.05, 0, 0); out.push(c); });
    return out;
  }, []);
  useLayoutEffect(() => {
    gl.toneMapping = THREE.NeutralToneMapping; gl.shadowMap.enabled = true; gl.shadowMap.type = THREE.PCFSoftShadowMap;
    const pm = new THREE.PMREMGenerator(gl); scene.environment = pm.fromEquirectangular(A.hdr.ruins).texture; scene.environmentIntensity = 0.7;
    scene.background = new THREE.Color('#2b2f55');
    const hemi = new THREE.HemisphereLight('#6f7fc8', '#2a2236', 0.6); scene.add(hemi);
    const sun = new THREE.DirectionalLight('#ffc27a', 2.6); sun.position.set(5, 7, 4); sun.castShadow = true; sun.shadow.mapSize.set(2048, 2048);
    Object.assign(sun.shadow.camera, { left: -6, right: 6, top: 6, bottom: -6 }); scene.add(sun);
    const ground = new THREE.Mesh(new THREE.PlaneGeometry(30, 30), new THREE.MeshStandardMaterial({ color: '#b8c4a8', roughness: 0.9 })); ground.rotation.x = -Math.PI / 2; ground.receiveShadow = true; scene.add(ground);
    chars.forEach(c => scene.add(c.root));
    camera.position.set(0, 1.05, 1.0 + LIST.length * 1.15); camera.lookAt(0, 0.82, 0); camera.fov = 40; camera.updateProjectionMatrix();
    const s = new THREE.Vector2(); gl.getDrawingBufferSize(s); CHAR_U.uRes.value.set(s.x * 1280 / s.y * 0.5625 / 0.5625, 1280); CHAR_U.uRes.value.copy(s);
  }, []);
  useFrame(() => { CHAR_LIGHT.rim.set('#ffc45a'); CHAR_LIGHT.rimAmt = 0.7; syncCharLight(); chars.forEach(c => c.update(0.3, camera)); gl.render(scene, camera); }, 1);
  return null;
}
export const CharSheet3D = () => {
  const [ready, setReady] = useState(false);
  const [h] = useState(() => delayRender('assets', { timeoutInMilliseconds: 170000 }));
  useEffect(() => { loadAssets().then(() => { setReady(true); continueRender(h); }); }, []);
  return <AbsoluteFill style={{ background: '#8fb6cc' }}>{ready ? <ThreeCanvas width={1440} height={1280} shadows camera={{ fov: 40 }} gl={{ antialias: true, preserveDrawingBuffer: true }}><Sheet /></ThreeCanvas> : null}</AbsoluteFill>;
};
