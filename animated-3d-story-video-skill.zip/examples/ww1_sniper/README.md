# Example: "How Soldiers Beat Snipers in World War 1" (71 s)

The finished Short this skill's style is taken from (`../../reference/ww1_style_frames.jpg`, `ww1_contact_sheet.jpg`).

| file | what it is |
|---|---|
| `script.txt`, `script.json` | the narration (299 words, 71 s, ~4.2 words/s) |
| `voice_blocks.json` | the same text in 8 blocks with an emotion each (what goes into the TTS / AI Studio) |
| `words.json` | word timings of the real voice-over (whisper) |
| `world.js` | two sets in one scene: a ruined street with the sniper's nest (origin) and a crowded trench (x = 100); ~a dozen characters + a trench crowd; sniper shots, impacts, helmet pings, mirror glint, scope view, biplanes, explosion + collapse, money rain |
| `camera.js` | 36 camera setups keyed to words (cut / hard / diss), shakes on the shots and the explosion, scope breathing |
| `CharSheet3D.jsx` | the WW1 cast lineup (Brodie helmets, Stahlhelm, officer cap, puttees, webbing) |
| `make_audio_ww1.py` | the sound design: rifle cracks, ricochets, pings, dirt, biplanes, bomb whistle, explosion, telephone, money, wind + distant artillery; music stops dead on "Wrong." |
| `assets.json` | the CC0 Poly Haven ids it uses (2 HDRIs, 11 texture sets, 12 models) |

Rebuild it (about 3-4 s/frame at 720x1280 on a CPU):
```bash
bash ../../new_project.sh /workspace/videos/ww1 && cd /workspace/videos/ww1
cp $PKG/examples/ww1_sniper/{world.js,camera.js,CharSheet3D.jsx} src/
cp $PKG/examples/ww1_sniper/{assets.json,words.json,script.json,voice_blocks.json} .
cp $PKG/examples/ww1_sniper/make_audio_ww1.py audio/make_audio.py
.venv/bin/python tools/fetch_assets.py
.venv/bin/python tools/write_timing.py words.json src/timing.js 71.0
# voice: make it from voice_blocks.json (AI Studio / tts_gemini.py / tts_edge.py) -> tools/voice_prep.py -> tools/words.py
```
The word timings belong to the original voice; with a new voice re-run `tools/words.py` and every event follows the words.
