# Sound design of the WW1 example ("How Soldiers Beat Snipers in World War 1", 71 s): every SFX keyed to a voice word.
# Copy to <project>/audio/make_audio.py when building this example (words.json in the project root).
#   .venv/bin/python audio/make_audio.py  -> audio/sfx_bed.wav, audio/music_raw.wav
import sys, os, json
import numpy as np
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE); ROOT = os.path.dirname(HERE)
from dsp import SR, ns, tt, rng, lp, hp, bp, fades, phase, pan, st, write_wav
from sfx import *
from music import score
W = json.load(open(os.path.join(ROOT, 'words.json')))['words']
DUR = 71.0
def wt(word, approx):
    best = None
    for x in W:
        ww = ''.join(ch for ch in x['t'].lower() if ch.isalnum() or ch == "'")
        if ww == word and (best is None or abs(x['s'] - approx) < abs(best - approx)): best = x['s']
    assert best is not None, word
    return best
r = rng(5)
N = ns(DUR + 1)
bed = np.zeros((2, N))
def put(x, t, g=1.0, p=0.0):
    x = np.asarray(x, float)
    if x.ndim == 1: x = pan(x, p)
    i = ns(t); a, b = max(0, i), min(N, i + x.shape[1])
    if b > a: bed[:, a:b] += g * x[:, a - i:b - i]
T = dict(and_=wt('and', 2.08), easy=wt('easy', 4.64), just=wt('just', 5.52), wrong=wt('wrong', 6.72), a1=wt('a', 7.36), what=wt('what', 10.48), this1=wt('this', 11.44),
         first=wt('first', 15.68), we=wt('we', 17.84), secondly=wt('secondly', 19.92), a7=wt('a', 21.68), is3=wt('is', 24.64), lets=wt("let's", 26.0), snipers=wt('snipers', 27.52),
         so=wt('so', 28.64), soldiers1=wt('soldiers', 32.08), taking=wt('taking', 33.28), helmets=wt('helmets', 33.84), barely=wt('barely', 34.48), fool=wt('fool', 36.32), soldier3=wt('soldier', 38.4),
         some=wt('some', 39.28), dummy=wt('dummy', 41.6), then=wt('then', 42.96), but=wt('but', 46.8), mirror=wt('mirror', 47.92), catch=wt('catch', 50.16), finally_=wt('finally', 51.43),
         a12=wt('a', 54.87), and9=wt('and', 58.23), even1=wt('even', 62.15), half=wt('half', 63.43), that2=wt('that', 64.15), needs=wt('needs', 65.19), take2=wt('take', 65.51),
         alt=wt('alternatively', 66.39), air=wt('air', 67.86), position=wt('position', 68.47), but1=wt('but', 69.03))
popPing = T['is3'] + 0.14; ping2 = T['soldier3'] + 0.05; dummyPing = T['dummy'] + 0.95; decoyPing = T['half'] - 0.05; markFire = T['needs'] - 0.02; ko = T['take2'] + 0.06; boom = T['position'] - 0.02
cues = []
# sniper shots (same times as the picture)
for ts, kind in [(0.0, 'wall'), (1.5, 'wall'), (T['wrong'] + 0.1, 'ground'), (T['wrong'] + 0.42, 'wall'), (T['a1'] + 0.3, 'ground'), (T['a1'] + 0.85, 'wall'), (popPing - 0.05, 'ping'), (T['snipers'] + 0.08, 'loud'), (T['catch'] + 0.1, 'far'), (decoyPing - 0.05, 'ping')]:
    if kind == 'loud': put(rifle(0.0, 7), ts, 1.3); cues.append((ts, 'rifle loud')); continue
    put(rifle(0.25 if kind != 'far' else 0.6, int(ts * 10)), ts, 0.9 if kind != 'far' else 0.6, 0.25); cues.append((ts, 'rifle'))
    if kind == 'wall' or kind == 'ground': put(dirt(int(ts * 7)), ts + 0.05, 0.8, -0.1); put(ricochet(int(ts * 3)), ts + 0.06, 0.35 if kind == 'wall' else 0.0, 0.3); cues.append((ts + 0.05, 'impact'))
    if kind == 'ping': put(ping(int(ts * 5)), ts + 0.05, 0.9); put(ricochet(int(ts * 9)), ts + 0.08, 0.45, -0.3); cues.append((ts + 0.05, 'helmet ping'))
# trench pings (sniper unseen, far crack + ping)
for ts in [ping2, dummyPing]:
    put(rifle(0.7, int(ts * 11)), ts - 0.12, 0.55); put(ping(int(ts * 13), 1250), ts, 0.95); put(ricochet(int(ts * 17)), ts + 0.03, 0.4, 0.4); cues.append((ts, 'helmet ping (trench)'))
# scope: sniper fires (recoil) right before the cut -> the same shot as ping2
put(rifle(0.1, 99), ping2 - 0.1, 0.8)
# marksman shot + KO
put(rifle(0.0, 31), markFire, 1.15, -0.2); cues.append((markFire, 'marksman rifle'))
put(ping(55, 1150), ko, 0.8); put(thud(4), ko + 0.35, 0.8); put(boing(3), ko + 0.1, 0.25); cues.append((ko, 'sniper KO'))
put(thud(8), ko + 0.95, 0.5)  # rifle hits the street
# hero jumps back / scramble
put(whoosh_soft(seed=2), T['wrong'] + 0.2, 0.6)
# helmet off, dummy, mirror glint
put(pop(3), T['helmets'], 0.4); put(whoosh_soft(seed=5), T['barely'] + 0.1, 0.35)
put(ding(2093.0), T['catch'] + 0.14, 0.5); cues.append((T['catch'] + 0.14, 'mirror glint'))
# field telephone ring + crank
put(phone_ring(1), T['alt'] + 0.1, 0.45); cues.append((T['alt'], 'field telephone'))
# biplanes + bomb whistles + explosion
put(engine_pass(3.0, 3), T['air'] - 0.9, 0.9, -0.4); put(engine_pass(3.0, 4), T['air'] - 0.6, 0.7, 0.4); cues.append((T['air'] - 0.9, 'biplanes'))
put(whistle_fall(boom - T['air'] - 0.1), T['air'] + 0.12, 0.5)
put(explosion(5), boom, 1.6); cues.append((boom, 'explosion'))
# money rain: paper flutter + coins
put(cash_register(1), T['but1'] - 0.15, 0.55); put(paper_flutter(1.6, 2), T['but1'] + 0.2, 0.6); put(coins(1.2, 3), T['but1'] + 0.4, 0.6); put(coins(0.8, 4), T['but1'] + 1.1, 0.5)
cues.append((T['but1'], 'money rain'))
# dissolve whooshes
for ts in [T['this1'], T['first'], T['lets'], T['then']]: put(whoosh_soft(seed=int(ts)), ts - 0.2, 0.45)
# ambience bed: wind + distant artillery booms (continuous, never silent); trench gets a slightly closer, muddier bed
rb = rng(77)
wind = lp(rb.standard_normal(N), 380) * 0.35 + lp(rb.standard_normal(N), 120) * 0.25
wind *= 0.75 + 0.25 * np.sin(np.arange(N) / SR * 0.35)
bed += st(wind) * 0.55
tb = 1.2
while tb < DUR - 1:
    put(boom_far(int(tb * 10)), tb, 0.45 + 0.25 * rb.random(), (rb.random() - 0.5) * 1.2); tb += 2.4 + rb.random() * 3.2
# fires crackle in the street shots (light)
crack = bp(rb.standard_normal(N), 1500, 6000) * (rb.random(N) < 0.0009) * 1.5
bed += st(lp(crack, 7000)) * 0.25
bed = bed[:, :ns(DUR)]
bed = bed / (np.abs(bed).max() + 1e-9) * 0.9
write_wav(os.path.join(ROOT, 'audio', 'sfx_bed.wav'), bed)
print('sfx ok', bed.shape, np.abs(bed).max())
# music: sly 'day' setup, cooler 'night' colour for the baiting, back to 'day' for the attack; dead stop on "Wrong." (1 s silence + bass hit)
mus = score(DUR, [(0, T['lets'], 'sly'), (T['lets'], T['finally_'], 'night'), (T['finally_'], DUR, 'day')], stops=[T['wrong']], gap=1.0, bpm=108, seed=11)
mus = mus[:, :ns(DUR)]
mus = mus / (np.abs(mus).max() + 1e-9) * 0.9
write_wav(os.path.join(ROOT, 'audio', 'music_raw.wav'), mus)
json.dump(cues, open(os.path.join(ROOT, 'audio', 'cues_used.json'), 'w'), indent=0)
print('music ok', mus.shape)
