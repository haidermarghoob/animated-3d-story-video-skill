// Shot list for "How Soldiers Beat Snipers in World War 1": one camera setup per shot, keyed on the voice words.
// kind: 'cut' (clean straight cut), 'hard' (jolt / punchline cut), 'diss' (dissolve, `df` frames, centred on the cut).
// Every shot moves (push-in / pull-back / orbit / track). Sets: street (x ~ -16..16), trench (TX), sky over the street.
import * as THREE from 'three';
import { WORDS, DURATION_S } from './timing';
import { clamp, lerp } from './kit';

export const TX = 100; // trench set offset
// word start nearest to the approximate time fb (n kept for readability only)
export const w = (word, n = 0, fb = 0) => { let best = null; for (const x of WORDS) if (x.t === word && (best === null || Math.abs(x.s - fb) < Math.abs(best - fb))) best = x.s; if (best === null) console.log('WORD MISSING', word); return best ?? fb; };
const V = (x, y, z) => new THREE.Vector3(x, y, z);

let _shots = null;
export function shots() {
  if (_shots) return _shots;
  const S = [];
  const add = (t, kind, set, p0, p1, l0, l1, o = {}) => S.push({ t, kind, set, p0: V(...p0), p1: V(...p1), l0: V(...l0), l1: V(...l1), fov: o.fov || 50, fov1: o.fov1 || o.fov || 50, aper: o.aper ?? 1.0, roll: o.roll || 0, df: o.df || 8, name: o.name || '', ...o });
  // 1 hook: pinned soldier, sniper flash across the street (first frame = strongest image)
  add(0, 'cut', 'street', [-1.2, 1.0, 5.65], [-0.95, 1.02, 5.05], [2.6, 0.2, -4.1], [2.75, 0.25, -4.4], { fov: 56, aper: 0.8, focusD: 2.0, name: 'hook' });
  // 2 "and you are tasked to plant a bomb on the other side of the street": over the shoulder, onto the target
  add(w('and', 0, 2.08), 'cut', 'street', [-1.05, 2.0, 5.6], [-0.6, 1.95, 5.2], [0.4, 1.2, -3.0], [2.5, 0.75, -5.1], { fov: 50, aper: 0.6, name: 'ots-target' });
  // 3 "Easy task." close, smug
  add(w('easy', 0, 4.64), 'cut', 'street', [0.15, 1.2, 5.55], [-0.05, 1.15, 5.05], [-0.4, 1.02, 3.75], [-0.4, 1.0, 3.75], { fov: 44, aper: 1.6, name: 'smug' });
  // 4 "Just run across, right?" wide from the street at the wall end
  add(w('just', 0, 5.52), 'cut', 'street', [4.3, 1.3, 0.85], [3.75, 1.28, 1.2], [1.2, 1.0, 3.4], [1.3, 1.0, 3.4], { fov: 52, aper: 0.6, name: 'run' });
  // 5 HARD "Wrong." sniper fires
  add(w('wrong', 0, 6.72), 'hard', 'street', [2.4, 3.9, -2.9], [2.65, 3.95, -3.4], [3.5, 4.5, -6.3], [3.5, 4.5, -6.3], { fov: 40, aper: 1.4, name: 'wrong' });
  // 6 "A sniper is holding you down": low dolly along the wall, bullets kicking dirt
  add(w('a', 3, 7.36), 'cut', 'street', [-1.6, 1.3, 6.6], [-1.2, 1.25, 6.0], [0.3, 0.55, 3.3], [0.35, 0.55, 3.3], { fov: 52, aper: 0.8, name: 'pinned' });
  // 7 "running across would be a death wish": over the sniper's shoulder at the gap
  add(w('running', 0, 8.8), 'cut', 'street', [4.5, 5.6, -8.9], [4.3, 5.5, -8.45], [1.2, 1.0, 3.2], [1.0, 1.0, 3.3], { fov: 46, aper: 0.5, name: 'sniper-ots' });
  // 8 "What do we do now?" huddle shrug
  add(w('what', 0, 10.48), 'cut', 'street', [-0.8, 1.28, 6.9], [-0.8, 1.22, 6.3], [-0.8, 0.45, 3.8], [-0.8, 0.45, 3.8], { fov: 50, aper: 1.2, name: 'huddle' });
  // 9 DISS trench full of soldiers (both World Wars)
  add(w('this', 1, 11.44), 'diss', 'trench', [TX - 7.5, 2.75, 1.45], [TX - 4.6, 2.65, 1.35], [TX + 1.5, 0.75, -0.45], [TX + 3.5, 0.75, -0.45], { fov: 54, aper: 0.6, df: 9, name: 'trench' });
  // 10 "First problem, where is the sniper?" DISS street: hero's back, scanning the windows
  add(w('first', 0, 15.68), 'diss', 'street', [-0.8, 1.58, 5.05], [-0.55, 1.55, 4.75], [-4.0, 3.1, -6.0], [3.0, 3.4, -6.0], { fov: 52, aper: 0.5, df: 9, name: 'scan' });
  // 11 "We need to locate him": binoculars, from the street side
  add(w('we', 0, 17.84), 'cut', 'street', [-0.35, 1.75, 1.75], [-0.38, 1.7, 2.2], [-0.4, 1.12, 3.75], [-0.4, 1.12, 3.75], { fov: 44, aper: 1.5, name: 'binoc' });
  // 12 "Secondly, how do we take him out?" rifle over the wall, from behind
  add(w('secondly', 0, 19.92), 'cut', 'street', [-2.6, 1.6, 5.05], [-2.4, 1.56, 4.72], [3.0, 3.7, -6.0], [3.3, 3.9, -6.0], { fov: 48, aper: 0.6, name: 'aim' });
  // 13 "A long-range fight against a sniper ..." inside the nest, slow orbit
  add(w('a', 7, 21.68), 'cut', 'street', [2.45, 4.5, -8.75], [2.75, 4.48, -8.25], [3.45, 4.25, -6.7], [3.5, 4.25, -6.7], { fov: 50, aper: 1.2, name: 'nest' });
  // 14 HARD "is almost impossible to win": soldier pops up, helmet pinged off
  add(w('is', 3, 24.64), 'hard', 'street', [-2.0, 1.75, 0.9], [-2.0, 1.7, 1.3], [-2.0, 1.15, 3.75], [-2.0, 1.12, 3.75], { fov: 46, aper: 1.2, name: 'ping1' });
  // 15 DISS "Let's tackle the first problem first." trench sergeant
  add(w("let's", 0, 26.0), 'diss', 'trench', [TX + 3.6, 1.68, 1.0], [TX + 3.2, 1.64, 0.85], [TX + 0.9, 1.3, -0.25], [TX + 0.9, 1.3, -0.25], { fov: 52, aper: 1.0, df: 8, name: 'sarge' });
  // 16 HARD "Snipers are loud." big flash
  add(w('snipers', 0, 27.52), 'hard', 'street', [4.35, 4.35, -4.25], [4.1, 4.38, -4.7], [3.5, 4.45, -6.3], [3.5, 4.45, -6.3], { fov: 44, aper: 1.2, name: 'loud' });
  // 17 "So, ideally, we want to bait out a shot" bait soldier on the fire step
  add(w('so', 0, 28.64), 'cut', 'trench', [TX - 1.6, 1.62, 0.8], [TX - 1.2, 1.6, 0.45], [TX + 0.25, 1.5, -0.6], [TX + 0.25, 1.48, -0.6], { fov: 50, aper: 0.9, name: 'bait' });
  // 18 "taking off their helmets" close
  add(w('soldiers', 1, 32.08), 'cut', 'trench', [TX + 0.3, 1.75, 1.05], [TX + 0.28, 1.7, 0.85], [TX + 0.25, 1.5, -0.5], [TX + 0.25, 1.48, -0.5], { fov: 58, aper: 1.4, name: 'helm-off' });
  // 19 "barely poking them out of cover" low from no-man's land
  add(w('barely', 0, 34.48), 'cut', 'trench', [TX + 0.95, 2.35, -4.6], [TX + 0.75, 2.33, -4.1], [TX + 0.25, 2.5, -1.3], [TX + 0.25, 2.55, -1.3], { fov: 48, aper: 0.9, name: 'poke' });
  // 20 "fool the sniper" scope view (device)
  add(w('fool', 0, 36.32), 'cut', 'trench', [TX + 1.0, 3.5, -42], [TX + 1.0, 3.5, -42], [TX + 0.25, 2.32, -1.25], [TX + 0.27, 2.31, -1.25], { fov: 3.4, fov1: 3.0, aper: 0.0, scope: true, name: 'scope' });
  // 21 HARD "soldier." helmet ping
  add(w('soldier', 3, 38.4) + 0.02, 'hard', 'trench', [TX + 1.6, 1.95, 0.6], [TX + 1.45, 1.95, 0.45], [TX + 0.25, 2.35, -1.0], [TX + 0.25, 2.45, -1.0], { fov: 54, aper: 0.8, name: 'ping2' });
  // 22 "Some soldiers would go even further" dummy head
  add(w('some', 0, 39.28), 'cut', 'trench', [TX + 4.7, 1.6, 0.55], [TX + 4.45, 1.58, 0.5], [TX + 3.1, 1.2, 0.2], [TX + 3.1, 1.22, 0.2], { fov: 52, aper: 1.2, name: 'dummy' });
  // 23 "dummy hat just for this" dummy over the parapet
  add(w('dummy', 0, 41.6), 'cut', 'trench', [TX + 3.55, 2.35, -4.4], [TX + 3.4, 2.33, -3.9], [TX + 3.1, 2.55, -1.3], [TX + 3.1, 2.6, -1.3], { fov: 46, aper: 0.9, name: 'dummy-up' });
  // 24 DISS "Then after they roughly know where the sniper is" street corner, dummy again
  add(w('then', 0, 42.96), 'diss', 'street', [-0.6, 1.32, 5.5], [-0.15, 1.3, 5.05], [0.9, 0.85, 3.2], [0.9, 0.9, 3.2], { fov: 56, aper: 0.9, df: 9, name: 'corner' });
  // 25 "but this time use a small mirror on a stick" mirror round the corner
  add(w('but', 0, 46.8), 'cut', 'street', [2.3, 1.3, 1.9], [2.1, 1.27, 2.1], [1.25, 1.0, 2.95], [1.25, 1.0, 2.95], { fov: 44, aper: 1.6, name: 'mirror' });
  // 26 HARD "catch the muzzle flash" mirror macro
  add(w('catch', 0, 50.16), 'hard', 'street', [1.95, 1.2, 2.2], [1.85, 1.18, 2.35], [1.2, 1.05, 2.95], [1.2, 1.05, 2.95], { fov: 38, aper: 2.0, name: 'flash' });
  // 27 "Finally ... they time an attack." two soldiers plan, orbit
  add(w('finally', 0, 51.43), 'cut', 'street', [-1.4, 1.2, 5.6], [-0.4, 1.22, 5.9], [-0.6, 0.6, 3.8], [-0.6, 0.6, 3.8], { fov: 50, aper: 1.1, name: 'plan' });
  // 28 "A soldier with a longrange weapon gets ready" marksman push-in
  add(w('a', 12, 54.87), 'cut', 'street', [0.1, 1.3, 5.9], [0.25, 1.25, 5.35], [0.8, 0.6, 3.6], [0.8, 0.6, 3.6], { fov: 46, aper: 1.3, name: 'marksman' });
  // 29 "another soldier prepares to distract" distractor with a helmet on his rifle
  add(w('and', 9, 58.23), 'cut', 'street', [-3.9, 1.45, 6.1], [-3.6, 1.42, 5.6], [-3.0, 1.3, 3.8], [-3.0, 1.35, 3.8], { fov: 50, aper: 1.2, name: 'distract' });
  // 30 "Even if they can distract him" helmet pops up and gets pinged, wide from the street
  add(w('even', 1, 62.15), 'cut', 'street', [-2.2, 1.75, -0.2], [-2.3, 1.72, 0.25], [-3.0, 1.45, 3.4], [-3.0, 1.45, 3.4], { fov: 46, aper: 0.6, name: 'decoy' });
  // 31 HARD "that is all his colleague needs" marksman leans out and fires
  add(w('that', 2, 64.15), 'hard', 'street', [2.5, 1.3, 1.45], [2.35, 1.3, 1.65], [1.1, 1.15, 3.6], [1.1, 1.15, 3.6], { fov: 46, aper: 1.0, name: 'fire' });
  // 32 HARD "take down the enemy" sniper knocked out of the window
  add(w('take', 2, 65.51), 'hard', 'street', [3.0, 4.5, -4.35], [3.1, 4.5, -4.7], [3.5, 4.5, -6.4], [3.5, 4.48, -6.4], { fov: 44, aper: 1.0, name: 'ko' });
  // 33 "Alternatively, you can just call it an air strike" field telephone
  add(w('alternatively', 0, 66.39), 'cut', 'street', [-5.6, 1.4, 6.3], [-5.4, 1.38, 5.8], [-5.2, 0.75, 3.9], [-5.2, 0.78, 3.9], { fov: 50, aper: 1.2, name: 'phone' });
  // 34 "air strike" biplanes overhead
  add(w('air', 0, 67.86), 'cut', 'street', [0.2, 1.2, 1.6], [0.1, 1.2, 1.25], [1.2, 6.8, -4.0], [2.2, 6.6, -4.4], { fov: 62, aper: 0.3, name: 'planes' });
  // 35 HARD "on this position" explosion
  add(w('position', 0, 68.47) - 0.04, 'hard', 'street', [-3.2, 1.9, 7.2], [-3.0, 1.85, 6.8], [3.0, 3.6, -6.0], [3.0, 3.6, -6.0], { fov: 52, aper: 0.4, name: 'boom' });
  // 36 "but that's a lot of taxpayer money" money rain, pull back
  add(w('but', 1, 69.03), 'cut', 'street', [-1.0, 1.35, 5.55], [-1.0, 1.75, 6.75], [-1.0, 1.3, 3.6], [-1.0, 1.55, 3.6], { fov: 52, aper: 0.8, name: 'money' });
  for (let i = 0; i < S.length; i++) S[i].t1 = i + 1 < S.length ? S[i + 1].t : DURATION_S;
  _shots = S;
  return S;
}

export function shotIndexAt(t) { const S = shots(); let i = 0; while (i + 1 < S.length && t >= S[i + 1].t) i++; return i; }
// dissolve state at t: { a, b, k } with k = 0..1 mix of b over a, or null
export function dissolveAt(t) {
  const S = shots();
  for (let i = 1; i < S.length; i++) {
    const s = S[i]; if (s.kind !== 'diss') continue;
    const half = s.df / 30 / 2; if (t >= s.t - half && t < s.t + half) { const u = (t - (s.t - half)) / (2 * half); const k = u * u * (3 - 2 * u); return { a: i - 1, b: i, k }; }
  }
  return null;
}

const ease = (u) => { const c = clamp(u, -0.2, 1.2); const s = 0.5 - 0.5 * Math.cos(Math.PI * clamp(c, 0, 1)); return 0.35 * c + 0.65 * s; };
export function cameraFor(i, t, cam) {
  const s = shots()[i];
  const u = ease((t - s.t) / Math.max(0.3, s.t1 - s.t));
  const p = s.p0.clone().lerp(s.p1, u), l = s.l0.clone().lerp(s.l1, u);
  let shake = 0;
  // shake on the explosion, the loud shot, the biplanes
  if (s.name === 'boom') shake = Math.max(0, 1 - (t - s.t) / 0.5) * 0.09;
  if (s.name === 'loud') shake = Math.max(0, 1 - (t - (s.t + 0.06)) / 0.35) * (t > s.t + 0.06 ? 0.035 : 0);
  if (s.name === 'planes') shake = 0.012;
  if (s.name === 'scope') { // breathing drift + recoil kick on the shot
    const k = t > w('soldier', 3, 38.4) - 0.05 ? Math.max(0, 1 - (t - (w('soldier', 3, 38.4) - 0.05)) / 0.25) : 0;
    l.x += Math.sin(t * 1.7) * 0.012; l.y += Math.sin(t * 2.3) * 0.008 + k * 0.25;
  }
  if (shake) { p.x += Math.sin(t * 61) * shake; p.y += Math.sin(t * 47 + 1) * shake; l.x += Math.sin(t * 53 + 2) * shake * 0.5; }
  // tiny handheld drift so no frame is static
  p.x += Math.sin(t * 0.9) * 0.008; p.y += Math.sin(t * 1.3 + 1) * 0.006;
  cam.fov = lerp(s.fov, s.fov1, clamp((t - s.t) / Math.max(0.3, s.t1 - s.t), 0, 1)); cam.updateProjectionMatrix();
  cam.position.copy(p); cam.up.set(0, 1, 0); cam.lookAt(l); if (s.roll) cam.rotateZ(s.roll); cam.updateMatrixWorld(true);
  return { focus: s.focusD || p.distanceTo(l) * (s.focusK || 1), look: l, aper: s.aper, shot: s };
}
