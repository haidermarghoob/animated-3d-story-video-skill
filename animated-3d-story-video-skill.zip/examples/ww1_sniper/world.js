// "How Soldiers Beat Snipers in World War 1": two sets in one world.
//  STREET (around the origin): our sandbag wall along z = 3 (x -9.8 .. 1.0, the wall end is "the corner"), the open street,
//  the ruined row opposite (facades at z = -6) with the sniper's nest on the first floor of building B (window x = 3.5).
//  TRENCH (x = TX): a crowded front-line trench, parapet facing -z, no-man's land and a far ruined town.
// House-style 3D characters (white round heads, line-art faces, stick limbs, detailed WWI uniforms), CC0 PBR textures.
import * as THREE from 'three';
import { rng, smooth, clamp, lerp, ramp, at, FONT } from './kit';
import { CHAR_LIGHT } from './chars';
import { Character, syncCharLight } from './chars3d';
import { A, placeModel, pbr } from './assets';
import { softTex } from './env';
import { cameraFor, shots, TX, w } from './camera';
import { DURATION_S } from './timing';

const E = (eyes, brows, mouth, extra = {}) => ({ eyes, brows, mouth, ...extra });
const SNIPER_WIN = new THREE.Vector3(3.5, 4.3, -6.0);
const MUZZLE = new THREE.Vector3(3.5, 4.36, -5.72);
const WALL_Z = 3.0, WALL_END = 1.0, WALL_TOP = 1.05;

function canvasTex(w, h, draw) {
  const c = document.createElement('canvas'); c.width = w; c.height = h; draw(c.getContext('2d'), w, h);
  const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; t.anisotropy = 4; return t;
}

export function buildWorld() {
  const root = new THREE.Group();
  const R = rng(11);
  const std = (c, rough = 0.8, metal = 0, o = {}) => new THREE.MeshStandardMaterial({ color: c, roughness: rough, metalness: metal, ...o });
  // box with world-scaled UVs (texScale metres per texture repeat)
  const boxGeo = (wd, ht, dp, ts = 2) => {
    const g = new THREE.BoxGeometry(wd, ht, dp); const uv = g.attributes.uv;
    const dims = [[dp, ht], [dp, ht], [wd, dp], [wd, dp], [wd, ht], [wd, ht]];
    for (let f = 0; f < 6; f++) for (let k = 0; k < 4; k++) { const i = f * 4 + k; uv.setXY(i, uv.getX(i) * dims[f][0] / ts, uv.getY(i) * dims[f][1] / ts); }
    return g;
  };
  const box = (wd, ht, dp, m, x, y, z, parent = root, o = {}) => { const b = new THREE.Mesh(boxGeo(wd, ht, dp, o.ts || 2), m); b.position.set(x, y, z); if (o.ry) b.rotation.y = o.ry; if (o.rz) b.rotation.z = o.rz; if (o.rx) b.rotation.x = o.rx; b.castShadow = o.cast ?? true; b.receiveShadow = true; parent.add(b); return b; };
  const plane = (wd, dp, m, x, y, z, parent = root, uvs = 1) => { const g = new THREE.PlaneGeometry(wd, dp).rotateX(-Math.PI / 2); const uv = g.attributes.uv; for (let i = 0; i < uv.count; i++) uv.setXY(i, uv.getX(i) * wd / uvs, uv.getY(i) * dp / uvs); const p = new THREE.Mesh(g, m); p.position.set(x, y, z); p.receiveShadow = true; parent.add(p); return p; };

  // ---------------- materials ----------------
  const M = {
    cobble: pbr('cobblestone_02', { color: '#8a8478', rough: 0.95 }),
    mud: pbr('brown_mud_02', { color: '#7a6a58', rough: 0.9 }),
    brick: pbr('broken_brick_wall', { color: '#a08878', rough: 0.95 }),
    brick2: pbr('red_brick_plaster_patch_02', { color: '#a89888', rough: 0.95 }),
    plaster: pbr('damaged_plaster', { color: '#a8a296', rough: 0.95 }),
    rubble: pbr('rubble', { color: '#8a8070', rough: 1 }),
    hessian: pbr('hessian_230', { color: '#b8a47e', rough: 0.95 }),
    planks: pbr('weathered_planks', { color: '#8a7a68', rough: 0.9 }),
    planks2: pbr('brown_planks_05', { color: '#8a7058', rough: 0.85 }),
    rust: pbr('rusty_metal_02', { color: '#9a8070', rough: 0.7, metal: 0.4 }),
    burnt: pbr('burned_ground_01', { color: '#6a6058', rough: 1 }),
    dark: std('#120f0d', 1), wood: std('#4a3626', 0.85), iron: std('#2a2a2c', 0.5, 0.7),
  };
  for (const k of ['cobble', 'mud', 'brick', 'brick2', 'plaster', 'rubble', 'hessian', 'planks', 'planks2', 'rust', 'burnt']) {
    const m = M[k]; for (const t of [m.map, m.normalMap, m.roughnessMap]) if (t) { t.repeat.set(1, 1); t.wrapS = t.wrapT = THREE.RepeatWrapping; }
  }

  // ---------------- sky dome (Poly Haven wasteland clouds, graded cool) ----------------
  const skyMat = new THREE.ShaderMaterial({
    uniforms: { uSky: { value: A.sky.clouds || null }, uTint: { value: new THREE.Color(0.78, 0.84, 1.0) }, uExp: { value: 0.95 }, uRot: { value: 1.2 } },
    vertexShader: `varying vec3 vD; void main(){ vD = normalize(position); vec4 p = projectionMatrix * modelViewMatrix * vec4(position, 1.0); gl_Position = p.xyww; }`,
    fragmentShader: `uniform sampler2D uSky; uniform vec3 uTint; uniform float uExp, uRot; varying vec3 vD;
      void main(){ vec3 d = normalize(vD); float az = atan(d.z, d.x) + uRot; float u = az * 0.15915494 + 0.5; float el = asin(clamp(d.y, -1.0, 1.0)) * 57.29578;
        float v = clamp((el + 11.25) / 101.25, 0.004, 0.996); vec3 c = texture2D(uSky, vec2(u, v)).rgb; float l = dot(c, vec3(0.2126, 0.7152, 0.0722));
        c = mix(vec3(l), c, 0.55) * uTint * uExp; c = mix(c, vec3(0.42, 0.45, 0.52), smoothstep(8.0, -6.0, el) * 0.7); gl_FragColor = vec4(c, 1.0); }`,
    side: THREE.BackSide, depthWrite: false, fog: false,
  });
  const sky = new THREE.Mesh(new THREE.SphereGeometry(900, 48, 24), skyMat); sky.renderOrder = -10; sky.frustumCulled = false; root.add(sky);

  // ---------------- shared props ----------------
  const bagSrc = (() => { let m = null; if (A.models.cement_bag) A.models.cement_bag.traverse((o) => { if (o.isMesh && !m) m = o; }); return m; })();
  const bagGeo = bagSrc ? bagSrc.geometry.clone() : new THREE.BoxGeometry(0.46, 0.18, 0.7);
  bagGeo.computeBoundingBox(); { const bb = bagGeo.boundingBox; bagGeo.translate(-(bb.min.x + bb.max.x) / 2, -bb.min.y, -(bb.min.z + bb.max.z) / 2); }
  const bagMat = M.hessian.clone(); bagMat.color = new THREE.Color('#a8956c'); bagMat.roughness = 0.95; for (const k of ['map', 'normalMap', 'roughnessMap']) if (bagMat[k]) { bagMat[k] = bagMat[k].clone(); bagMat[k].repeat.set(2, 2); bagMat[k].needsUpdate = true; }
  const bagList = [];
  // a row of sandbags (long side across the row): from (x0,z0) to (x1,z1), `layers` high, base y
  const bagRow = (x0, z0, x1, z1, layers, y0 = 0, rr = R, opt = {}) => {
    const len = Math.hypot(x1 - x0, z1 - z0), ang = Math.atan2(x1 - x0, z1 - z0); const n = Math.max(1, Math.round(len / 0.44));
    for (let L = 0; L < layers; L++) for (let i = 0; i < n; i++) {
      if (opt.gap && L >= layers - 1 && rr() < opt.gap) continue;
      const u = (i + 0.5 + (L % 2) * 0.5) / n; if (u > 1) continue; const x = lerp(x0, x1, u), z = lerp(z0, z1, u);
      bagList.push([x + (rr() - 0.5) * 0.04, y0 + L * 0.17, z + (rr() - 0.5) * 0.06, ang + Math.PI / 2 + (rr() - 0.5) * 0.18, 0.95 + rr() * 0.12, (rr() - 0.5) * 0.08]);
    }
  };
  const rubblePile = (cx, cz, rad, hgt, n, seed, mat = M.rubble, parent = root) => {
    const rr = rng(seed); const geos = [new THREE.DodecahedronGeometry(1, 0), new THREE.BoxGeometry(1.6, 0.8, 1)];
    for (let i = 0; i < n; i++) { const a = rr() * 6.28, d = Math.sqrt(rr()) * rad; const s = 0.08 + rr() * 0.25 * (1 - d / rad * 0.6);
      const m = new THREE.Mesh(geos[i % 2], i % 3 === 0 ? M.brick : mat); m.scale.set(s * (0.8 + rr() * 0.6), s * (0.5 + rr() * 0.5), s * (0.8 + rr() * 0.6));
      m.position.set(cx + Math.cos(a) * d, Math.max(0, (1 - d / rad) * hgt * rr()) + s * 0.3, cz + Math.sin(a) * d); m.rotation.set(rr() * 3, rr() * 3, rr() * 3); m.castShadow = true; m.receiveShadow = true; parent.add(m); }
    const mound = new THREE.Mesh(new THREE.SphereGeometry(rad, 18, 8, 0, Math.PI * 2, 0, Math.PI / 2), mat); mound.scale.set(1, hgt / rad, 0.8); mound.position.set(cx, 0, cz); mound.receiveShadow = true; mound.castShadow = true; parent.add(mound);
  };
  const wireMat = std('#3a3430', 0.6, 0.6);
  const barbedWire = (x0, z0, x1, z1, y = 0.45, parent = root) => {
    const len = Math.hypot(x1 - x0, z1 - z0); const pts = []; const turns = len / 0.35;
    for (let i = 0; i <= turns * 12; i++) { const u = i / (turns * 12), a = u * turns * 6.283; pts.push(new THREE.Vector3(lerp(x0, x1, u) + Math.cos(a) * 0.05, y + Math.sin(a) * 0.35, lerp(z0, z1, u) + Math.cos(a) * 0.35)); }
    const m = new THREE.Mesh(new THREE.TubeGeometry(new THREE.CatmullRomCurve3(pts), Math.ceil(turns * 24), 0.008, 4), wireMat); m.castShadow = true; parent.add(m);
    for (let u = 0; u <= 1.001; u += 1 / Math.max(1, Math.round(len / 2))) box(0.07, 1.0, 0.07, M.wood, lerp(x0, x1, u), 0.45, lerp(z0, z1, u), parent, { rz: (R() - 0.5) * 0.25 });
  };
  const model = (n, h, x, y, z, ry = 0, parent = root) => { const g = placeModel(n, { h }); at(g, x, y, z, ry); parent.add(g); return g; };

  // ---------------- fire + smoke sprites ----------------
  const puffTex = softTex();
  const fireTex = canvasTex(64, 128, (g, W, H) => { const gr = g.createRadialGradient(32, 92, 2, 32, 80, 60); gr.addColorStop(0, 'rgba(255,250,200,1)'); gr.addColorStop(0.25, 'rgba(255,190,70,0.95)'); gr.addColorStop(0.6, 'rgba(230,80,20,0.5)'); gr.addColorStop(1, 'rgba(120,20,0,0)'); g.fillStyle = gr; g.beginPath(); g.moveTo(32, 0); g.quadraticCurveTo(64, 70, 54, 110); g.quadraticCurveTo(32, 128, 10, 110); g.quadraticCurveTo(0, 70, 32, 0); g.fill(); });
  const fires = [];
  const addFire = (x, y, z, s = 1, light = true, parent = root) => {
    const grp = new THREE.Group(); grp.position.set(x, y, z); parent.add(grp);
    const fl = []; for (let i = 0; i < 4; i++) { const sp = new THREE.Sprite(new THREE.SpriteMaterial({ map: fireTex, color: new THREE.Color(2.2, 1.6, 1.0), transparent: true, blending: THREE.AdditiveBlending, depthWrite: false, fog: false })); sp.scale.set(0.35 * s, 0.7 * s, 1); sp.position.set((i - 1.5) * 0.12 * s, 0.3 * s, (i % 2) * 0.05); grp.add(sp); fl.push(sp); }
    let L = null; if (light) { L = new THREE.PointLight('#ff9a40', 6 * s, 7 * s, 1.6); L.position.set(0, 0.6 * s, 0.3); grp.add(L); }
    fires.push({ grp, fl, L, s, ph: R() * 6 }); return grp;
  };
  const smokeCols = [];
  const smokeMat = (c, op) => new THREE.SpriteMaterial({ map: puffTex, color: new THREE.Color(c), transparent: true, opacity: op, depthWrite: false });
  const addSmoke = (x, y, z, scale = 3, n = 7, c = '#5a5a60', parent = root) => { const arr = []; for (let i = 0; i < n; i++) { const sp = new THREE.Sprite(smokeMat(c, 0.5)); parent.add(sp); arr.push(sp); } smokeCols.push({ x, y, z, scale, arr, ph: R() * 10 }); };

  // =====================================================================================================
  // STREET SET
  // =====================================================================================================
  const street = new THREE.Group(); root.add(street);
  plane(80, 22, M.cobble, 0, 0, 1.5, street, 2.2);
  plane(120, 60, M.mud, 0, -0.01, 30, street, 4); plane(120, 60, M.mud, 0, -0.01, -36, street, 4);
  // mud + scorch patches (soft-edged decals)
  const patchAlpha = canvasTex(128, 128, (g) => { const gr = g.createRadialGradient(64, 64, 10, 64, 64, 64); gr.addColorStop(0, '#fff'); gr.addColorStop(0.6, '#bbb'); gr.addColorStop(1, '#000'); g.fillStyle = gr; g.fillRect(0, 0, 128, 128); });
  for (let i = 0; i < 16; i++) { const m = (i % 3 === 0 ? M.burnt : M.mud).clone(); m.alphaMap = patchAlpha; m.transparent = true; m.depthWrite = false; const s = 1.5 + R() * 2.5; const p = plane(s, s * (0.6 + R() * 0.5), m, -14 + R() * 30, 0.004 + i * 0.0003, -4.5 + R() * 13, street, 2); p.rotation.y = R() * 3; }
  // craters
  for (const [x, z, r0] of [[-5.5, -1.6, 1.3], [5.8, 0.4, 1.0], [-11, 1.2, 1.5], [9.5, -3.2, 1.1]]) {
    const ring = new THREE.Mesh(new THREE.TorusGeometry(r0, r0 * 0.28, 8, 24), M.mud); ring.rotation.x = Math.PI / 2; ring.scale.set(1, 1, 0.45); ring.position.set(x, 0.02, z); ring.receiveShadow = true; street.add(ring);
    const pit = new THREE.Mesh(new THREE.CircleGeometry(r0 * 0.95, 24).rotateX(-Math.PI / 2), std('#2e261e', 0.6)); pit.position.set(x, 0.012, z); street.add(pit);
    rubblePile(x + r0, z + 0.2, 0.5, 0.15, 6, 100 + x * 3);
  }

  // ---- our cover: sandbag wall z = 3 (x -9.8 .. 1.0), 7 layers + rubble mound in front
  bagRow(-9.8, WALL_Z + 0.22, WALL_END, WALL_Z + 0.22, 6, 0, rng(3), { gap: 0.25 });
  bagRow(-9.8, WALL_Z - 0.22, WALL_END - 0.2, WALL_Z - 0.22, 5, 0, rng(4), { gap: 0.3 });
  bagRow(WALL_END - 0.05, WALL_Z + 0.4, WALL_END + 0.1, WALL_Z - 0.4, 6, 0, rng(5));   // end cap (the corner)
  for (let x = -9; x < 0.8; x += 2.1) rubblePile(x + R() * 0.8, WALL_Z - 0.9, 0.7, 0.35, 9, 200 + x * 7);
  // our side: ruined building corner at the left end + facades behind us (z = 9.6, facing the street)
  // ---- ruined facade builder (front faces `dir`: +1 = toward +z) ----
  const winGlows = [];
  const facade = (x0, x1, zf, H, dir, seed, o = {}) => {
    const rr = rng(seed), g = new THREE.Group(); root.add(g); const mat = o.mat || (rr() < 0.5 ? M.brick : M.brick2); const th = 0.42;
    const fh = 3.3, ww = 1.15, wh = 1.6, sill = 0.95, sp = o.sp || 2.5; const wdt = x1 - x0; const nW = Math.max(1, Math.floor(wdt / sp)); const off = (wdt - nW * sp) / 2;
    const zc = zf - dir * th / 2; const floors = Math.ceil(H / fh);
    const topAt = (x) => H - (o.jag ?? 1.6) * Math.abs(Math.sin(x * 1.7 + seed)) * (0.4 + 0.6 * Math.abs(Math.sin(x * 0.53 + seed * 2)));
    for (let f = 0; f < floors; f++) {
      const y0 = f * fh;
      // band under the windows (ground floor: doors/shopfront heights differ)
      const bandH = f === 0 ? (o.shop ? 0.5 : sill) : sill;
      box(wdt, bandH, th, mat, (x0 + x1) / 2, y0 + bandH / 2, zc, g);
      // piers between windows
      for (let i = 0; i <= nW; i++) {
        const pxL = i === 0 ? x0 : x0 + off + i * sp - (sp - ww) / 2, pxR = i === nW ? x1 : x0 + off + i * sp + (sp - ww) / 2;
        const pw = Math.max(0.1, (i === 0 ? x0 + off + (sp - ww) / 2 : pxR) - (i === 0 ? x0 : pxL));
        const pcx = i === 0 ? x0 + pw / 2 : i === nW ? x1 - (x1 - (x0 + off + nW * sp - (sp - ww) / 2)) / 2 : (pxL + pxR) / 2;
        const pwid = i === 0 ? pw : i === nW ? x1 - (x0 + off + nW * sp - (sp - ww) / 2) : pxR - pxL;
        const ytop = Math.min(y0 + fh, topAt(pcx)); const yb = y0 + bandH; if (ytop > yb) box(pwid, ytop - yb, th, mat, pcx, (yb + ytop) / 2, zc, g);
      }
      // band over the windows (lintel) per window bay, broken by the jagged top
      for (let i = 0; i < nW; i++) {
        const cx = x0 + off + (i + 0.5) * sp; const yb = y0 + bandH + wh, ytop = Math.min(y0 + fh, topAt(cx));
        if (ytop > yb + 0.05) box(ww + 0.02, ytop - yb, th, mat, cx, (yb + ytop) / 2, zc, g);
        const wy = y0 + bandH; if (wy + wh * 0.5 < topAt(cx)) {
          // window: frame, sill, sometimes a shutter, dark interior card or a warm glow
          if (!(o.skip && o.skip(i, f))) {
            box(ww + 0.16, 0.08, th + 0.12, M.plaster, cx, wy - 0.02, zc, g);
            const shut = rr(); if (shut < 0.35) { const sh = box(0.5, wh * 0.9, 0.04, M.planks2, cx + (rr() < 0.5 ? -1 : 1) * (ww / 2 + 0.22), wy + wh / 2, zf + dir * 0.06, g, { rz: (rr() - 0.5) * 0.4, ry: (rr() - 0.5) * 0.6 }); }
            if (!o.noInterior && wy + wh + 0.35 < topAt(cx)) { const back = new THREE.Mesh(new THREE.PlaneGeometry(ww, wh), rr() < (o.glow ?? 0.12) ? std('#000', 1, 0, { emissive: new THREE.Color('#ff8a30'), emissiveIntensity: 0.6 + rr() * 0.6 }) : M.dark); back.position.set(cx, wy + wh / 2, zf - dir * (th + 0.9)); if (dir < 0) back.rotation.y = Math.PI; g.add(back);
              if (back.material.emissive && back.material.emissiveIntensity > 0) winGlows.push(back); }
          }
        }
      }
    }
    // interior darkness volume (so windows read as deep rooms) + roof remains
    if (!o.noInterior) { const ib = box(wdt - 0.2, H * 0.9, 4, M.dark, (x0 + x1) / 2, H * 0.45, zf - dir * (th + 2.2), g, { cast: false }); }
    // broken beams sticking out of the top
    for (let k = 0; k < 2; k++) { const bx = lerp(x0 + 0.5, x1 - 0.5, rr()); const by = topAt(bx) - 0.4; box(0.16, 0.16, 2.2, M.wood, bx, by, zf - dir * 0.6, g, { rx: (rr() - 0.3) * 0.5, ry: (rr() - 0.5) * 0.4 }); }
    return g;
  };
  // far row (z = -6, facing the street); building B (x 1.5..6.5) is the sniper's, built separately below
  facade(-30, -16, -6.0, 7.5, 1, 31, { glow: 0.15 });
  facade(-16, -9, -6.0, 8.2, 1, 32);
  facade(-9, -3.5, -6.0, 6.4, 1, 33, { mat: M.plaster, glow: 0.2 });
  facade(-3.5, 1.5, -6.0, 9.0, 1, 34, { shop: true });
  facade(6.5, 12, -6.0, 6.0, 1, 35, { mat: M.plaster });
  facade(12, 18, -6.0, 8.4, 1, 36, { glow: 0.25 });
  facade(18, 32, -6.0, 7.0, 1, 37);
  // our side row (z = 9.6, facing -z) + side wall of the corner building at the wall's left end
  facade(-30, -12, 9.6, 7.0, -1, 41); facade(-12, -4, 9.6, 8.6, -1, 42, { glow: 0.2 }); facade(-4, 4, 9.6, 6.2, -1, 43, { mat: M.plaster }); facade(4, 12, 9.6, 7.8, -1, 44); facade(12, 30, 9.6, 6.8, -1, 45);
  box(0.45, 4.2, 6.2, M.brick, -10.2, 2.1, 6.4, street); box(0.45, 2.2, 3.0, M.brick, -10.2, 5.2, 7.7, street);
  // distant ruins + smoke behind the far row
  for (let i = 0; i < 16; i++) { const x = -40 + i * 5.4 + R() * 2, h = 6 + R() * 10; box(3 + R() * 3, h, 3, i % 2 ? M.brick : M.plaster, x, h / 2, -20 - R() * 8, street, { cast: false }); }
  for (let i = 0; i < 10; i++) { const x = -40 + i * 8 + R() * 3, h = 5 + R() * 8; box(4, h, 3, M.brick2, x, h / 2, 22 + R() * 6, street, { cast: false }); }
  addSmoke(-12, 6, -22, 4.5, 8, '#4a4a52'); addSmoke(9, 7, -26, 5, 8, '#55555e'); addSmoke(-22, 5, -14, 3.5, 6, '#4f4f58'); addSmoke(20, 5, 20, 4, 6, '#55555e');
  addFire(-7.2, 3.3, -6.3, 0.9); addFire(14.5, 0.0, -5.7, 1.0); addFire(-14, 0, 8.9, 0.9); addFire(8.2, 6.0, -6.6, 0.8, false);

  // ---- building B: the sniper's nest (x 1.5 .. 6.5), facade at z = -6, room on the first floor
  const bldB = new THREE.Group(); root.add(bldB);
  const bUpper = new THREE.Group(); bldB.add(bUpper);
  {
    const th = 0.42, zc = -6.0 - th / 2, mat = M.brick2;
    // ground floor: a big doorway (blown in) + walls
    box(1.4, 3.3, th, mat, 2.2, 1.65, zc, bldB); box(1.6, 3.3, th, mat, 5.7, 1.65, zc, bldB); box(2.1, 0.9, th, mat, 3.95, 2.85, zc, bldB);
    box(4.6, 3.2, 3.6, M.dark, 4.0, 1.6, -8.3, bldB, { cast: false });
    // first floor slab (room floor y = 3.3)
    box(5.0, 0.24, 4.2, M.planks2, 4.0, 3.18, -8.1, bUpper);
    // first floor facade with the sniper window at x = 3.5 (1.15 wide, sill 4.25 .. 5.75)
    box(5.0, 0.95, th, mat, 4.0, 3.3 + 0.475, zc, bUpper);           // band under the window
    box(1.42, 2.35, th, mat, 1.5 + 0.71, 4.25 + 1.175, zc, bUpper);    // left pier
    box(2.43, 2.35, th, mat, 4.075 + 1.215, 4.25 + 1.175, zc, bUpper); // right pier (with a second, boarded window)
    box(1.17, 0.75, th, mat, 3.5, 5.97, zc, bUpper);                    // lintel
    box(5.0, 1.2, th, mat, 4.0, 6.95, zc, bUpper);                      // top band
    box(1.3, 0.08, th + 0.14, M.plaster, 3.5, 4.24, zc, bUpper);        // sill
    for (let i = 0; i < 4; i++) box(0.95, 0.12, 0.05, M.planks2, 5.3, 4.5 + i * 0.32, -5.95, bUpper, { rz: (R() - 0.5) * 0.2 }); // boarded window
    // jagged broken top
    for (let i = 0; i < 6; i++) box(0.8, 0.4 + R() * 1.2, th, mat, 1.9 + i * 0.85, 7.55 + R() * 0.3, zc, bUpper);
    // room: back wall, side walls, ceiling (half collapsed)
    box(5.0, 3.4, 0.3, M.plaster, 4.0, 4.95, -10.15, bUpper); box(0.3, 3.4, 4.2, M.plaster, 1.45, 4.95, -8.1, bUpper); box(0.3, 3.4, 4.2, M.plaster, 6.55, 4.95, -8.1, bUpper);
    box(3.0, 0.22, 4.2, M.planks2, 5.0, 6.7, -8.1, bUpper);
    for (let i = 0; i < 4; i++) box(0.18, 0.18, 4.4, M.wood, 2.2 + i * 0.5, 6.6 - i * 0.05, -8.1, bUpper, { rx: 0.05 * i });
    // sandbags on the sill inside the window, sniper's kit
    bagRow(2.95, -6.42, 4.05, -6.42, 1, 4.26, rng(12));
    bagRow(2.7, -6.75, 4.3, -6.75, 3, 3.3, rng(13));
    model('ammo_box', 0.3, 4.6, 3.3, -7.0, 0.4, bUpper); model('old_military_crate', 0.45, 2.3, 3.3, -8.9, 0.6, bUpper); model('wooden_crate_01', 0.6, 5.6, 3.3, -9.3, 0.2, bUpper);
    model('wooden_lantern_01', 0.35, 2.4, 3.75, -8.9, 0, bUpper);
    rubblePile(5.5, -8.0, 0.8, 0.25, 8, 77, M.rubble, bUpper);
    const lan = new THREE.PointLight('#ffae5a', 4.5, 6, 1.6); lan.position.set(2.5, 4.3, -8.6); bUpper.add(lan);
    const winFill = new THREE.PointLight('#9ab0d8', 3, 5, 1.6); winFill.position.set(3.5, 4.6, -5.4); bUpper.add(winFill);
    // the bomb target: enemy ammo crates with a painted red X at the base of building B
    const tg = new THREE.Group(); tg.position.set(2.5, 0, -5.25); root.add(tg);
    model('wooden_military_crate', 0.55, -0.4, 0, 0, 0.1, tg); model('wooden_military_crate', 0.55, 0.45, 0, 0.05, -0.1, tg); model('wooden_military_crate', 0.5, 0.0, 0.55, 0.0, 0.05, tg);
    const xTex = canvasTex(256, 256, (g) => { g.clearRect(0, 0, 256, 256); g.strokeStyle = '#c81e1e'; g.lineCap = 'round'; g.lineWidth = 34; g.beginPath(); g.moveTo(40, 40); g.lineTo(216, 216); g.moveTo(216, 40); g.lineTo(40, 216); g.stroke(); g.globalAlpha = 0.5; g.lineWidth = 8; g.strokeStyle = '#7a0a0a'; g.beginPath(); g.moveTo(60, 230); g.lineTo(62, 256); g.moveTo(200, 228); g.lineTo(203, 256); g.stroke(); });
    const xm = new THREE.Mesh(new THREE.PlaneGeometry(1.5, 1.5), new THREE.MeshStandardMaterial({ map: xTex, transparent: true, roughness: 0.9, depthWrite: false })); xm.position.set(2.5, 1.35, -5.77); root.add(xm);
  }
  // street dressing
  for (const [x, z, r0] of [[-1.5, -5.3, 0.9], [8.5, -5.3, 1.2], [-6.5, -5.4, 1.0], [12.5, 8.6, 1.2], [-6, 8.7, 1.1]]) rubblePile(x, z, r0, 0.6, 14, 300 + x * 11);
  barbedWire(-14, -0.6, -7.5, -0.4); barbedWire(6.8, -1.6, 13, -1.0);
  model('barrel_03', 0.9, -8.6, 0, -4.6, 0.3); model('wooden_barrels_01', 1.0, 10.8, 0, -4.9, 1.0); model('old_military_crate', 0.45, -6.6, 0, 5.35, 0.4); model('ammo_box', 0.3, -4.3, 0, 4.7, 1.2);
  model('wooden_military_crate', 0.55, -7.4, 0, 4.9, 0.2); model('barrel_stove', 0.9, -9.0, 0, 5.4, 0); addFire(-9.0, 0.85, 5.4, 0.55);
  { const lamp = model('street_lamp_01', 3.9, 6.6, 0, -4.6, 0.3); lamp.rotation.z = -0.32; }
  { const lamp = model('street_lamp_01', 3.9, -12.5, 0, 8.2, 2.0); }
  // burned cart in the street
  { const cart = new THREE.Group(); cart.position.set(8.0, 0, 2.2); cart.rotation.y = 0.5; root.add(cart);
    box(2.0, 0.12, 1.1, M.burnt, 0, 0.62, 0, cart, { rz: 0.2 }); box(2.0, 0.4, 0.06, M.planks2, 0, 0.85, 0.53, cart, { rz: 0.2 }); box(2.0, 0.4, 0.06, M.planks2, 0, 0.85, -0.53, cart, { rz: 0.2 });
    const wh = new THREE.Mesh(new THREE.TorusGeometry(0.42, 0.05, 6, 16), M.wood); wh.position.set(-0.3, 0.42, 0.62); cart.add(wh); const wh2 = wh.clone(); wh2.position.set(0.5, 0.25, -0.62); wh2.rotation.x = 1.2; cart.add(wh2); }

  // =====================================================================================================
  // TRENCH SET (x = TX)
  // =====================================================================================================
  const trench = new THREE.Group(); root.add(trench);
  const TL = 46, GY = 1.85;
  plane(TL, 2.4, M.planks, TX, 0.0, 0, trench, 1.2);                     // duckboards
  for (let x = -TL / 2; x < TL / 2; x += 0.5) box(0.06, 0.04, 2.3, M.wood, TX + x, 0.02, 0, trench, { cast: false });
  plane(TL + 40, 80, M.mud, TX, GY, -41.25, trench, 4);                    // no-man's land
  plane(TL + 40, 30, M.mud, TX, GY, 16.25, trench, 4);                     // behind the trench
  box(TL, GY, 0.2, M.planks2, TX, GY / 2, -1.2, trench, { ts: 1.2 });       // front revetment
  box(TL, GY, 0.2, M.planks2, TX, GY / 2, 1.2, trench, { ts: 1.2 });        // back revetment
  for (let x = -TL / 2; x <= TL / 2; x += 1.6) { box(0.12, GY + 0.2, 0.12, M.wood, TX + x, GY / 2, -1.08, trench); box(0.12, GY + 0.2, 0.12, M.wood, TX + x, GY / 2, 1.08, trench); }
  box(TL, 0.42, 0.5, M.planks, TX, 0.21, -0.85, trench);                    // fire step
  bagRow(TX - TL / 2, -1.45, TX + TL / 2, -1.45, 4, GY, rng(21), { gap: 0.15 }); // parapet
  bagRow(TX - TL / 2, -1.9, TX + TL / 2, -1.9, 2, GY, rng(22), { gap: 0.4 });
  bagRow(TX - TL / 2, 1.45, TX + TL / 2, 1.45, 2, GY, rng(23), { gap: 0.3 });   // parados
  model('wooden_ladder', 2.4, TX - 6.2, 0, -0.95, 0, trench).rotation.x = -0.25;
  model('wooden_ladder', 2.4, TX + 6.0, 0, -0.95, 0, trench).rotation.x = -0.25;
  model('ammo_box', 0.3, TX - 2.7, 0.42, -0.85, 0.3, trench); model('old_military_crate', 0.45, TX + 1.9, 0, 0.75, 0.2, trench); model('wooden_crate_01', 0.6, TX - 4.8, 0, 0.8, 0.5, trench);
  model('barrel_03', 0.8, TX + 7.3, 0, 0.7, 0, trench);
  const lanterns = [];
  for (const x of [-7, -1.5, 4.5, 10]) { model('wooden_lantern_01', 0.32, TX + x, 1.55, 1.02, 0, trench); const l = new THREE.PointLight('#ffb060', 3.5, 5, 1.6); l.position.set(TX + x, 1.6, 0.8); trench.add(l); lanterns.push(l); }
  // no-man's land: barbed wire, craters, dead trees, far ruined town with the sniper's building (window at TX+1, y 3.5)
  barbedWire(TX - 20, -6, TX + 20, -6.5, GY + 0.45, trench); barbedWire(TX - 20, -10, TX + 20, -10.5, GY + 0.45, trench);
  for (let i = 0; i < 9; i++) { const ring = new THREE.Mesh(new THREE.TorusGeometry(1.4, 0.4, 8, 20), M.mud); ring.rotation.x = Math.PI / 2; ring.scale.set(1, 1, 0.4); ring.position.set(TX - 18 + i * 4.6 + R() * 2, GY + 0.02, -8 - R() * 22); trench.add(ring); }
  for (let i = 0; i < 6; i++) { const tr = new THREE.Group(); tr.position.set(TX - 16 + i * 6.5 + R() * 2, GY, -14 - R() * 16); trench.add(tr); box(0.22, 3 + R() * 2, 0.22, M.burnt, 0, 1.8, 0, tr, { rz: (R() - 0.5) * 0.3 }); box(0.1, 1.2, 0.1, M.burnt, 0.3, 2.8, 0, tr, { rz: -0.8 }); }
  for (let i = 0; i < 12; i++) { const x = TX - 30 + i * 5.2 + R() * 2, h = 4 + R() * 7; box(3.4, h, 3, i % 2 ? M.brick : M.plaster, x, GY + h / 2, -50 - R() * 6, trench, { cast: false }); }
  { // sniper's far building with a window hole the scope camera looks through
    const fz = -41.6, fx = TX + 1.0, mat = M.brick2; const g = trench;
    box(6, GY + 1.0, 0.4, mat, fx, (GY + 1.0) / 2 + 0.6, fz, g, { cast: false });
    box(2.6, 3.0, 0.4, mat, fx - 1.7, 4.3, fz, g, { cast: false }); box(2.6, 3.0, 0.4, mat, fx + 1.7, 4.3, fz, g, { cast: false }); box(6, 1.5, 0.4, mat, fx, 6.4, fz, g, { cast: false });
    box(0.8, 0.3, 0.4, mat, fx, 3.05, fz, g, { cast: false }); box(0.8, 1.8, 0.4, mat, fx, 4.95, fz, g, { cast: false });
  }
  addSmoke(TX - 10, GY + 4, -38, 5, 8, '#56565e'); addSmoke(TX + 12, GY + 3, -30, 4, 7, '#5a5a62'); addSmoke(TX + 2, GY + 5, -55, 6, 8, '#50505a');
  addFire(TX + 8, GY + 0.1, -34, 1.2, false); addFire(TX - 12, GY, -26, 1.0, false);

  // =====================================================================================================
  // INSTANCED SANDBAGS (all sets)
  // =====================================================================================================
  {
    const im = new THREE.InstancedMesh(bagGeo, bagMat, bagList.length); im.castShadow = true; im.receiveShadow = true;
    const m4 = new THREE.Matrix4(), q = new THREE.Quaternion(), e = new THREE.Euler(), s = new THREE.Vector3(), p = new THREE.Vector3();
    bagList.forEach(([x, y, z, ry, sc, rz], i) => { e.set(0, ry, rz); q.setFromEuler(e); s.set(sc, 0.95, sc); p.set(x, y, z); m4.compose(p, q, s); im.setMatrixAt(i, m4); });
    im.instanceMatrix.needsUpdate = true; im.frustumCulled = false; root.add(im);
  }

  // =====================================================================================================
  // 3D STORY PROPS
  // =====================================================================================================
  // rifle normalised: butt at the origin, muzzle along +x
  const rifleBase = (() => {
    const holder = new THREE.Group(); const src = A.models.bolt_action_rifle_7_62; if (!src) { holder.add(new THREE.Mesh(new THREE.BoxGeometry(1.2, 0.06, 0.04), M.wood)); return holder; }
    const g = src.clone(true); g.traverse((o) => { if (o.isMesh) { o.castShadow = true; o.receiveShadow = true; } });
    const inner = new THREE.Group(); inner.add(g); holder.add(inner);
    let b = new THREE.Box3().setFromObject(inner); let sz = b.getSize(new THREE.Vector3());
    if (sz.y > sz.x && sz.y > sz.z) inner.rotation.z = Math.PI / 2; else if (sz.z > sz.x) inner.rotation.y = Math.PI / 2;
    inner.updateMatrixWorld(true); b = new THREE.Box3().setFromObject(inner); sz = b.getSize(new THREE.Vector3());
    const k = 1.25 / sz.x; inner.scale.multiplyScalar(k); inner.updateMatrixWorld(true); b = new THREE.Box3().setFromObject(inner);
    inner.position.set(-b.min.x, -(b.min.y + b.max.y) / 2, -(b.min.z + b.max.z) / 2);
    return holder;
  })();
  const RIFLE_FLIP = false; // muzzle at the +x end after flipping (checked on stills)
  const makeRifle = () => { const r = rifleBase.clone(true); const o = new THREE.Group(); if (RIFLE_FLIP) { r.rotation.y = Math.PI; r.position.x = 1.25; } o.add(r); return o; };
  // helmets as loose props (Brodie, Stahlhelm)
  const brodieMat = new THREE.MeshStandardMaterial({ color: '#5d5f3a', roughness: 0.6, envMapIntensity: 0.6 });
  const makeBrodie = (s = 1) => { const g = new THREE.Group(); const r = 0.293 * s;
    const d = new THREE.Mesh(new THREE.SphereGeometry(1, 24, 10, 0, Math.PI * 2, 0, Math.PI / 2).scale(r * 0.86, r * 0.62, r * 0.86), brodieMat); d.castShadow = true; g.add(d);
    const b = new THREE.Mesh(new THREE.CylinderGeometry(r * 1.42, r * 1.48, r * 0.06, 32), brodieMat); b.castShadow = true; g.add(b);
    const ol = new THREE.Mesh(new THREE.CylinderGeometry(r * 1.47, r * 1.53, r * 0.04, 32), new THREE.MeshBasicMaterial({ color: '#141113', side: THREE.BackSide })); g.add(ol); return g; };
  const stahlMat = new THREE.MeshStandardMaterial({ color: '#55604f', roughness: 0.55 });
  const makeStahl = () => { const g = new THREE.Group(); const r = 0.293; const d = new THREE.Mesh(new THREE.SphereGeometry(r * 1.06, 24, 12, 0, Math.PI * 2, 0, Math.PI * 0.5), stahlMat); d.castShadow = true; g.add(d); const f = new THREE.Mesh(new THREE.CylinderGeometry(r * 1.06, r * 1.32, r * 0.42, 28, 1, true), stahlMat); f.position.y = -r * 0.2; g.add(f); return g; };
  // dummy head on a stick (white head, painted face, Brodie, big mustache)
  const dummyFaceTex = canvasTex(256, 256, (g) => { g.fillStyle = '#f2efe6'; g.fillRect(0, 0, 256, 256); g.fillStyle = '#141113'; g.beginPath(); g.ellipse(92, 120, 10, 16, 0, 0, 7); g.ellipse(164, 120, 10, 16, 0, 0, 7); g.fill(); g.lineWidth = 8; g.strokeStyle = '#141113'; g.beginPath(); g.moveTo(70, 88); g.lineTo(108, 96); g.moveTo(186, 88); g.lineTo(148, 96); g.stroke(); g.fillStyle = '#2a1a12'; g.beginPath(); g.moveTo(128, 150); g.bezierCurveTo(160, 132, 196, 150, 210, 136); g.bezierCurveTo(206, 172, 160, 176, 128, 164); g.bezierCurveTo(96, 176, 50, 172, 46, 136); g.bezierCurveTo(60, 150, 96, 132, 128, 150); g.fill(); g.beginPath(); g.arc(128, 190, 22, 0.15, Math.PI - 0.15); g.lineWidth = 7; g.stroke(); g.fillStyle = 'rgba(200,60,60,0.35)'; g.beginPath(); g.ellipse(70, 160, 16, 9, 0, 0, 7); g.ellipse(186, 160, 16, 9, 0, 0, 7); g.fill(); });
  const makeDummy = () => { const g = new THREE.Group(); const head = new THREE.Mesh(new THREE.SphereGeometry(0.27, 28, 18), new THREE.MeshStandardMaterial({ color: '#ffffff', roughness: 0.55, map: dummyFaceTex })); head.rotation.y = -Math.PI / 2; head.castShadow = true; g.add(head);
    const ol = new THREE.Mesh(new THREE.SphereGeometry(0.285, 20, 14), new THREE.MeshBasicMaterial({ color: '#141113', side: THREE.BackSide })); g.add(ol);
    const hb = makeBrodie(0.95); hb.position.y = 0.17; hb.rotation.x = -0.1; g.add(hb); const stick = new THREE.Mesh(new THREE.CylinderGeometry(0.018, 0.02, 1.4, 6), M.wood); stick.position.y = -0.95; g.add(stick); g.userData.head = head; return g; };
  // mirror on a stick
  const mirror = new THREE.Group(); root.add(mirror);
  { const fr = new THREE.Mesh(new THREE.BoxGeometry(0.3, 0.22, 0.025), std('#5a3a1e', 0.6)); mirror.add(fr);
    const gl = new THREE.Mesh(new THREE.PlaneGeometry(0.26, 0.18), new THREE.MeshStandardMaterial({ color: '#e8f0f8', roughness: 0.03, metalness: 1.0, envMapIntensity: 2.8, emissive: new THREE.Color('#9ab0d8'), emissiveIntensity: 1.1 })); gl.position.z = 0.014; mirror.add(gl); mirror.userData.glass = gl; }
  const mirrorStick = new THREE.Mesh(new THREE.CylinderGeometry(0.012, 0.012, 1, 6), M.wood); mirrorStick.castShadow = true; root.add(mirrorStick);
  const dummyT = makeDummy(); root.add(dummyT);     // trench dummy
  const dummyS = makeDummy(); root.add(dummyS);     // street dummy ("do it again")
  const flyHelm = []; for (let i = 0; i < 4; i++) { const h = makeBrodie(); h.visible = false; root.add(h); flyHelm.push(h); }
  const flyStahl = makeStahl(); flyStahl.visible = false; root.add(flyStahl);
  const handHelm = makeBrodie(); handHelm.visible = false; root.add(handHelm);   // the bait soldier's helmet in hand / on the rifle
  const handHelm2 = makeBrodie(); handHelm2.visible = false; root.add(handHelm2); // the distractor's helmet on his rifle
  const fallRifle = makeRifle(); fallRifle.visible = false; root.add(fallRifle);
  const binoc = new THREE.Group(); root.add(binoc); binoc.visible = false;
  { const bm = std('#2a2a24', 0.45, 0.3); for (const sx of [-0.075, 0.075]) { const c = new THREE.Mesh(new THREE.CylinderGeometry(0.055, 0.06, 0.2, 16).rotateX(Math.PI / 2), bm); c.position.x = sx; c.castShadow = true; binoc.add(c); const ln = new THREE.Mesh(new THREE.CircleGeometry(0.045, 16), std('#7aa0b8', 0.05, 0.6)); ln.position.set(sx, 0, 0.101); binoc.add(ln); const o = new THREE.Mesh(new THREE.CylinderGeometry(0.065, 0.07, 0.21, 16).rotateX(Math.PI / 2), new THREE.MeshBasicMaterial({ color: '#141113', side: THREE.BackSide })); o.position.x = sx; binoc.add(o); } box(0.1, 0.05, 0.08, bm, 0, 0, 0, binoc); }

  // ---- biplanes + money bombs ----
  const roundel = canvasTex(128, 128, (g) => { g.fillStyle = '#1f3c8a'; g.beginPath(); g.arc(64, 64, 62, 0, 7); g.fill(); g.fillStyle = '#f2efe6'; g.beginPath(); g.arc(64, 64, 42, 0, 7); g.fill(); g.fillStyle = '#c8201e'; g.beginPath(); g.arc(64, 64, 22, 0, 7); g.fill(); });
  const dollarTex = canvasTex(128, 128, (g) => { g.fillStyle = '#1c1c20'; g.fillRect(0, 0, 128, 128); g.fillStyle = '#e8c040'; g.font = `900 92px ${FONT}`; g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillText('$', 64, 70); });
  const planeMat = std('#6a6a3a', 0.6), planeMat2 = std('#8a7a4a', 0.65);
  const makePlane = () => { const p = new THREE.Group();
    const fus = new THREE.Mesh(new THREE.CylinderGeometry(0.42, 0.18, 5.2, 12).rotateX(Math.PI / 2), planeMat); fus.castShadow = true; p.add(fus);
    const nose = new THREE.Mesh(new THREE.CylinderGeometry(0.46, 0.46, 0.5, 14).rotateX(Math.PI / 2), M.iron); nose.position.z = 2.7; p.add(nose);
    for (const y of [0.9, -0.35]) { const wg = new THREE.Mesh(boxGeo(8.4, 0.09, 1.25), planeMat2); wg.position.set(0, y, 0.9); wg.castShadow = true; p.add(wg);
      for (const s of [-1, 1]) { const rd = new THREE.Mesh(new THREE.CircleGeometry(0.5, 20).rotateX(-Math.PI / 2), new THREE.MeshStandardMaterial({ map: roundel, roughness: 0.6 })); rd.position.set(s * 3.0, y + 0.05, 0.9); p.add(rd); } }
    for (const x of [-2.6, -1.0, 1.0, 2.6]) { const st = new THREE.Mesh(new THREE.CylinderGeometry(0.03, 0.03, 1.25, 5), M.wood); st.position.set(x, 0.28, 0.9); p.add(st); }
    const tail = new THREE.Mesh(boxGeo(2.6, 0.06, 0.8), planeMat2); tail.position.set(0, 0.1, -2.4); p.add(tail); const fin = new THREE.Mesh(boxGeo(0.06, 0.9, 0.8), planeMat2); fin.position.set(0, 0.5, -2.45); p.add(fin);
    const prop = new THREE.Mesh(new THREE.CircleGeometry(1.1, 24), new THREE.MeshBasicMaterial({ color: '#222', transparent: true, opacity: 0.25, side: THREE.DoubleSide, depthWrite: false })); prop.position.z = 2.98; p.add(prop); p.userData.prop = prop;
    const pilot = new THREE.Mesh(new THREE.SphereGeometry(0.26, 16, 12), std('#ffffff', 0.5)); pilot.position.set(0, 0.55, -0.3); p.add(pilot);
    const cap = new THREE.Mesh(new THREE.SphereGeometry(0.27, 16, 8, 0, Math.PI * 2, 0, Math.PI / 2), std('#5a3e22', 0.7)); cap.position.set(0, 0.58, -0.3); p.add(cap);
    for (const s of [-1, 1]) { const wl = new THREE.Mesh(new THREE.TorusGeometry(0.3, 0.08, 8, 16), M.iron); wl.rotation.y = Math.PI / 2; wl.position.set(s * 0.8, -1.2, 1.6); p.add(wl); }
    p.scale.setScalar(0.8); p.visible = false; root.add(p); return p; };
  const planes = [makePlane(), makePlane()];
  const bombs = []; for (let i = 0; i < 4; i++) { const b = new THREE.Group(); const body = new THREE.Mesh(new THREE.SphereGeometry(0.25, 16, 12).scale(1, 1, 2.0), new THREE.MeshStandardMaterial({ color: '#1c1c20', roughness: 0.5, map: dollarTex })); b.add(body); const fin = new THREE.Mesh(boxGeo(0.5, 0.04, 0.2), M.iron); fin.position.z = -0.5; b.add(fin); const fin2 = fin.clone(); fin2.rotation.z = Math.PI / 2; b.add(fin2); b.visible = false; root.add(b); bombs.push(b); }

  // ---- money rain (banknotes + coins) ----
  const billTex = canvasTex(256, 128, (g) => { g.fillStyle = '#a8cc98'; g.fillRect(0, 0, 256, 128); g.strokeStyle = '#3a6a3a'; g.lineWidth = 6; g.strokeRect(8, 8, 240, 112); g.fillStyle = '#2f5a2f'; g.beginPath(); g.ellipse(128, 64, 34, 40, 0, 0, 7); g.fill(); g.fillStyle = '#d8ecd0'; g.font = `900 56px ${FONT}`; g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillText('$', 128, 68); g.fillStyle = '#2f5a2f'; g.font = `900 30px ${FONT}`; g.fillText('100', 44, 34); g.fillText('100', 212, 96); });
  const NB = 240, NC = 90;
  const bills = new THREE.InstancedMesh(new THREE.PlaneGeometry(0.3, 0.15), new THREE.MeshStandardMaterial({ map: billTex, side: THREE.DoubleSide, roughness: 0.7 }), NB); bills.frustumCulled = false; bills.castShadow = true; root.add(bills);
  const coins = new THREE.InstancedMesh(new THREE.CylinderGeometry(0.06, 0.06, 0.015, 16), new THREE.MeshStandardMaterial({ color: '#e8b830', roughness: 0.25, metalness: 1.0 }), NC); coins.frustumCulled = false; root.add(coins);
  const money0 = []; { const rr = rng(51); for (let i = 0; i < NB + NC; i++) money0.push([rr(), rr(), rr(), rr(), rr()]); }

  // ---- FX: muzzle flashes, dirt puffs, sparks, tracers, explosion ----
  const starTex = canvasTex(256, 256, (g) => { const c = 128; const gr = g.createRadialGradient(c, c, 0, c, c, 128); gr.addColorStop(0, 'rgba(255,255,240,1)'); gr.addColorStop(0.12, 'rgba(255,230,140,1)'); gr.addColorStop(0.35, 'rgba(255,150,40,0.6)'); gr.addColorStop(1, 'rgba(255,80,0,0)'); g.fillStyle = gr; g.beginPath(); for (let k = 0; k < 16; k++) { const a = k / 16 * 6.283, r0 = k % 2 ? 40 : 128; g.lineTo(c + Math.cos(a) * r0, c + Math.sin(a) * r0); } g.closePath(); g.fill(); });
  const sparkTex = canvasTex(128, 128, (g) => { g.strokeStyle = '#fff2b0'; g.lineCap = 'round'; for (let k = 0; k < 10; k++) { const a = k / 10 * 6.283 + 0.3; g.lineWidth = 6; g.beginPath(); g.moveTo(64 + Math.cos(a) * 14, 64 + Math.sin(a) * 14); g.lineTo(64 + Math.cos(a) * 60, 64 + Math.sin(a) * 60); g.stroke(); } const gr = g.createRadialGradient(64, 64, 0, 64, 64, 22); gr.addColorStop(0, '#fff'); gr.addColorStop(1, 'rgba(255,220,120,0)'); g.fillStyle = gr; g.fillRect(0, 0, 128, 128); });
  const mkSprite = (map, col, add = true, op = 1) => { const s = new THREE.Sprite(new THREE.SpriteMaterial({ map, color: new THREE.Color(col), transparent: true, opacity: op, blending: add ? THREE.AdditiveBlending : THREE.NormalBlending, depthWrite: false, fog: false })); s.visible = false; root.add(s); return s; };
  const flashS = mkSprite(starTex, '#ffffff'); const flashS2 = mkSprite(starTex, '#ffffff');
  const flashL = new THREE.PointLight('#ffb050', 0, 12, 1.4); root.add(flashL);
  const puffs = []; for (let i = 0; i < 10; i++) { const s = new THREE.Sprite(new THREE.SpriteMaterial({ map: puffTex, color: new THREE.Color('#8a7660'), transparent: true, depthWrite: false })); s.visible = false; root.add(s); puffs.push(s); }
  const sparks = [mkSprite(sparkTex, '#ffe8a0'), mkSprite(sparkTex, '#ffe8a0')];
  const tracer = new THREE.Mesh(new THREE.CylinderGeometry(0.012, 0.012, 1, 6).rotateX(Math.PI / 2), new THREE.MeshBasicMaterial({ color: new THREE.Color(3, 2.4, 1.2), transparent: true, opacity: 0.9, depthWrite: false })); tracer.visible = false; root.add(tracer);
  const mirrorGlint = mkSprite(starTex, '#ffffff');
  const boomFire = []; for (let i = 0; i < 9; i++) boomFire.push(mkSprite(fireTex, '#ffffff'));
  const boomSmoke = []; for (let i = 0; i < 10; i++) { const s = new THREE.Sprite(smokeMat('#3a3634', 0.85)); s.visible = false; root.add(s); boomSmoke.push(s); }
  const boomL = new THREE.PointLight('#ff8a30', 0, 30, 1.2); boomL.position.set(4, 5, -4.5); root.add(boomL);
  const debris = new THREE.InstancedMesh(new THREE.BoxGeometry(0.22, 0.1, 0.12), M.brick2, 60); debris.frustumCulled = false; debris.castShadow = true; root.add(debris);
  const deb0 = []; { const rr = rng(61); for (let i = 0; i < 60; i++) deb0.push([rr() - 0.5, rr(), rr() - 0.2, rr(), rr()]); }

  // =====================================================================================================
  // CHARACTERS
  // =====================================================================================================
  const chars = [];
  const add = (spec, o, vis, pos) => { const c = new Character(spec, o); c.vis = vis; chars.push(c); root.add(c.root); if (pos) at(c.root, ...pos); c.rifle = null; return c; };
  const KH = ['#8a7a4e', '#7e7048', '#94845a', '#857650'];
  const tommy = (seed, o = {}) => ({ hat: 'brodie', outfit: 'tommy', top: KH[seed % 4], bottom: KH[(seed + 1) % 4], puttees: '#6e6444', seed, ...o });
  const german = (seed, o = {}) => ({ hat: 'stahlhelm', outfit: 'german', top: '#6e7466', bottom: '#5a5e54', puttees: '#4a4a40', webbing: '#2e2218', seed, ...o });
  const giveRifle = (c) => { c.rifle = makeRifle(); c.body.add(c.rifle); return c; };
  // time helpers
  const T = { and: w('and', 0, 2.08), easy: w('easy', 0, 4.64), just: w('just', 0, 5.52), wrong: w('wrong', 0, 6.72), a1: w('a', 0, 7.36), what: w('what', 0, 10.48), this1: w('this', 0, 11.44),
    first: w('first', 0, 15.68), we: w('we', 0, 17.84), secondly: w('secondly', 0, 19.92), a7: w('a', 0, 21.68), is3: w('is', 0, 24.64), lets: w("let's", 0, 26.0), snipers: w('snipers', 0, 27.52), so: w('so', 0, 28.64),
    soldiers1: w('soldiers', 0, 32.08), taking: w('taking', 0, 33.28), helmets: w('helmets', 0, 33.84), barely: w('barely', 0, 34.48), fool: w('fool', 0, 36.32), real: w('real', 0, 38.16), soldier3: w('soldier', 0, 38.4), some: w('some', 0, 39.28), dummy: w('dummy', 0, 41.6),
    then: w('then', 0, 42.96), again: w('again', 0, 46.24), but: w('but', 0, 46.8), mirror: w('mirror', 0, 47.92), catch: w('catch', 0, 50.16), finally: w('finally', 0, 51.43), a12: w('a', 0, 54.87), peek: w('peek', 0, 56.95), and9: w('and', 0, 58.23),
    even1: w('even', 0, 62.15), half: w('half', 0, 63.43), that2: w('that', 0, 64.15), needs: w('needs', 0, 65.19), take2: w('take', 0, 65.51), alt: w('alternatively', 0, 66.39), air: w('air', 0, 67.86), position: w('position', 0, 68.47), but1: w('but', 0, 69.03), money: w('money', 0, 70.47) };
  T.ping2 = T.soldier3 + 0.05; T.dummyPing = T.dummy + 0.95; T.decoyUp = T.even1 + 0.15; T.decoyPing = T.half - 0.05; T.markFire = T.needs - 0.02; T.ko = T.take2 + 0.06; T.boom = T.position - 0.02; T.popPing = T.is3 + 0.14;
  // sniper shots: [time, kind] kind: 'wall' (impact on our wall), 'ground', 'ping' (helmet), 'far' (unseen)
  const SHOTS = [[0.0, 'wall', new THREE.Vector3(-0.15, 1.08, 2.85)], [1.5, 'wall', new THREE.Vector3(-0.95, 1.1, 2.85)], [T.wrong + 0.1, 'ground', new THREE.Vector3(1.45, 0.05, 3.25)],
    [T.wrong + 0.42, 'wall', new THREE.Vector3(0.85, 1.05, 2.7)], [T.a1 + 0.3, 'ground', new THREE.Vector3(1.6, 0.05, 2.6)], [T.a1 + 0.85, 'wall', new THREE.Vector3(-0.4, 1.08, 2.8)],
    [T.popPing - 0.05, 'ping', new THREE.Vector3(-2.0, 1.92, 3.75)], [T.snipers + 0.08, 'far', null], [T.catch + 0.1, 'far', null], [T.decoyPing - 0.05, 'ping', new THREE.Vector3(-3.0, 1.75, 3.05)]];

  // ---- the hero (street): Brodie, khaki tunic, puttees, round cartoon bomb
  const HERO_X = -0.4, HERO_Z = 3.75;
  const hero = add(tommy(1, { mustache: null }), { scale: 1.0, pose: (t) => {
    const flinch = SHOTS.some(([ts]) => t > ts && t < ts + 0.25) ? 1 : 0;
    if (t < T.and) return { crouch: 0.86, armL: 0.9, armR: 1.05, propL: 'bomb', jump: flinch * 10, expr: E('wide', 'worried', 'grit', { sweat: true, sweatY: (t * 30) % 60, lines: flinch > 0, lookY: -0.2, look: 0.5 }) };
    if (t < T.easy) return { crouch: 0.32, armL: 0.7, armR: 0.9, propR: 'bomb', yawAbs: Math.PI + 0.28, expr: E('dot', 'raised', 'line') };
    if (t < T.just) return { crouch: 0.42, armL: 0.6, armR: 2.5, propL: 'bomb', tilt: 0.08, expr: E('closed', 'smug', 'smirk') };
    if (t < T.wrong + 0.18) { const walking = t < T.just + 0.6; return { crouch: 0.05, armL: walking ? 1.2 + Math.sin(t * 9) * 0.2 : 0.7, armR: walking ? 0.5 : 2.5, propL: 'bomb', walk: walking ? t * 9 : 0, tilt: walking ? 0 : 0.1, expr: E(walking ? 'happy' : 'closed', 'raised', 'grin', { look: 0.4 }) }; }
    if (t < T.wrong + 0.7) { const u = ramp(T.wrong + 0.18, T.wrong + 0.7, t); return { crouch: lerp(0.0, 0.8, u), jump: Math.sin(u * Math.PI) * 60, armL: 2.6, armR: 2.7, propL: 'bomb', lean: -0.25 * Math.sin(u * Math.PI), expr: E('wide', 'shock', 'shout', { sweat: true, lines: true }) }; }
    if (t < T.what) return { crouch: 0.86, armL: 0.9, armR: 1.0, propL: 'bomb', jump: flinch * 8, expr: E('wide', 'worried', 'grit', { sweat: true, sweatY: (t * 30) % 60, lines: flinch > 0, look: 0.6 }) };
    if (t < T.this1 + 0.3) return { crouch: 0.75, armL: 1.65, armR: 1.65, propL: 'bomb', tilt: -0.1, expr: E('dot', 'worried', 'frown', { sweat: true, sweatY: 20 }) };
    if (t < T.we) return { crouch: 0.05, armL: 2.15, armR: 2.15, binoc: true, yawAbs: Math.PI + lerp(-0.45, 0.28, ramp(T.first, T.we, t)), expr: E('dot', 'flat', 'line') };
    if (t < T.secondly) return { crouch: 0.0, armL: 2.15, armR: 2.15, binoc: true, headY: 0, expr: E('squint', 'angry', 'line', { look: Math.sin(t * 1.5) * 0.4 }) };
    if (t < T.but1) return { crouch: 0.82, armL: 0.6, armR: 0.8, propL: 'bomb', expr: E('half', 'flat', 'line', { look: 0.4 }) };
    return { crouch: 0.15, armL: 2.6, armR: 2.2, propR: 'bill', expr: E('wide', 'shock', 'o', { lookY: -0.8, lines: true }) };
  } }, (t) => t < T.then - 0.5 || t >= T.but1 - 0.1, [HERO_X, 0, HERO_Z]);
  const heroX = (t) => { if (t >= T.just && t < T.wrong + 0.18) return lerp(HERO_X, 1.65, smooth(T.just - 0.1, T.just + 0.55, t)); if (t >= T.wrong + 0.18 && t < T.wrong + 0.7) return lerp(1.65, 0.15, smooth(T.wrong + 0.18, T.wrong + 0.7, t)); if (t >= T.wrong + 0.7 && t < T.what) return 0.15; if (t >= T.what && t < T.first) return -0.3; return HERO_X; };
  // ---- buddies along the wall (crowded frontline), each with a rifle
  const street_crowd = [];
  const CROWD = [[-8.7, 3.72, 0.8], [-7.9, 3.8, 0.7], [-7.0, 3.68, 0.85], [-6.2, 3.85, 0.6], [-5.6, 4.7, 0.35], [-4.4, 3.75, 0.82], [-4.75, 4.8, 0.3], [-1.3, 3.8, 0.75], [-2.65, 3.7, 0.84], [-8.0, 4.8, 0.3], [-11.2, 5.4, 0.0], [-11.8, 6.6, 0.0]];
  CROWD.forEach(([x, z, cr], i) => {
    const sp = tommy(10 + i, { mustache: i % 3 === 0 ? ['#3a2418', '#6a4a2a', '#141414'][i % 3] : null, hat: i === 10 ? 'officercap' : 'brodie', chevrons: i === 4 ? 2 : 0 });
    const ph = R() * 6;
    const c = add(sp, { scale: 0.96 + R() * 0.1, pose: (t) => {
      const flinch = SHOTS.some(([ts, k]) => k !== 'far' && t > ts && t < ts + 0.3) ? 1 : 0;
      if (t > T.but1 - 0.1) return { crouch: cr * 0.3, armL: 2.4 + Math.sin(t * 8 + ph) * 0.2, armR: 2.0, rifle: 'back', expr: E('wide', 'shock', i % 2 ? 'o' : 'grin', { lookY: -0.9, look: Math.sin(ph) * 0.4 }) };
      if (t > T.what && t < T.this1 + 0.3 && i === 7) return { crouch: 0.7, armL: 1.6, armR: 1.6, rifle: 'back', expr: E('dot', 'worried', 'line', { look: 0.6 }) };
      return { crouch: cr, armL: 0.75, armR: 1.05, rifle: 'port', jump: flinch * 6, expr: flinch ? E('wide', 'shock', 'grit', { sweat: true, lines: true }) : E(i % 4 === 0 ? 'half' : 'dot', i % 2 ? 'worried' : 'flat', i % 3 ? 'line' : 'frown', { look: Math.sin(t * 0.7 + ph) * 0.6, sweat: i % 3 === 1, sweatY: (t * 20 + ph * 10) % 60 }) };
    } }, i === 7 ? (t) => !(t >= T.finally - 0.3 && t < T.a12) : (t) => true, [x, 0, z]);
    giveRifle(c); street_crowd.push(c);
  });
  // ---- the soldier who pops up (helmet pinged off)
  const popper = giveRifle(add(tommy(30, { mustache: '#3a2418' }), { pose: (t) => {
    if (t >= T.secondly && t < T.a7) return { crouch: 0.05, armL: 1.6, armR: 1.5, rifle: 'aim', yawAbs: 2.63, expr: E('squint', 'angry', 'grit') };
    if (t < T.is3) return { crouch: 0.84, armL: 0.75, armR: 1.0, rifle: 'port', expr: E('dot', 'flat', 'line', { look: 0.3 }) };
    if (t < T.popPing) { const u = ramp(T.is3, T.popPing, t); return { crouch: lerp(0.84, 0.0, u), armL: 1.0, armR: 1.2, rifle: 'port', expr: E('dot', 'angry', 'grit') }; }
    if (t < T.lets) { const u = ramp(T.popPing + 0.45, T.popPing + 1.0, t); const k = ramp(T.popPing, T.popPing + 0.2, t); return { crouch: lerp(0.0, 0.6, u), armL: lerp(1.0, 2.5, k), armR: lerp(1.2, 2.6, k), rifle: 'port', hatOff: true, jump: Math.sin(k * Math.PI) * 18, tilt: Math.sin(t * 9) * 0.12 * k, expr: u > 0.1 ? E('closed', 'worried', 'o', { lines: true, sweat: true }) : E('wide', 'shock', 'o', { lines: true, sweat: true }) }; }
    if (t > T.but1 - 0.1) return { crouch: 0.3, armL: 2.5, armR: 2.2, rifle: 'back', hatOff: true, expr: E('wide', 'raised', 'grin', { lookY: -0.9 }) };
    return { crouch: 0.84, armL: 0.75, armR: 1.0, rifle: 'port', hatOff: true, expr: E('half', 'worried', 'line') };
  } }, (t) => true, [-2.0, 0, 3.75]));
  // ---- the marksman (also the mirror man)
  const markX = (t) => t < T.finally ? 0.62 : t < T.a12 ? -0.2 : t < T.that2 ? 0.7 : t < T.take2 ? lerp(0.7, 1.15, smooth(T.that2 + 0.05, T.that2 + 0.6, t)) : 0.7;
  const marks = giveRifle(add(tommy(40, { mustache: '#141414', hat: 'brodie' }), { pose: (t) => {
    if (t < T.but) return { crouch: 0.4, armL: 2.7, armR: 2.75, rifle: 'none', expr: E('dot', 'raised', 'smile', { look: 0.5 }) }; // holding the dummy up
    if (t < T.catch) return { crouch: 0.62, armL: 1.6, armR: 1.4, rifle: 'none', lean: -0.12, expr: E('squint', 'flat', 'line', { look: 0.8 }) };
    if (t < T.finally) return { crouch: 0.62, armL: 1.6, armR: 2.6, rifle: 'none', lean: -0.12, expr: E('wide', 'raised', 'grin', { look: 0.8, lines: true }) };
    if (t < T.a12) return { crouch: 0.78, armL: 1.3, armR: 0.9, rifle: 'port', expr: E('dot', 'angry', 'line', { look: -0.6 }) };
    if (t < T.that2) return { crouch: 0.66, armL: 0.8, armR: 1.1, rifle: 'port', expr: E('half', 'angry', 'grit', { look: 0.7, sweat: true, sweatY: (t * 20) % 60 }) };
    if (t < T.take2) { const fire = t > T.markFire && t < T.markFire + 0.12; return { crouch: 0.3, lean: -0.32 * smooth(T.that2, T.that2 + 0.5, t), rifle: 'aim', armL: 1.6, armR: 1.5, yawAbs: 2.92, jump: fire ? 6 : 0, expr: E('squint', 'angry', 'grit') }; }
    if (t > T.but1 - 0.1) return { crouch: 0.2, armL: 2.6, armR: 2.6, rifle: 'back', expr: E('happy', 'raised', 'grin', { lookY: -0.8 }) };
    return { crouch: 0.6, armL: 2.5, armR: 0.9, rifle: 'port', expr: E('happy', 'proud', 'grin') };
  } }, (t) => t >= T.then - 0.5, [0.62, 0, 3.75]));
  // ---- the distractor
  const distX = (t) => t < T.finally ? -3.0 : t < T.a12 ? -1.05 : -3.0;
  const dist = giveRifle(add(tommy(41, { mustache: null }), { pose: (t) => {
    if (t >= T.finally && t < T.a12) return { crouch: 0.78, armL: 2.2, armR: 1.0, propL: 'watch', rifle: 'back', expr: E('dot', 'raised', 'smile', { look: 0.6 }) };
    if (t >= T.and9 && t < T.even1) return { crouch: 0.72, armL: 2.5, armR: 2.6, rifle: 'up', hatOff: true, expr: E('closed', 'smug', 'grin') };
    if (t >= T.even1 && t < T.but1 - 0.1) { const up = smooth(T.decoyUp, T.decoyUp + 0.4, t); return { crouch: 0.72, armL: lerp(2.5, 2.9, up), armR: lerp(2.6, 2.95, up), rifle: 'up', hatOff: true, expr: t > T.decoyPing ? E('wide', 'raised', 'grin', { lines: true }) : E('dot', 'raised', 'smile') }; }
    if (t >= T.but1 - 0.1) return { crouch: 0.3, armL: 2.4, armR: 2.2, rifle: 'back', hatOff: true, expr: E('wide', 'shock', 'o', { lookY: -0.8 }) };
    return { crouch: 0.82, armL: 0.75, armR: 1.0, rifle: 'port', expr: E('dot', 'flat', 'line', { look: 0.2 }) };
  } }, (t) => t >= T.finally - 0.5, [-3.0, 0, 3.8]));
  // ---- the radio / field-telephone man
  const phone = add(tommy(42, { mustache: '#6a4a2a', armband: '#c8201e' }), { pose: (t) => {
    if (t >= T.alt && t < T.air + 0.3) return { crouch: 0.55, armL: 1.9, armR: 1.3, propL: 'fieldphone', expr: E('happy', 'raised', 'shout', { look: 0.3 }) };
    if (t >= T.but1 - 0.1) return { crouch: 0.3, armL: 2.5, armR: 2.0, expr: E('wide', 'shock', 'o', { lookY: -0.8, sweat: true }) };
    return { crouch: 0.75, armL: 0.6, armR: 0.8, propL: 'fieldphone', expr: E('dot', 'flat', 'line') };
  } }, (t) => t >= T.finally - 0.5, [-5.2, 0, 3.9]);
  // ---- the sniper (grey, Stahlhelm) in the window
  const sniper = giveRifle(add(german(50, { mustache: '#2a2420' }), { pose: (t) => {
    const fire = SHOTS.some(([ts]) => t > ts && t < ts + 0.12);
    if (t >= T.ko && t < T.ko + 0.9) { const u = ramp(T.ko, T.ko + 0.6, t); return { crouch: 0.25, rifle: 'none', hatOff: true, armL: 2.8, armR: 2.6, yawAbs: 0, expr: E('closed', 'shock', 'o', { lines: true }) }; }
    if (t > T.a7 && t < T.is3) return { crouch: 0.15, armL: 0.9, armR: 2.2, rifle: 'port', expr: E('squint', 'smug', 'smirk', { look: 0.3 }) };
    const smug = false;
    return { crouch: 0.28, armL: 1.55, armR: 1.4, rifle: 'aim', yawAbs: 0 + Math.sin(t * 0.6) * 0.06, jump: fire ? 4 : 0, expr: smug ? E('squint', 'smug', 'smirk') : E('half', 'angry', 'smirk', { look: 0.2 }) };
  } }, (t) => t < T.ko + 0.9, [3.5, 3.3, -6.62]));
  sniper.koFall = (t) => { if (t < T.ko) { sniper.root.rotation.set(0, 0, 0); sniper.root.position.set(3.5, 3.3, -6.62); return; } const u = ramp(T.ko + 0.15, T.ko + 0.7, t); const hop = Math.sin(ramp(T.ko, T.ko + 0.4, t) * Math.PI); sniper.root.rotation.x = -1.4 * u * u; sniper.root.position.set(3.5, 3.3 + hop * 0.3, -6.62 - u * 0.9); };

  // ---- trench people
  const sarge = add(tommy(60, { hat: 'officercap', mustache: '#d8d0c0', chevrons: 3, top: '#7a6a42' }), { scale: 1.04, pose: (t) => {
    if (t >= T.lets && t < T.snipers) return { armL: 0.5, armR: 2.75, crouch: 0.0, expr: E('dot', 'raised', 'shout', { look: 0.4 }) };
    return { armL: 0.6, armR: 1.5, crouch: 0, expr: E('half', 'flat', 'line', { look: -0.3 }) };
  } }, (t) => true, [TX + 0.6, 0, 0.35]);
  sarge.move = (t) => { if (t > T.so - 0.2) sarge.root.position.set(TX + 2.45, 0, 0.75); else sarge.root.position.set(TX + 0.6, 0, 0.35); };
  const bait = giveRifle(add(tommy(61, { mustache: null }), { pose: (t) => {
    if (t < T.soldiers1) return { armL: 0.8, armR: 1.1, rifle: 'port', expr: E('dot', 'raised', 'smile', { look: 0.5 }) };
    if (t < T.helmets + 0.1) { const u = ramp(T.taking - 0.3, T.helmets, t); return { armL: lerp(0.8, 2.85, u), armR: lerp(1.1, 2.9, u), rifle: 'back', expr: E('closed', 'proud', 'smile') }; }
    if (t < T.barely) return { armL: 0.9, armR: 1.9, rifle: 'back', hatOff: true, expr: E('happy', 'raised', 'grin', { look: 0.4 }) };
    if (t < T.ping2) { const u = smooth(T.barely, T.fool + 0.4, t); return { armL: lerp(2.4, 2.75, u), armR: lerp(2.4, 2.8, u), rifle: 'up', hatOff: true, expr: E('half', 'smug', 'smirk', { lookY: -0.6 }) }; }
    return { armL: 2.75, armR: 2.8, rifle: 'up', hatOff: true, jump: t < T.ping2 + 0.2 ? 14 : 0, expr: E('wide', 'raised', 'grin', { lines: t < T.ping2 + 0.5, lookY: -0.7 }) };
  } }, (t) => true, [TX + 0.25, 0.42, -0.62]));
  const crafter = add(tommy(62, { mustache: '#6a4a2a', hat: 'brodie' }), { pose: (t) => {
    if (t >= T.some && t < T.dummy) return { armL: 1.4, armR: 1.4, expr: E('happy', 'proud', 'grin', { look: 0.5 }) };
    if (t >= T.dummy) return { armL: 2.8, armR: 2.85, expr: t > T.dummyPing ? E('wide', 'shock', 'o', { lines: true }) : E('closed', 'smug', 'grin') };
    return { armL: 0.6, armR: 0.8, expr: E('dot', 'flat', 'line') };
  } }, (t) => true, [TX + 3.1, 0, 0.3]);
  // trench crowd: on the fire step and the duckboards, rifles, Brodies (two in caps)
  const TCROWD = [[-9.2, 1], [-8.1, 0], [-7.1, 1], [-6.0, 0], [-5.0, 1], [-4.0, 0], [-3.1, 1], [-2.2, 0], [-1.25, 1], [1.5, 0], [2.0, 1], [5.8, 1], [6.6, 0], [7.4, 1], [8.3, 0], [9.2, 1], [10.2, 0], [-10.4, 0], [11.2, 1]];
  TCROWD.forEach(([x, step], i) => {
    const sp = tommy(70 + i, { mustache: i % 4 === 1 ? '#3a2418' : null, hat: i % 7 === 3 ? 'officercap' : 'brodie', hatColor: i % 5 === 2 ? '#4f5232' : undefined });
    const ph = R() * 6; const c = add(sp, { scale: 0.95 + R() * 0.1, pose: (t) => {
      const att = t >= T.lets && t < T.snipers; // listening to the sergeant
      return { armL: step ? 0.8 : 0.5, armR: step ? 1.1 : 0.7, rifle: step ? 'port' : 'back', crouch: step ? 0.0 : 0.05, expr: att ? E('dot', 'raised', 'o', { look: (0.6 - (x / 10)) * 0.8 }) : E(i % 3 ? 'dot' : 'half', i % 2 ? 'worried' : 'flat', i % 4 ? 'line' : 'frown', { look: Math.sin(t * 0.8 + ph) * 0.5 }) };
    } }, (t) => true, [TX + x, step ? 0.42 : 0, step ? -0.62 : 0.15 + R() * 0.35]);
    giveRifle(c);
  });

  // rifle placement per pose (body space; the body faces +z)
  const placeRifle = (c) => {
    const r = c.rifle; if (!r) return; const mode = (c.lastPose && c.lastPose.rifle) || 'none'; r.visible = mode !== 'none';
    if (!r.visible) return;
    r.rotation.set(0, 0, 0); r.position.set(0, 0, 0);
    if (mode === 'port') { r.position.set(-0.32, 0.42 - (c.lastPose.crouch || 0) * 0.585, 0.16); r.rotation.set(0, 0, 0.95); }
    else if (mode === 'back') { r.position.set(-0.3, 0.35 - (c.lastPose.crouch || 0) * 0.585, -0.17); r.rotation.set(0, 0, 0.85); }
    else if (mode === 'up') { const h = c.hands[1].position; r.position.set(h.x + 0.02, h.y - 0.25, h.z); r.rotation.set(0, 0, Math.PI / 2); }
    else if (mode === 'aim') { r.position.set(0.24, 1.02 - (c.lastPose.crouch || 0) * 0.585, -0.35); r.rotation.set(0, -Math.PI / 2, 0); }
  };
  const V = new THREE.Vector3(), V2 = new THREE.Vector3(), Q = new THREE.Quaternion(), M4 = new THREE.Matrix4(), EU = new THREE.Euler(), S1 = new THREE.Vector3(1, 1, 1);
  const muzzleOf = (c, out) => { c.rifle.updateWorldMatrix(true, true); return out.set(1.25, 0, 0).applyMatrix4(c.rifle.children[0].matrixWorld.clone().multiply(new THREE.Matrix4().makeTranslation(0, 0, 0))) ; };
  const rifleTip = (c, out) => { c.rifle.updateWorldMatrix(true, true); const m = c.rifle.matrixWorld; return out.set(1.25, 0, 0).applyMatrix4(m); };

  // =====================================================================================================
  // LIGHTS
  // =====================================================================================================
  const hemi = new THREE.HemisphereLight('#8f9fc0', '#3a3228', 0.8); root.add(hemi);
  const key = new THREE.DirectionalLight('#ffd2a0', 2.0); root.add(key); root.add(key.target);
  key.castShadow = true; key.shadow.mapSize.set(2048, 2048); key.shadow.bias = -0.0004; key.shadow.normalBias = 0.03;
  const envMaps = {};
  function initGL(gl) { const pm = new THREE.PMREMGenerator(gl); if (A.hdr.ruins) envMaps.ruins = pm.fromEquirectangular(A.hdr.ruins).texture; pm.dispose(); }
  const fog = new THREE.FogExp2('#6a7286', 0.02);
  const scratch = new THREE.PerspectiveCamera(60, 720 / 1280, 0.05, 400);
  const FR = new THREE.Frustum(), PV = new THREE.Matrix4(), SPH = new THREE.Sphere(new THREE.Vector3(), 1.4);

  // =====================================================================================================
  // UPDATE
  // =====================================================================================================
  function update(t, cam, scene, shotIdx) {
    const cs = cameraFor(shotIdx, t, cam);
    const shot = cs.shot; const set = shot.set; const inTrench = set === 'trench';
    // ---- story props ----
    // hero / buddies x moves
    hero.root.position.x = heroX(t); hero.root.position.z = (t >= T.just && t < T.wrong + 0.7) ? lerp(HERO_Z, 3.25, smooth(T.just + 0.1, T.just + 0.55, t) * (1 - smooth(T.wrong + 0.18, T.wrong + 0.7, t))) : HERO_Z;
    marks.root.position.set(markX(t), 0, t >= T.finally && t < T.a12 ? 3.85 : 3.75);
    dist.root.position.x = distX(t);
    sniper.koFall(t); sarge.move(t);
    // sniper's falling rifle on the KO
    fallRifle.visible = t > T.ko && t < T.ko + 1.2 && !inTrench;
    if (fallRifle.visible) { const u = t - T.ko; fallRifle.position.set(3.5 + u * 0.4, 4.3 - 4.9 * u * u, -5.7 + u * 1.2); fallRifle.rotation.set(u * 5, 0.3, u * 7); }
    // dummy in the trench (held, then raised above the parapet, pinged and spinning)
    {
      const hold = t < T.dummy; const g = dummyT;
      if (hold) { g.position.set(TX + 3.5, 1.25, 0.32); g.rotation.set(0, Math.PI / 2, 0); }
      else { const u = smooth(T.dummy, T.dummy + 0.8, t); g.position.set(TX + 3.1, lerp(1.9, 2.72, u), -1.0); g.rotation.set(0, Math.PI + (t > T.dummyPing ? (t - T.dummyPing) * 14 : 0), 0); }
      g.userData.head.rotation.y = -Math.PI / 2;
      g.visible = t > T.some - 0.5;
    }
    // street dummy ("they would do it again") held up above the wall end by the marksman
    { const g = dummyS; g.visible = t > T.then - 0.5 && t < T.but; const u = smooth(T.then + 0.4, T.then + 1.6, t); g.position.set(0.55, lerp(1.2, 1.78, u), WALL_Z + 0.42); g.rotation.set(0, Math.sin(t * 2) * 0.2, 0.05); }
    // mirror on a stick: around the wall end from the marksman's hands
    {
      const on = t >= T.but && t < T.finally && !inTrench; mirror.visible = mirrorStick.visible = on;
      if (on) {
        const ext = smooth(T.but + 0.2, T.mirror + 0.6, t);
        mirror.position.set(lerp(0.95, 1.42, ext), 0.98 + Math.sin(t * 2.2) * 0.008, lerp(3.3, 2.85, ext));
        mirror.lookAt(lerp(1.0, 1.9, ext), 1.06, 2.3); // tilted toward the street / the camera
        marks.update(t, cam); marks.hands[1].getWorldPosition(V);
        const mid = V.clone().add(mirror.position).multiplyScalar(0.5); mirrorStick.position.copy(mid); mirrorStick.scale.set(1, V.distanceTo(mirror.position), 1);
        mirrorStick.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), mirror.position.clone().sub(V).normalize());
      }
      mirrorGlint.visible = on && t > T.catch + 0.1 && t < T.catch + 0.75;
      if (mirrorGlint.visible) { const k = 1 - (t - (T.catch + 0.1)) / 0.65; mirror.userData.glass.getWorldPosition(V); mirrorGlint.position.copy(V).add(new THREE.Vector3(0.03, 0.0, -0.01)); const s = 0.12 * (0.6 + 0.6 * k) * (1 + 0.2 * Math.sin(t * 60)); mirrorGlint.scale.set(s, s, 1); mirrorGlint.material.rotation = t * 3; mirrorGlint.material.opacity = Math.min(1, k * 1.4); }
    }
    // helmets: bait (in hand -> on the rifle -> pinged), distractor (on the rifle -> pinged), popper (pinged off his head)
    flyHelm.forEach((h) => { h.visible = false; });
    const fly = (h, p0, t0, vx, vy, vz, spin) => { const u = t - t0; h.visible = u >= 0 && u < 1.6; if (!h.visible) return; h.position.set(p0.x + vx * u, p0.y + vy * u - 4.9 * u * u, p0.z + vz * u); h.rotation.set(u * spin, u * spin * 0.7, u * spin * 0.4); };
    handHelm.visible = false; handHelm2.visible = false;
    // (characters are updated below; prop positions that need hand positions are done after)
    // ---- planes + bombs (air strike) ----
    planes.forEach((p, i) => { const u = (t - (T.air - 0.45 + i * 0.22)) / 1.7; p.visible = u > 0 && u < 1 && !inTrench; if (!p.visible) return; p.position.set(lerp(-20, 26, u), 9.0 + i * 1.6 + Math.sin(u * 3) * 0.3, -2.0 - i * 2.2); p.rotation.set(0, Math.PI / 2, (i ? -1 : 1) * 0.12 + Math.sin(t * 2 + i) * 0.05); p.userData.prop.rotation.z = t * 40; });
    bombs.forEach((b, i) => { const t0 = T.air + 0.12 + i * 0.07; const u = t - t0; b.visible = u > 0 && t < T.boom + 0.02 && !inTrench; if (!b.visible) return; const k = clamp(u / (T.boom - t0), 0, 1); b.position.set(lerp(1.0 + i * 0.8, 3.0 + i * 0.5, k), lerp(9.0 + (i % 2) * 1.6, 5.5, k * k), lerp(-2.0 - (i % 2) * 2.2, -6.2, k)); b.lookAt(b.position.x + 0.5, b.position.y - 1.0, b.position.z - 0.4); });
    // ---- explosion + building collapse ----
    const bt = t - T.boom; const boomOn = bt > 0 && !inTrench;
    boomFire.forEach((s, i) => { s.visible = boomOn && bt < 1.4; if (!s.visible) return; const k = bt / 1.4; const a = i * 0.7; s.position.set(4.0 + Math.cos(a) * (0.6 + k * 2.2), 4.8 + Math.sin(a * 1.3) * 1.2 + k * 2.5, -5.4 + Math.sin(a) * 0.6); const sc = (2.4 + i * 0.25) * (0.4 + Math.pow(k, 0.4)); s.scale.set(sc, sc * 1.4, 1); s.material.opacity = Math.max(0, 1 - k * 0.9); });
    boomSmoke.forEach((s, i) => { s.visible = boomOn && bt > 0.12; if (!s.visible) return; const k = bt - 0.12; const a = i * 0.63; s.position.set(4.0 + Math.cos(a) * (1.0 + k * 1.6), 4.5 + k * (1.3 + i * 0.12) + Math.sin(a) * 0.8, -5.6 + Math.sin(a) * 0.8); const sc = 2.6 + k * 2.2 + i * 0.2; s.scale.set(sc, sc, 1); s.material.opacity = clamp(0.9 - k * 0.12, 0, 0.9); });
    boomL.intensity = boomOn ? Math.max(0, 120 * (1 - bt / 1.0)) + (bt < 2.5 ? 15 : 0) : 0;
    debris.visible = boomOn && bt < 2.2;
    if (debris.visible) { for (let i = 0; i < 60; i++) { const d = deb0[i]; const vx = d[0] * 12, vy = 4 + d[1] * 8, vz = 2 + d[2] * 9; V.set(4 + vx * bt, Math.max(0.05, 5 + vy * bt - 4.9 * bt * bt), -5.8 + vz * bt); EU.set(bt * 8 * d[3], bt * 6 * d[4], 0); Q.setFromEuler(EU); M4.compose(V, Q, S1); debris.setMatrixAt(i, M4); } debris.instanceMatrix.needsUpdate = true; }
    bUpper.position.y = boomOn ? -Math.min(3.2, Math.max(0, bt - 0.15) * Math.max(0, bt - 0.15) * 6) : 0; bUpper.rotation.z = boomOn ? -Math.min(0.12, Math.max(0, bt - 0.15) * 0.15) : 0;
    bUpper.visible = !(boomOn && bt > 0.8);
    // ---- money rain ----
    const mt = t - (T.but1 - 0.25); const moneyOn = mt > 0 && !inTrench; bills.visible = coins.visible = moneyOn;
    if (moneyOn) {
      for (let i = 0; i < NB; i++) { const k = money0[i]; const fall = mt * (0.9 + k[0] * 0.6) - k[1] * 0.9; let y = 4.6 + k[1] * 1.5 - fall * 1.7; if (y < 0.02) y = 0.02; V.set(-4.0 + k[2] * 6.5 + Math.sin(t * 1.7 + i) * 0.25, y, 3.2 + k[3] * 4.0 + Math.cos(t * 1.3 + i) * 0.2); if (fall < 0) V.y = 30; EU.set(y > 0.03 ? Math.sin(t * 3 + i) * 1.2 : -Math.PI / 2, t * (1 + k[4]) * (y > 0.03 ? 1 : 0), y > 0.03 ? Math.cos(t * 2.3 + i) : 0); Q.setFromEuler(EU); M4.compose(V, Q, S1); bills.setMatrixAt(i, M4); }
      for (let i = 0; i < NC; i++) { const k = money0[NB + i]; const fall = mt * (1.4 + k[0] * 0.6) - k[1] * 0.8; let y = 5.0 + k[1] * 1.2 - fall * 2.4; if (y < 0.01) y = 0.01; V.set(-3.8 + k[2] * 6.0, y, 3.3 + k[3] * 3.6); if (fall < 0) V.y = 30; EU.set(t * 9 * k[4], t * 5, 0); Q.setFromEuler(EU); M4.compose(V, Q, S1); coins.setMatrixAt(i, M4); }
      bills.instanceMatrix.needsUpdate = true; coins.instanceMatrix.needsUpdate = true;
    }
    // ---- sniper flash / impacts / tracer ----
    flashS.visible = false; flashS2.visible = false; flashL.intensity = 0; tracer.visible = false; sparks.forEach((s) => { s.visible = false; });
    let flashAmt = 0;
    if (!inTrench) for (const [ts, kind, pos] of SHOTS) {
      const u = t - ts; if (u < -0.001 || u > 0.6) continue;
      if (u < 0.1) { flashS.visible = true; flashS.position.copy(MUZZLE); const s = (u < 0.035 ? 1.5 : 0.9) * (shot.name === 'loud' ? 1.8 : 1.0) * (1 - u * 5); flashS.scale.set(s, s, 1); flashS.material.rotation = ts * 7; flashL.position.copy(MUZZLE).add(new THREE.Vector3(0, 0, 0.5)); flashL.intensity = 40 * (1 - u * 10); if (shot.name === 'loud' || shot.name === 'wrong' || shot.name === 'nest') flashAmt = Math.max(flashAmt, 0.35 * (1 - u * 10)); }
      if (pos && u < 0.07) { tracer.visible = true; const k = clamp(u / 0.06, 0, 1); V.copy(MUZZLE).lerp(pos, k); V2.copy(MUZZLE).lerp(pos, Math.max(0, k - 0.35)); tracer.position.copy(V).add(V2).multiplyScalar(0.5); tracer.scale.set(1, 1, Math.max(0.01, V.distanceTo(V2))); tracer.lookAt(V); }
      if (pos && kind === 'ping' && u > 0.04 && u < 0.3) { const sp = sparks[0]; sp.visible = true; sp.position.copy(pos); const s = 0.5 * (1 - (u - 0.04) / 0.26) + 0.2; sp.scale.set(s, s, 1); sp.material.rotation = u * 8; }
    }
    // dirt puffs from the impacts
    let pi = 0;
    puffs.forEach((p) => { p.visible = false; });
    if (!inTrench) for (const [ts, kind, pos] of SHOTS) { const u = t - ts - 0.04; if (!pos || kind === 'ping' || u < 0 || u > 1.1 || pi >= puffs.length - 1) continue; for (let k = 0; k < 2 && pi < puffs.length; k++) { const p = puffs[pi++]; p.visible = true; p.position.set(pos.x + (k - 0.5) * 0.15, pos.y + u * (0.5 + k * 0.3), pos.z + 0.05); const s = 0.25 + u * 0.9 + k * 0.1; p.scale.set(s, s, 1); p.material.opacity = Math.max(0, 0.85 * (1 - u / 1.1)); } }
    // marksman's shot
    if (!inTrench && t > T.markFire && t < T.markFire + 0.09) { rifleTip(marks, V); flashS2.visible = true; flashS2.position.copy(V); const s = 0.9; flashS2.scale.set(s, s, 1); flashL.position.copy(V); flashL.intensity = 30; flashAmt = Math.max(flashAmt, 0.18); }
    // scope shot: far flash is off-screen; in the trench, the ping on the bait helmet + the dummy
    // ---- fires + smoke animation ----
    fires.forEach((f) => { f.fl.forEach((s, i) => { const k = 0.8 + 0.25 * Math.sin(t * (9 + i * 2.3) + f.ph + i); s.scale.set(0.35 * f.s * k, 0.75 * f.s * (0.85 + 0.3 * Math.sin(t * 7 + i * 1.7 + f.ph)), 1); }); if (f.L) f.L.intensity = 6 * f.s * (0.8 + 0.2 * Math.sin(t * 13 + f.ph) + 0.1 * Math.sin(t * 31)); });
    smokeCols.forEach((c) => { c.arr.forEach((s, i) => { const ph = ((t * 0.08 + i / c.arr.length + c.ph) % 1); s.position.set(c.x + Math.sin(ph * 4 + i) * c.scale * 0.3 + ph * c.scale * 0.6, c.y + ph * c.scale * 3, c.z); const sc = c.scale * (0.6 + ph * 1.4); s.scale.set(sc, sc, 1); s.material.opacity = 0.45 * Math.sin(ph * Math.PI); }); });
    winGlows.forEach((m, i) => { m.material.emissiveIntensity = 0.7 + 0.25 * Math.sin(t * (5 + i) + i); });

    // ---- characters ----
    FR.setFromProjectionMatrix(PV.multiplyMatrices(cam.projectionMatrix, cam.matrixWorldInverse));
    chars.forEach((c) => { let v = c.vis(t); if (v) { c.root.getWorldPosition(V); SPH.center.copy(V).setY(V.y + 1.0); v = FR.intersectsSphere(SPH); } c.root.visible = v; if (v) { c.update(t, cam); placeRifle(c); } });
    // props that ride on hands / rifles (need the character pose of this frame)
    binoc.visible = false;
    if (hero.root.visible && hero.lastPose && hero.lastPose.binoc) { hero.head.getWorldPosition(V); hero.pivot.getWorldQuaternion(Q); binoc.visible = true; binoc.quaternion.copy(Q); V2.set(0, 0.0, 0.33).applyQuaternion(Q); binoc.position.copy(V).add(V2); }
    if (bait.root.visible) {
      if (t >= T.helmets + 0.1 && t < T.barely) { bait.hands[1].getWorldPosition(V); handHelm.visible = true; handHelm.position.copy(V).add(new THREE.Vector3(0, 0.06, 0.08)); handHelm.rotation.set(0.3, 0, -0.4); }
      if (t >= T.barely && t < T.ping2) { rifleTip(bait, V); handHelm.visible = true; handHelm.position.copy(V).add(new THREE.Vector3(0, 0.1, 0)); handHelm.rotation.set(0.1, t * 0.2, 0.06 * Math.sin(t * 2)); }
    }
    if (t >= T.ping2) { rifleTip(bait, V2); fly(flyHelm[0], V2.clone().add(new THREE.Vector3(0, 0.1, 0)), T.ping2, 0.7, 3.0, 1.2, 11); if (inTrench && t - T.ping2 < 0.26) { const sp = sparks[1]; sp.visible = true; sp.position.copy(V2).add(new THREE.Vector3(0, 0.2, -0.15)); const s = 0.6 * (1 - (t - T.ping2) / 0.26) + 0.2; sp.scale.set(s, s, 1); } }
    if (inTrench && t > T.dummyPing && t < T.dummyPing + 0.26) { const sp = sparks[1]; sp.visible = true; sp.position.copy(dummyT.position).add(new THREE.Vector3(0, 0.25, -0.2)); const s = 0.55 * (1 - (t - T.dummyPing) / 0.26) + 0.2; sp.scale.set(s, s, 1); }
    if (dist.root.visible && dist.lastPose && dist.lastPose.rifle === 'up' && t < T.decoyPing) { rifleTip(dist, V); handHelm2.visible = true; handHelm2.position.copy(V).add(new THREE.Vector3(0, 0.1, 0)); handHelm2.rotation.set(0.05, 0, 0.05 * Math.sin(t * 3)); }
    if (t >= T.decoyPing && t < T.decoyPing + 1.6 && !inTrench) { rifleTip(dist, V2); fly(flyHelm[1], V2.clone().add(new THREE.Vector3(0, 0.1, 0)), T.decoyPing, -0.8, 4.0, 1.4, 12); }
    if (t >= T.popPing && t < T.popPing + 1.6 && !inTrench) fly(flyHelm[2], new THREE.Vector3(-2.0, 1.95, 3.75), T.popPing, 0.6, 3.6, 1.2, 10);
    flyStahl.visible = false; if (t >= T.ko && t < T.ko + 1.4 && !inTrench) { const u = t - T.ko; flyStahl.visible = true; flyStahl.position.set(3.5 + u * 0.5, 4.75 + 3.6 * u - 4.9 * u * u, -6.5 + u * 0.9); flyStahl.rotation.set(u * 9, u * 4, u * 6); }

    // ---- lighting per set ----
    scene.environment = envMaps.ruins || null; scene.environmentIntensity = inTrench ? 0.55 : 0.5; scene.environmentRotation.set(0, 1.0, 0);
    const room = shot.name === 'nest' || shot.name === 'sniper-ots';
    hemi.color.set(inTrench ? '#8ea0c4' : '#8696bc'); hemi.groundColor.set('#3a3026'); hemi.intensity = room ? 0.6 : 1.1;
    key.color.set('#ffcf98'); key.intensity = room ? 1.2 : 2.5;
    fog.color.set(inTrench ? '#6c7690' : '#66708a'); fog.density = shot.name === 'scope' ? 0.0 : inTrench ? 0.016 : 0.022;
    if (boomOn && bt < 2.5) fog.color.lerp(new THREE.Color('#8a5a40'), 0.4 * (1 - bt / 2.5));
    scene.fog = fog; scene.background = null;
    skyMat.uniforms.uExp.value = inTrench ? 1.0 : 0.92;
    CHAR_LIGHT.rim.set('#ffc45a'); CHAR_LIGHT.rimAmt = 0.45; syncCharLight();
    // key light: low warm sun from behind-right of the camera's view, shadows framed on the look point
    const fwd = new THREE.Vector3().subVectors(cs.look, cam.position).setY(0).normalize(); const rgt = new THREE.Vector3(-fwd.z, 0, fwd.x);
    const kd = new THREE.Vector3().addScaledVector(rgt, 0.75).addScaledVector(fwd, 0.35).add(new THREE.Vector3(0, 0.75, 0)).normalize();
    CHAR_LIGHT.keyDir.copy(kd);
    const L = cs.look; const sz = clamp(cs.focus * 0.9, 3.5, 14);
    key.position.copy(L).addScaledVector(kd, 25); key.target.position.copy(L);
    const sc = key.shadow.camera; sc.left = -sz; sc.right = sz; sc.top = sz; sc.bottom = -sz; sc.near = 0.5; sc.far = 60; sc.updateProjectionMatrix();
    key.target.updateMatrixWorld(); key.updateMatrixWorld();
    lanterns.forEach((l) => { l.visible = inTrench; });
    fires.forEach((f) => { if (f.L) f.L.visible = !inTrench ? f.grp.position.x < 50 : f.grp.position.x > 50; });
    cameraFor(shotIdx, t, cam);
    const boomFlash = boomOn ? Math.max(0, 1 - bt / 0.25) * 0.8 : 0;
    return { blur: 0, flash: Math.max(flashAmt, boomFlash), flashCol: '#ffd8a0', focus: cs.focus, aper: cs.aper, fgMax: 8, motion: null, ao: 0.4, edge: 0.32, scope: shot.scope ? 1 : 0 };
  }
  return { root, update, initGL };
}
