#!/usr/bin/env bash
# Smoke test: proves setup + the whole pipeline work on this machine (about 15-20 min on a CPU sandbox).
#   setsid nohup bash smoke_test.sh /tmp/a3sv_smoke > /tmp/a3sv_smoke.log 2>&1 &      then poll /tmp/a3sv_smoke.log
# Steps: setup -> new project -> CC0 assets -> voice (edge-tts, fallback: test tone) -> word timings -> SFX + music + mix
#        -> character sheet + 2 stills -> the demo rendered at 1080x1920 in chunks -> act clip -> final mp4 + QA -> checks.
set -uo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"; BASE="${1:-/tmp/a3sv_smoke}"; P="$BASE/proj"
step() { printf '\n[%s] %s\n' "$(date -u +%T)" "$*"; }
fail() { echo "SMOKE FAIL: $*"; exit 1; }
rm -rf "$BASE"; mkdir -p "$BASE"
step "setup"; bash "$ROOT/setup.sh" || fail setup
step "new project"; bash "$ROOT/new_project.sh" "$P" || fail new_project; cd "$P"
step "assets"; .venv/bin/python tools/fetch_assets.py | tail -3
step "voice"
if env -u HTTP_PROXY -u HTTPS_PROXY -u http_proxy -u https_proxy .venv/bin/python tools/tts_edge.py voice_blocks.json audio/vo && ls audio/vo/*.mp3 >/dev/null 2>&1; then
  .venv/bin/python tools/voice_prep.py audio/vo/vo_*.mp3 --script script.json || fail voice_prep
  .venv/bin/python tools/words.py public/voiceover.wav words.json --script script.json || .venv/bin/python tools/est_timing.py script.json words.json
else
  echo "edge-tts unavailable -> test tone voice + estimated timing"; .venv/bin/python tools/est_timing.py script.json words.json
  ffmpeg -v error -y -f lavfi -i "sine=f=220:d=6" -ar 48000 public/voiceover.wav
fi
.venv/bin/python tools/write_timing.py words.json src/timing.js || fail timing
step "sound design + mix"
DUR=$(python3 -c "import re;print(re.search(r'DURATION_S=([0-9.]+)',open('src/timing.js').read()).group(1))")
.venv/bin/python audio/make_audio.py || fail make_audio
.venv/bin/python audio/mix.py --voice public/voiceover.wav --bed audio/sfx_bed.wav --music audio/music_raw.wav --dur $DUR --out audio/final_mix || fail mix
step "stills (cast sheet + 2 frames)"
bash tools/stillrun.sh smoke chars 0 $(python3 tools/frames.py 2 | awk '{print $2}')
cat out/stills.log | tail -5; [ -f out/chars3d.png ] && [ -f out/sheet_smoke.jpg ] || fail stills
step "render the whole demo (about 4-5 s) at 1080x1920, act clip of frames 0-59, finish + QA"
SCALE=1.5 STEP=60 bash tools/render.sh; tail -4 out/chunks/render.log
[ -f out/chunks/c_00000_00059.done ] || { tail -30 out/chunks/c_00000_00059.log; fail render; }
bash tools/act.sh 0 59 || fail act
bash tools/finish.sh "Smoke Test" || fail finish
grep -q "SUMMARY FAIL" out/qa.txt && fail "qa (see out/qa.txt)"
step "checks"
ffprobe -v error -show_entries stream=codec_type,width,height,r_frame_rate -show_entries format=duration -of compact out/act_0_59.mp4
W=$(ffprobe -v error -select_streams v:0 -show_entries stream=width,height -of csv=p=0 out/act_0_59.mp4)
[ "$W" = "1080,1920" ] || fail "size $W"
ffmpeg -v error -y -i out/act_0_59.mp4 -vf "fps=2,scale=270:-2,tile=4x1" -frames:v 1 -update 1 out/smoke_frames.jpg
.venv/bin/python - <<'PY'
from PIL import Image, ImageStat
im = Image.open('out/smoke_frames.jpg').convert('L'); m = ImageStat.Stat(im).mean[0]; s = ImageStat.Stat(im).stddev[0]
print('frame mean', round(m, 1), 'stddev', round(s, 1)); assert 20 < m < 235 and s > 12, 'frames look blank'
PY
[ $? = 0 ] || fail "blank frames"
echo "SMOKE PASS  project: $P  final: $P/out/Smoke Test.mp4  clip: $P/out/act_0_59.mp4  stills: $P/out/sheet_smoke.jpg  cast: $P/out/chars3d.png"
